"use strict";
var config = require('../common/config')(__dirname);
module.exports = config;
