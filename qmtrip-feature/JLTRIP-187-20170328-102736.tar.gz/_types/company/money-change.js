"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const common_1 = require("common/model/common");
const _types_1 = require("_types");
const object_1 = require("common/model/object");
const model_1 = require("common/model");
let MoneyChange = class MoneyChange extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(val) { }
    get companyId() { return null; }
    set companyId(val) { }
    get status() { return 0; }
    set status(val) { }
    get money() { return 0; }
    set money(val) { }
    get channel() { return 0; }
    set channel(val) { }
    get userId() { return null; }
    set userId(val) { }
    get remark() { return ''; }
    set remark(val) { }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], MoneyChange.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], MoneyChange.prototype, "companyId", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], MoneyChange.prototype, "status", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.NUMERIC(15, 2) })
], MoneyChange.prototype, "money", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], MoneyChange.prototype, "channel", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], MoneyChange.prototype, "userId", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], MoneyChange.prototype, "remark", null);
tslib_1.__decorate([
    common_1.Create()
], MoneyChange, "create", null);
MoneyChange = tslib_1.__decorate([
    common_1.Table(_types_1.Models.moneyChange, 'company.')
], MoneyChange);
exports.MoneyChange = MoneyChange;

//# sourceMappingURL=money-change.js.map
