'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const _types_1 = require("_types");
const model_1 = require("common/model");
const common_1 = require("common/model/common");
const object_1 = require("common/model/object");
var API = require("common/api");
let getSupplier;
var ESupplierType;
(function (ESupplierType) {
    ESupplierType[ESupplierType["COMPANY_CUSTOM"] = 1] = "COMPANY_CUSTOM";
    ESupplierType[ESupplierType["SYSTEM_CAN_IMPORT"] = 2] = "SYSTEM_CAN_IMPORT";
    ESupplierType[ESupplierType["SYSTEM_CAN_NOT_IMPORT"] = 3] = "SYSTEM_CAN_NOT_IMPORT";
})(ESupplierType = exports.ESupplierType || (exports.ESupplierType = {}));
let Supplier = class Supplier extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(val) { }
    //类型
    get type() { return ESupplierType.COMPANY_CUSTOM; }
    set type(val) { }
    // 供应商名称
    get name() { return null; }
    set name(val) { }
    // 交通预定链接
    get trafficBookLink() { return null; }
    set trafficBookLink(val) { }
    // 酒店预定链接
    get hotelBookLink() { return null; }
    set hotelBookLink(val) { }
    // 供应商logo
    get logo() { return null; }
    set logo(val) { }
    // 是否使用
    get isInUse() { return true; }
    set isInUse(val) { }
    // 拉取关联订单使用的供应商key
    get supplierKey() { return null; }
    set supplierKey(val) { }
    //所属企业
    get company() { return null; }
    set company(val) { }
    getBookLink(options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!this.isLocal) {
                API.require('place');
                yield API.onload();
            }
            let reserveType = options.reserveType;
            let defaultBackUrl = "";
            switch (reserveType) {
                case "travel_plane":
                case "travel_train":
                    defaultBackUrl = this.trafficBookLink;
                    break;
                case "hotel":
                    defaultBackUrl = this.hotelBookLink;
                    break;
            }
            if (!this.supplierKey) {
                return { url: defaultBackUrl, jsCode: "" };
            }
            if (options.fromCity) {
                console.info(options.fromCity);
                let cityObject = yield API.place.getCityInfo({ cityCode: options.fromCity });
                options.fromCity = cityObject.name;
            }
            if (options.toCity) {
                console.info(options.toCity);
                let cityObject = yield API.place.getCityInfo({ cityCode: options.toCity });
                options.toCity = cityObject.name;
            }
            if (options.city) {
                console.info(options.city);
                let cityObject = yield API.place.getCityInfo({ cityCode: options.city });
                options.city = cityObject.name;
            }
            if (!getSupplier) {
                getSupplier = require('libs/suppliers').getSupplier;
            }
            let client = getSupplier(this.supplierKey);
            var bookLink = yield client.getBookLink(options);
            if (!bookLink || !bookLink.url) {
                return { url: defaultBackUrl, jsCode: "" };
            }
            return bookLink;
        });
    }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], Supplier.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER, defaultValue: ESupplierType.COMPANY_CUSTOM })
], Supplier.prototype, "type", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Supplier.prototype, "name", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Supplier.prototype, "trafficBookLink", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Supplier.prototype, "hotelBookLink", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Supplier.prototype, "logo", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], Supplier.prototype, "isInUse", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Supplier.prototype, "supplierKey", null);
tslib_1.__decorate([
    common_1.ResolveRef({ type: model_1.Types.UUID }, _types_1.Models.company)
], Supplier.prototype, "company", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Supplier.prototype, "getBookLink", null);
tslib_1.__decorate([
    common_1.Create()
], Supplier, "create", null);
Supplier = tslib_1.__decorate([
    common_1.Table(_types_1.Models.supplier, 'company.')
], Supplier);
exports.Supplier = Supplier;

//# sourceMappingURL=supplier.js.map
