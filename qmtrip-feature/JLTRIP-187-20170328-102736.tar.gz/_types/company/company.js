'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const _types_1 = require("_types");
const staff_1 = require("_types/staff");
const travelPolicy_1 = require("_types/travelPolicy");
const model_1 = require("common/model");
const common_1 = require("common/model/common");
const object_1 = require("common/model/object");
const types_1 = require("../approve/types");
const emitter_1 = require("libs/oa/emitter");
const index_1 = require("libs/oa/index");
const language_1 = require("common/language");
const staff_2 = require("../staff/staff");
const trip_plan_num_change_1 = require("./trip-plan-num-change");
var sequelize = require("common/model").DB;
let promoCodeType = require('libs/promoCodeType');
var ECompanyStatus;
(function (ECompanyStatus) {
    ECompanyStatus[ECompanyStatus["DELETE"] = -2] = "DELETE";
    ECompanyStatus[ECompanyStatus["UN_ACTIVE"] = 0] = "UN_ACTIVE";
    ECompanyStatus[ECompanyStatus["ACTIVE"] = 1] = "ACTIVE"; //激活状态
})(ECompanyStatus = exports.ECompanyStatus || (exports.ECompanyStatus = {}));
var ECompanyType;
(function (ECompanyType) {
    ECompanyType[ECompanyType["TRYING"] = 0] = "TRYING";
    ECompanyType[ECompanyType["PAYED"] = 1] = "PAYED";
})(ECompanyType = exports.ECompanyType || (exports.ECompanyType = {}));
let Company = class Company extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    destroy(options) {
        const _super = name => super[name];
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (this.isLocal) {
                let query = { where: { companyId: this.id } };
                let staffs = yield _types_1.Models.staff.find(query);
                yield Promise.all(staffs.map((staff) => staff.destroy(options)));
            }
            _super("destroy").call(this, options);
        });
    }
    get id() { return model_1.Values.UUIDV1(); }
    set id(val) { }
    // '企业编号'
    get companyNo() { return null; }
    set companyNo(val) { }
    // '创建人id'
    get createUser() { return null; }
    set createUser(val) { }
    // '企业名称'
    get name() { return null; }
    set name(val) { }
    // '企业域名'
    get domainName() { return null; }
    set domainName(val) { }
    // '企业描述'
    get description() { return ''; }
    set description(val) { }
    // '企业状态'
    get status() { return ECompanyStatus.UN_ACTIVE; }
    set status(val) { }
    // '企业邮箱'
    get email() { return null; }
    set email(val) { }
    // '创建人手机号'
    get mobile() { return null; }
    set mobile(val) { }
    // '员工数目'
    get staffNum() { return 0; }
    set staffNum(val) { }
    // '员工积分'
    get staffScore() { return 0; }
    set staffScore(val) { }
    // '备注'
    get remark() { return ''; }
    set remark(val) { }
    get paymentPwd() { return null; }
    set paymentPwd(val) { }
    get income() { return 0; }
    set income(val) { }
    get consume() { return 0; }
    set consume(val) { }
    get frozen() { return 0; }
    set frozen(val) { }
    get staffReward() { return 0; }
    set staffReward(val) { }
    get isSetPwd() { return false; }
    set isSetPwd(val) { }
    get isApproveOpen() { return true; }
    set isApproveOpen(val) { }
    get budgetPolicy() { return 'default'; }
    set budgetPolicy(policy) { }
    get getNoticeEmail() { return null; }
    set getNoticeEmail(val) { }
    get budgetConfig() { return {}; }
    ;
    set budgetConfig(conf) { }
    getAgency(id) {
        return _types_1.Models.agency.get(id);
    }
    get coinAccount() { return null; }
    ;
    set coinAccount(coinAccount) { }
    get points2coinRate() { return 50; }
    ;
    set points2coinRate(rate) { }
    get appointedPubilcSuppliers() { return []; }
    ;
    set appointedPubilcSuppliers(val) { }
    get isAppointSupplier() { return false; }
    set isAppointSupplier(val) { }
    get oa() { return types_1.EApproveChannel.QM; }
    set oa(oa) { }
    get expiryDate() { return null; }
    set expiryDate(val) { }
    // 企业员工数目限制
    get staffNumLimit() { return 5; }
    set staffNumLimit(val) { }
    // 企业出差审批数目限制（每月）
    get tripPlanNumLimit() { return 60; }
    set tripPlanNumLimit(val) { }
    // 企业出差审批通过数目（每月月初会清零）
    get tripPlanPassNum() { return 0; }
    set tripPlanPassNum(val) { }
    // 企业出差审批冻结数目
    get tripPlanFrozenNum() { return 0; }
    set tripPlanFrozenNum(val) { }
    // 套餐加油包冻结数目
    get extraTripPlanFrozenNum() { return 0; }
    set extraTripPlanFrozenNum(val) { }
    // 够买套餐条数
    get extraTripPlanNum() { return 0; }
    set extraTripPlanNum(val) { }
    // 够买套餐条数过期时间
    get extraExpiryDate() { return null; }
    set extraExpiryDate(val) { }
    get tripPackageId() { return null; }
    set tripPackageId(id) { }
    //可用剩余行程数
    get tripPlanNumBalance() {
        let num = this.tripPlanNumLimit - this.tripPlanPassNum - this.tripPlanFrozenNum;
        if (num < 0) {
            num = 0;
        }
        if (this.extraTripPlanNum && this.extraExpiryDate && (this.extraExpiryDate.getTime() - new Date().getTime()) > 0) {
            num = num + this.extraTripPlanNum - this.extraTripPlanFrozenNum;
        }
        return num;
    }
    //套餐内剩余行程数
    get tripPlanNumInBase() {
        let num = this.tripPlanNumLimit - this.tripPlanPassNum - this.tripPlanFrozenNum;
        return num;
    }
    //加油包内剩余行程数
    get tripPlanNumInPack() {
        let num = this.extraTripPlanNum - this.extraTripPlanFrozenNum;
        return num;
    }
    get type() { return ECompanyType.TRYING; }
    set type(type) { }
    getStaffs(options) {
        if (!options) {
            options = { where: {} };
        }
        ;
        if (!options.where) {
            options.where = {};
        }
        ;
        options.where.companyId = this.id;
        return _types_1.Models.staff.find(options);
    }
    getStaffNum(options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let companyId = this.id;
            let sql = `select count(id) as staffnum from staff.staffs where company_id='${companyId}' and deleted_at is null and staff_status=${staff_1.EStaffStatus.ON_JOB}`;
            let staff_num = yield sequelize.query(sql);
            return Number(staff_num[0][0].staffnum || 0);
        });
    }
    beforeGoTrip(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            let number = 1;
            if (params && params.number) {
                number = params.number;
            }
            //套餐内剩余量
            let surplus = self.tripPlanNumInBase;
            if (!(surplus >= number)) {
                //套餐包剩余的条数不够
                if (!self.tripPlanNumInPack) {
                    throw language_1.default.ERR.BEYOND_LIMIT_NUM("出差申请");
                }
                else {
                    //套餐包剩余的加上加油包剩余的条数不够
                    if (surplus < 0) {
                        surplus = 0;
                    }
                    if (!((self.tripPlanNumInPack + surplus) >= number
                        && self.extraExpiryDate && self.extraExpiryDate.getTime() - new Date().getTime() > 0)) {
                        throw language_1.default.ERR.BEYOND_LIMIT_NUM("出差申请");
                    }
                }
            }
            return true;
        });
    }
    beforeApproveTrip(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            let number = 1;
            if (params && params.number) {
                number = params.number;
            }
            //过期企业 套餐会被置为0 冻结数不能被自动审批通过
            /*if(self.expiryDate && (self.expiryDate.getTime() - new Date().getTime()) < 0){
             return true;
             }*/
            //套餐内剩余量
            let surplus = self.tripPlanNumLimit - self.tripPlanPassNum;
            if (!(surplus >= number)) {
                if (!self.extraTripPlanNum) {
                    throw language_1.default.ERR.BEYOND_LIMIT_NUM("出差申请");
                }
                else {
                    if (surplus < 0) {
                        surplus = 0;
                    }
                    if (!((self.extraTripPlanNum + surplus) >= number
                        && self.extraExpiryDate && self.extraExpiryDate.getTime() - new Date().getTime() > 0)) {
                        throw language_1.default.ERR.BEYOND_LIMIT_NUM("出差申请");
                    }
                }
            }
            return true;
        });
    }
    /**
     * 增加行程冻结点数
     * @param params
     * @returns {Company}
     */
    frozenTripPlanNum(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let number = 1;
            if (params && params.number) {
                number = params.number;
            }
            let extraFrozen = 0;
            let limitFrozen = 0;
            let lostFrozenNum = this.tripPlanNumLimit - this.tripPlanPassNum - this.tripPlanFrozenNum;
            if (lostFrozenNum > 0) {
                if (lostFrozenNum >= number) {
                    limitFrozen = number;
                }
                else {
                    limitFrozen = lostFrozenNum;
                    extraFrozen = number - lostFrozenNum;
                }
            }
            else {
                extraFrozen = number;
            }
            this.tripPlanFrozenNum = this.tripPlanFrozenNum + limitFrozen;
            this.extraTripPlanFrozenNum = this.extraTripPlanFrozenNum + extraFrozen;
            let result = yield this.save();
            params.type = trip_plan_num_change_1.NUM_CHANGE_TYPE.FROZEN;
            params.companyId = this.id;
            params.number = 0 - number;
            let log = trip_plan_num_change_1.TripPlanNumChange.create(params);
            let account = yield _types_1.Models.staff.get(params.accountId);
            log.account = account;
            yield log.save();
            let frozenNum = { limitFrozen: limitFrozen, extraFrozen: extraFrozen };
            return { company: result, frozenNum: frozenNum };
        });
    }
    /**
     * 审批通过扣减行程点数
     * @param params
     * @returns {Company}
     */
    approvePassReduceTripPlanNum(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let result = this;
            let extraFrozen = params.frozenNum.extraFrozen;
            let limitFrozen = params.frozenNum.limitFrozen;
            if (this.expiryDate && (this.expiryDate.getTime() - new Date().getTime() > 0)) {
                this.tripPlanFrozenNum = this.tripPlanFrozenNum - limitFrozen;
                this.tripPlanPassNum = this.tripPlanPassNum + limitFrozen;
            }
            if (this.extraExpiryDate && (this.extraExpiryDate.getTime() - new Date().getTime() > 0)) {
                this.extraTripPlanFrozenNum = this.extraTripPlanFrozenNum - extraFrozen;
                this.extraTripPlanNum = this.extraTripPlanNum - extraFrozen;
            }
            result = yield this.save();
            params.type = trip_plan_num_change_1.NUM_CHANGE_TYPE.CONSUME;
            params.companyId = this.id;
            params.number = extraFrozen + limitFrozen;
            let log = trip_plan_num_change_1.TripPlanNumChange.create(params);
            let account = yield _types_1.Models.staff.get(params.accountId);
            log.account = account;
            yield log.save();
            return result;
        });
    }
    /**
     * 审批通过本月之前的行程只处理加油包行程数
     * @param params
     * @returns {Company}
     */
    approvePassReduceBeforeNum(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let extraFrozen = params.frozenNum.extraFrozen;
            let limitFrozen = params.frozenNum.limitFrozen;
            if (this.extraExpiryDate && (this.extraExpiryDate.getTime() - new Date().getTime() > 0)) {
                this.extraTripPlanFrozenNum = this.extraTripPlanFrozenNum - extraFrozen;
                this.extraTripPlanNum = this.extraTripPlanNum - extraFrozen;
            }
            let result = yield this.save();
            params.type = trip_plan_num_change_1.NUM_CHANGE_TYPE.CONSUME;
            params.companyId = this.id;
            params.number = extraFrozen + limitFrozen;
            let log = trip_plan_num_change_1.TripPlanNumChange.create(params);
            let account = yield _types_1.Models.staff.get(params.accountId);
            log.account = account;
            yield log.save();
            return result;
        });
    }
    /**
     * 审批驳回返回行程点数
     * @param params
     * @returns {Company}
     */
    approveRejectFreeTripPlanNum(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let extraFrozen = params.frozenNum.extraFrozen;
            let limitFrozen = params.frozenNum.limitFrozen;
            if (this.expiryDate && (this.expiryDate.getTime() - new Date().getTime() > 0)) {
                this.tripPlanFrozenNum = this.tripPlanFrozenNum - limitFrozen;
            }
            if (this.extraExpiryDate && (this.extraExpiryDate.getTime() - new Date().getTime() > 0)) {
                this.extraTripPlanFrozenNum = this.extraTripPlanFrozenNum - extraFrozen;
            }
            let result = yield this.save();
            params.type = trip_plan_num_change_1.NUM_CHANGE_TYPE.FREE_FROZEN;
            params.companyId = this.id;
            params.number = extraFrozen + limitFrozen;
            let log = trip_plan_num_change_1.TripPlanNumChange.create(params);
            let account = yield _types_1.Models.staff.get(params.accountId);
            log.account = account;
            yield log.save();
            return result;
        });
    }
    /**
     *审批驳回本月之前的行程只处理加油包行程数
     * @param params
     * @returns {Company}
     */
    approveRejectFreeBeforeNum(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let extraFrozen = params.frozenNum.extraFrozen;
            if (this.extraExpiryDate && (this.extraExpiryDate.getTime() - new Date().getTime() > 0)) {
                this.extraTripPlanFrozenNum = this.extraTripPlanFrozenNum - extraFrozen;
            }
            let result = yield this.save();
            params.type = trip_plan_num_change_1.NUM_CHANGE_TYPE.FREE_FROZEN;
            params.companyId = this.id;
            params.number = extraFrozen;
            let log = trip_plan_num_change_1.TripPlanNumChange.create(params);
            let account = yield _types_1.Models.staff.get(params.accountId);
            log.account = account;
            yield log.save();
            return result;
        });
    }
    /**
     * 减少冻结行程点数
     * @param params
     * @returns {Company}
     */
    freeFrozenTripPlanNum(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let number = 1;
            if (params && params.number) {
                number = params.number;
            }
            this.tripPlanFrozenNum = this.tripPlanFrozenNum - number;
            let result = yield this.save();
            params.type = trip_plan_num_change_1.NUM_CHANGE_TYPE.FREE_FROZEN;
            params.companyId = this.id;
            let log = trip_plan_num_change_1.TripPlanNumChange.create(params);
            let account = yield _types_1.Models.staff.get(params.accountId);
            log.account = account;
            yield log.save();
            return result;
        });
    }
    /**
     * 减少加油包行程条数
     * @param params
     * @returns {Company}
     */
    reduceExtraTripPlanNum(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let number = 1;
            if (params && params.number) {
                number = params.number;
            }
            this.extraTripPlanNum = this.extraTripPlanNum - number;
            let result = yield this.save();
            params.type = trip_plan_num_change_1.NUM_CHANGE_TYPE.CONSUME;
            params.companyId = this.id;
            params.number = 0 - number;
            let log = trip_plan_num_change_1.TripPlanNumChange.create(params);
            let account = yield _types_1.Models.staff.get(params.accountId);
            log.account = account;
            yield log.save();
            return result;
        });
    }
    /**
     * 增加行程审批通过条数
     * @param params
     * @returns {Company}
     */
    addTripPlanPassNum(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let number = 1;
            if (params && params.number) {
                number = params.number;
            }
            this.tripPlanPassNum = this.tripPlanPassNum + number;
            let result = yield this.save();
            params.type = trip_plan_num_change_1.NUM_CHANGE_TYPE.CONSUME;
            params.companyId = this.id;
            params.number = 0 - number;
            let log = trip_plan_num_change_1.TripPlanNumChange.create(params);
            let account = yield _types_1.Models.staff.get(params.accountId);
            log.account = account;
            yield log.save();
            return result;
        });
    }
    /**
     * 添加加油包
     * @param params
     * @returns {Company}
     */
    addPackage(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let number = params.number;
            let extraExpiryDate = params.extraExpiryDate;
            this.extraTripPlanNum = this.extraTripPlanNum + number;
            this.extraExpiryDate = extraExpiryDate;
            let result = yield this.save();
            params.type = trip_plan_num_change_1.NUM_CHANGE_TYPE.ADD_PACKAGE;
            params.companyId = this.id;
            let log = trip_plan_num_change_1.TripPlanNumChange.create(params);
            let account = yield _types_1.Models.staff.get(params.accountId);
            log.account = account;
            yield log.save();
            return result;
        });
    }
    /**
     * 够买套餐包
     * @param params
     * @returns {Company}
     */
    buyPackageBag(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let number = params.number;
            this.tripPlanNumLimit = number;
            let result = yield this.save();
            params.type = trip_plan_num_change_1.NUM_CHANGE_TYPE.PACKAGE_BAG;
            params.companyId = this.id;
            let log = trip_plan_num_change_1.TripPlanNumChange.create(params);
            let account = yield _types_1.Models.staff.get(params.accountId);
            log.account = account;
            yield log.save();
            return result;
        });
    }
    getTripPlanNumChanges(options) {
        if (!options) {
            options = {};
        }
        ;
        if (!options.where) {
            options.where = {};
        }
        ;
        options.where.companyId = this.id;
        options.where.isShowToUser = true;
        return _types_1.Models.tripPlanNumChange.find(options);
    }
    getDepartments(options) {
        if (!options) {
            options = {};
        }
        ;
        if (!options.where) {
            options.where = {};
        }
        ;
        options.where.companyId = this.id;
        return _types_1.Models.department.find(options);
    }
    getTravelPolicies() {
        let query = { where: { companyId: this.id } };
        return _types_1.Models.travelPolicy.find(query);
    }
    getDefaultTravelPolicy() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            var tps = yield _types_1.Models.travelPolicy.find({ where: { companyId: this.id, isDefault: true } });
            if (tps && tps.length > 0) {
                return tps[0];
            }
            else {
                tps = yield _types_1.Models.travelPolicy.find({ where: { companyId: this.id } });
                if (tps && tps.length) {
                    return tps[0];
                }
                let travelPolicy = travelPolicy_1.TravelPolicy.create({ name: '默认标准', planeLevels: [travelPolicy_1.EPlaneLevel.ECONOMY],
                    trainLevels: [travelPolicy_1.ETrainLevel.SECOND_SEAT], hotelLevels: [travelPolicy_1.EHotelLevel.THREE_STAR], subsidy: 0, isDefault: true });
                travelPolicy.company = self;
                travelPolicy = yield travelPolicy.save();
                return travelPolicy;
            }
        });
    }
    doPromoCode(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let promoCodes = yield _types_1.Models.promoCode.find({ where: { code: params.code } });
            if (promoCodes && promoCodes.length > 0) {
                let promoCode = promoCodes[0];
                if (promoCode.expiryDate && promoCode.expiryDate.getTime() - new Date().getTime() < 0) {
                    throw language_1.default.ERR.INVALID_PROMO_CODE();
                }
                let params = promoCode.params;
                params.companyId = this.id;
                let result = yield promoCodeType[promoCode.type].execute(params);
                let times = promoCode.times || 0;
                promoCode.times = times + 1;
                yield promoCode.save();
                return promoCode;
            }
            else {
                throw language_1.default.ERR.INVALID_PROMO_CODE();
            }
        });
    }
    getDefaultDepartment(companyId) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var depts = yield _types_1.Models.department.find({ where: { companyId: this.id, isDefault: true } });
            if (depts && depts.length > 0) {
                return depts[0];
            }
            else {
                return null;
            }
        });
    }
    getRootDepartment() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            var depts = yield _types_1.Models.department.find({ where: { companyId: this.id, parentId: null } });
            if (depts && depts.length > 0) {
                return depts[0];
            }
            else {
                let department = _types_1.Models.department.create({ name: self.name, companyId: self.id, parentId: null });
                return department.save();
            }
        });
    }
    getAllDepartmentStructure(companyId) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let departmentStructure = new Array();
            let m = new Array();
            let pagers = yield _types_1.Models.department.find({ where: { companyId: this.id }, order: [['created_at', 'desc']] });
            let departments = [];
            departments.push.apply(departments, pagers);
            while (pagers.hasNextPage()) {
                let nextPager = yield pagers.nextPage();
                departments.push.apply(departments, nextPager);
                // pagers = nextPager;
            }
            for (let i = 0; i < departments.length; i++) {
                let t = departments[i];
                t["childDepartments"] = new Array();
                m.push(t);
            }
            for (let i = 0; i < m.length; i++) {
                if (!m[i].parent || !m[i].parent.id) {
                    dg(m[i], m);
                    departmentStructure.push(m[i]);
                }
            }
            return departmentStructure;
        });
    }
    getTripPlans(options) {
        if (!options) {
            options = { where: {} };
        }
        ;
        if (!options.where) {
            options.where = {};
        }
        options.where.companyId = this.id;
        if (options.where.startTime) {
            if (!options.where.startAt) {
                options.where.startAt = {};
            }
            options.where.startAt.$gte = options.where.startTime;
            delete options.where.startTime;
        }
        if (options.where.endTime) {
            if (!options.where.startAt) {
                options.where.startAt = {};
            }
            options.where.startAt.$lte = options.where.endTime;
            delete options.where.endTime;
        }
        return _types_1.Models.tripPlan.find(options);
    }
    getMoneyChanges(companyId) {
        return _types_1.Models.moneyChange.find({ where: { companyId: this.id } });
    }
    statisticTripPlanOfMonth(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            params['companyId'] = this.id;
            if (!this.isLocal) {
                API.require('tripPlan');
                yield API.onload();
            }
            return API.tripPlan.statisticTripPlanOfMonth(params);
        });
    }
    getCompanySuppliers(options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!options) {
                options = {};
            }
            ;
            if (!options.where) {
                options.where = {};
            }
            ;
            options.where.companyId = this.id;
            return _types_1.Models.supplier.find(options);
        });
    }
    getAppointedSuppliers(options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!options) {
                options = {};
            }
            ;
            if (!options.where) {
                options.where = {};
            }
            ;
            options.where.companyId = this.id;
            options.where.isInUse = true;
            var suppliers = yield _types_1.Models.supplier.find(options);
            var company = yield _types_1.Models.company.get(this.id);
            if (company && company.appointedPubilcSuppliers && company.appointedPubilcSuppliers.length > 0) {
                var ps = JSON.parse(company.appointedPubilcSuppliers).map(function (s) {
                    return tslib_1.__awaiter(this, void 0, void 0, function* () {
                        var su = yield _types_1.Models.supplier.get(s);
                        if (su) {
                            suppliers.push(su);
                        }
                    });
                });
                yield Promise.all(ps);
            }
            return suppliers;
        });
    }
    changeOA(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let { oa } = params;
            let self = this;
            if (this.oa == oa) {
                return this;
            }
            //查询是否有未完成的审批
            let approves = yield _types_1.Models.approve.find({ where: { status: types_1.EApproveStatus.WAIT_APPROVE, companyId: self.id }, limit: 200 });
            let ps = approves.map((item) => {
                emitter_1.emitter.emit(index_1.EVENT.APPROVE_FAIL, { approveId: item.id, oa: oaEnum2Str(self.oa), type: types_1.EApproveType.TRAVEL_BUDGET, reason: '切换审批流,自动驳回' });
                item.status = types_1.EApproveStatus.FAIL;
                return item.save();
            });
            yield Promise.all(ps);
            this.oa = oa;
            return this.save();
        });
    }
    getManagers(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            let roles = [staff_2.EStaffRole.ADMIN];
            if (params && params.withOwner) {
                roles.push(staff_2.EStaffRole.OWNER);
            }
            let managers = [];
            let pager = yield self.getStaffs({
                where: {
                    roleId: {
                        $in: roles,
                    }
                }
            });
            pager.forEach((manager) => {
                managers.push(manager);
            });
            while (pager && pager.hasNextPage()) {
                pager = yield pager.nextPage();
                pager.forEach((manager) => {
                    managers.push(manager);
                });
            }
            return managers;
        });
    }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], Company.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(30) })
], Company.prototype, "companyNo", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], Company.prototype, "createUser", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Company.prototype, "name", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Company.prototype, "domainName", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Company.prototype, "description", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], Company.prototype, "status", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Company.prototype, "email", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Company.prototype, "mobile", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], Company.prototype, "staffNum", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], Company.prototype, "staffScore", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Company.prototype, "remark", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Company.prototype, "paymentPwd", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.NUMERIC(15, 2) })
], Company.prototype, "income", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.NUMERIC(15, 2) })
], Company.prototype, "consume", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.NUMERIC(15, 2) })
], Company.prototype, "frozen", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.NUMERIC(15, 2) })
], Company.prototype, "staffReward", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], Company.prototype, "isSetPwd", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN, defaultValue: true })
], Company.prototype, "isApproveOpen", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(50), defaultValue: 'default' })
], Company.prototype, "budgetPolicy", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(50) })
], Company.prototype, "getNoticeEmail", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.JSONB, defaultValue: '{}' })
], Company.prototype, "budgetConfig", null);
tslib_1.__decorate([
    common_1.Reference({ type: model_1.Types.UUID })
], Company.prototype, "getAgency", null);
tslib_1.__decorate([
    common_1.ResolveRef({ type: model_1.Types.UUID }, _types_1.Models.coinAccount)
], Company.prototype, "coinAccount", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.NUMERIC(10, 2) })
], Company.prototype, "points2coinRate", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.JSONB, defaultValue: '[]' })
], Company.prototype, "appointedPubilcSuppliers", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN, defaultValue: false })
], Company.prototype, "isAppointSupplier", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], Company.prototype, "oa", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DATE })
], Company.prototype, "expiryDate", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER, defaultValue: 5 })
], Company.prototype, "staffNumLimit", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER, defaultValue: 60 })
], Company.prototype, "tripPlanNumLimit", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER, defaultValue: 0 })
], Company.prototype, "tripPlanPassNum", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER, defaultValue: 0 })
], Company.prototype, "tripPlanFrozenNum", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER, defaultValue: 0 })
], Company.prototype, "extraTripPlanFrozenNum", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER, defaultValue: 0 })
], Company.prototype, "extraTripPlanNum", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DATE })
], Company.prototype, "extraExpiryDate", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], Company.prototype, "tripPackageId", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], Company.prototype, "type", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Company.prototype, "getStaffNum", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Company.prototype, "beforeGoTrip", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Company.prototype, "beforeApproveTrip", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Company.prototype, "frozenTripPlanNum", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Company.prototype, "approvePassReduceTripPlanNum", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Company.prototype, "approvePassReduceBeforeNum", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Company.prototype, "approveRejectFreeTripPlanNum", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Company.prototype, "approveRejectFreeBeforeNum", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Company.prototype, "freeFrozenTripPlanNum", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Company.prototype, "reduceExtraTripPlanNum", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Company.prototype, "addTripPlanPassNum", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Company.prototype, "addPackage", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Company.prototype, "buyPackageBag", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Company.prototype, "doPromoCode", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Company.prototype, "getRootDepartment", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Company.prototype, "changeOA", null);
tslib_1.__decorate([
    common_1.Create()
], Company, "create", null);
Company = tslib_1.__decorate([
    common_1.Table(_types_1.Models.company, 'company.')
], Company);
exports.Company = Company;
//p为父菜单节点。o为菜单列表
function dg(p, o) {
    for (var i = 0; i < o.length; i++) {
        var t = o[i];
        if (t.parent && t.parent.id == p.id) {
            if (!p.childDepartments) {
                p.childDepartments = [];
            }
            p.childDepartments.push(t);
            dg(t, o);
        }
    }
}
function oaEnum2Str(e) {
    let obj = {};
    obj[types_1.EApproveChannel.QM] = 'qm';
    obj[types_1.EApproveChannel.AUTO] = 'auto';
    obj[types_1.EApproveChannel.DING_TALK] = 'ddtalk';
    return obj[e];
}

//# sourceMappingURL=company.js.map
