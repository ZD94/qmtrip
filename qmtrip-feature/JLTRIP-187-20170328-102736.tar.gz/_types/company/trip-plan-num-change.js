"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const common_1 = require("common/model/common");
const _types_1 = require("_types");
const object_1 = require("common/model/object");
const model_1 = require("common/model");
var NUM_CHANGE_TYPE;
(function (NUM_CHANGE_TYPE) {
    NUM_CHANGE_TYPE[NUM_CHANGE_TYPE["ADD_PACKAGE"] = 1] = "ADD_PACKAGE";
    NUM_CHANGE_TYPE[NUM_CHANGE_TYPE["PACKAGE_BAG"] = 2] = "PACKAGE_BAG";
    NUM_CHANGE_TYPE[NUM_CHANGE_TYPE["CONSUME"] = 3] = "CONSUME";
    NUM_CHANGE_TYPE[NUM_CHANGE_TYPE["FROZEN"] = 4] = "FROZEN";
    NUM_CHANGE_TYPE[NUM_CHANGE_TYPE["FREE_FROZEN"] = 5] = "FREE_FROZEN";
    NUM_CHANGE_TYPE[NUM_CHANGE_TYPE["SYSTEM_ADD"] = 6] = "SYSTEM_ADD";
    NUM_CHANGE_TYPE[NUM_CHANGE_TYPE["SYSTEM_REDUCE"] = 7] = "SYSTEM_REDUCE";
})(NUM_CHANGE_TYPE = exports.NUM_CHANGE_TYPE || (exports.NUM_CHANGE_TYPE = {}));
let TripPlanNumChange = class TripPlanNumChange extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(id) { }
    get companyId() { return null; }
    set companyId(id) { }
    get tripPlanId() { return null; }
    set tripPlanId(id) { }
    get account() { return null; }
    set account(val) { }
    get type() { return NUM_CHANGE_TYPE.ADD_PACKAGE; }
    set type(type) { }
    set number(coins) { }
    get number() { return 0; }
    set remark(remark) { }
    get remark() { return ''; }
    set content(content) { }
    get content() { return ''; }
    set isShowToUser(remark) { }
    get isShowToUser() { return ''; }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], TripPlanNumChange.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], TripPlanNumChange.prototype, "companyId", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], TripPlanNumChange.prototype, "tripPlanId", null);
tslib_1.__decorate([
    common_1.ResolveRef({ type: model_1.Types.UUID }, _types_1.Models.staff)
], TripPlanNumChange.prototype, "account", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], TripPlanNumChange.prototype, "type", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER, defaultValue: 0 })
], TripPlanNumChange.prototype, "number", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.TEXT })
], TripPlanNumChange.prototype, "remark", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.TEXT })
], TripPlanNumChange.prototype, "content", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN, defaultValue: true })
], TripPlanNumChange.prototype, "isShowToUser", null);
tslib_1.__decorate([
    common_1.Create()
], TripPlanNumChange, "create", null);
TripPlanNumChange = tslib_1.__decorate([
    common_1.Table(_types_1.Models.tripPlanNumChange, "company.trip_plan_num_changes")
], TripPlanNumChange);
exports.TripPlanNumChange = TripPlanNumChange;

//# sourceMappingURL=trip-plan-num-change.js.map
