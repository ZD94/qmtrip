/**
 * Created by wlh on 16/6/28.
 */
'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const object_1 = require("common/model/object");
const common_1 = require("common/model/common");
const index_1 = require("./index");
const model_1 = require("common/model");
var TRAFFIC;
(function (TRAFFIC) {
    TRAFFIC[TRAFFIC["TRAIN"] = 0] = "TRAIN";
    TRAFFIC[TRAFFIC["FLIGHT"] = 1] = "FLIGHT";
})(TRAFFIC = exports.TRAFFIC || (exports.TRAFFIC = {}));
//记录预算分析数据及结果
let TravelBudgetLog = class TravelBudgetLog extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    ;
    set id(id) { }
    //便于调试时选择
    get title() { return null; }
    set title(title) { }
    get query() { return null; }
    ;
    set query(query) { }
    get prefers() { return null; }
    ;
    set prefers(prefers) { }
    get originData() { return null; }
    set originData(data) { }
    get markedData() { return null; }
    set markedData(data) { }
    get result() { return null; }
    ;
    set result(result) { }
    get type() { return 1; }
    ;
    set type(t) { }
    get status() { return 0; }
    set status(status) { }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], TravelBudgetLog.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(255) })
], TravelBudgetLog.prototype, "title", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.JSONB })
], TravelBudgetLog.prototype, "query", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.JSONB })
], TravelBudgetLog.prototype, "prefers", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.JSONB })
], TravelBudgetLog.prototype, "originData", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.JSONB })
], TravelBudgetLog.prototype, "markedData", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.JSONB })
], TravelBudgetLog.prototype, "result", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], TravelBudgetLog.prototype, "type", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], TravelBudgetLog.prototype, "status", null);
tslib_1.__decorate([
    common_1.Create()
], TravelBudgetLog, "create", null);
TravelBudgetLog = tslib_1.__decorate([
    common_1.Table(index_1.Models.travelBudgetLog, "travelbudget.travel_budget_log")
], TravelBudgetLog);
exports.TravelBudgetLog = TravelBudgetLog;

//# sourceMappingURL=travelbudget.js.map
