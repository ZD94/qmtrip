"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const model_1 = require("common/model");
const common_1 = require("common/model/common");
const _types_1 = require("_types");
const object_1 = require("common/model/object");
const staff_1 = require("_types/staff");
const moment = require("moment");
var ENoticeType;
(function (ENoticeType) {
    ENoticeType[ENoticeType["SYSTEM_NOTICE"] = 1] = "SYSTEM_NOTICE";
    ENoticeType[ENoticeType["TRIP_APPROVE_NOTICE"] = 2] = "TRIP_APPROVE_NOTICE";
    ENoticeType[ENoticeType["TRIP_APPLY_NOTICE"] = 3] = "TRIP_APPLY_NOTICE";
    ENoticeType[ENoticeType["ACTIVITY_NOTICE"] = 4] = "ACTIVITY_NOTICE";
})(ENoticeType = exports.ENoticeType || (exports.ENoticeType = {}));
;
var ESendType;
(function (ESendType) {
    ESendType[ESendType["ONE_ACCOUNT"] = 1] = "ONE_ACCOUNT";
    ESendType[ESendType["MORE_ACCOUNT"] = 2] = "MORE_ACCOUNT";
    ESendType[ESendType["ALL_ACCOUNT"] = 3] = "ALL_ACCOUNT";
})(ESendType = exports.ESendType || (exports.ESendType = {}));
;
let Notice = class Notice extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(val) { }
    get title() { return null; }
    set title(val) { }
    get content() { return null; }
    set content(val) { }
    get description() { return null; }
    set description(val) { }
    get link() { return null; }
    set link(val) { }
    get type() { return ENoticeType.SYSTEM_NOTICE; }
    set type(val) { }
    get sendType() { return ESendType.ONE_ACCOUNT; }
    set sendType(val) { }
    get picture() { return null; }
    set picture(val) { }
    get toUsers() { return null; }
    ;
    set toUsers(val) { }
    /************************预计无用字段****************************/
    get isSend() { return true; }
    set isSend(val) { }
    get sendTime() { return null; }
    set sendTime(val) { }
    /************************预计无用字段****************************/
    sendNotice() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            /*if(!this.isLocal){
                API.require('jpush');
                await API.onload();
            }*/
            var notice = yield _types_1.Models.notice.get(this.id);
            notice.isSend = true;
            notice.sendTime = moment().toDate();
            var result = yield notice.save();
            // var jpushId = JPush.ALL;
            // await API.jpush.pushAppMessage({content: result.description, title: result.title, link: null, jpushId: jpushId});
            return result;
        });
    }
    staffDeleteNotice() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var staff = yield staff_1.Staff.getCurrent();
            var noticeAccount = yield _types_1.Models.noticeAccount.find({ where: { accountId: staff.id, noticeId: this.id } });
            if (noticeAccount && noticeAccount.length > 0) {
                yield noticeAccount[0].destroy();
            }
            return true;
        });
    }
    setReadStatus() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var staff = yield staff_1.Staff.getCurrent();
            var result;
            var noticeAccounts = yield _types_1.Models.noticeAccount.find({ where: { accountId: staff.id, noticeId: this.id } });
            if (noticeAccounts && noticeAccounts.length > 0 && !noticeAccounts[0].isRead) {
                result = noticeAccounts[0];
                result.isRead = true;
                result.readTime = new Date();
                result = yield result.save();
            }
            return result;
        });
    }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], Notice.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Notice.prototype, "title", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.TEXT })
], Notice.prototype, "content", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.TEXT })
], Notice.prototype, "description", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Notice.prototype, "link", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER, defaultValue: ENoticeType.SYSTEM_NOTICE })
], Notice.prototype, "type", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER, defaultValue: ESendType.ONE_ACCOUNT })
], Notice.prototype, "sendType", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Notice.prototype, "picture", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.JSONB })
], Notice.prototype, "toUsers", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN, defaultValue: true })
], Notice.prototype, "isSend", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DATE })
], Notice.prototype, "sendTime", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Notice.prototype, "sendNotice", null);
tslib_1.__decorate([
    common_1.Create()
], Notice, "create", null);
Notice = tslib_1.__decorate([
    common_1.Table(_types_1.Models.notice, "notice.")
], Notice);
exports.Notice = Notice;

//# sourceMappingURL=notice.js.map
