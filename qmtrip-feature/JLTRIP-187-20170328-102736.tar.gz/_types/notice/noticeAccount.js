/**
 * Created by wangyali on 2016/11/28.
 */
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const model_1 = require("common/model");
const common_1 = require("common/model/common");
const _types_1 = require("_types");
const object_1 = require("common/model/object");
let NoticeAccount = class NoticeAccount extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(val) { }
    //员工id
    get accountId() { return null; }
    set accountId(val) { }
    //通知id
    get noticeId() { return null; }
    set noticeId(val) { }
    //阅读状态
    get isRead() { return false; }
    set isRead(val) { }
    //阅读时间
    get readTime() { return null; }
    set readTime(val) { }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], NoticeAccount.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], NoticeAccount.prototype, "accountId", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], NoticeAccount.prototype, "noticeId", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN, defaultValue: false })
], NoticeAccount.prototype, "isRead", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DATE })
], NoticeAccount.prototype, "readTime", null);
tslib_1.__decorate([
    common_1.Create()
], NoticeAccount, "create", null);
NoticeAccount = tslib_1.__decorate([
    common_1.Table(_types_1.Models.noticeAccount, "notice.")
], NoticeAccount);
exports.NoticeAccount = NoticeAccount;

//# sourceMappingURL=noticeAccount.js.map
