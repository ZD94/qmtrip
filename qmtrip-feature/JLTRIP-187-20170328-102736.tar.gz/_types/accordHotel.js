"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const _types_1 = require("_types");
const model_1 = require("common/model");
const common_1 = require("common/model/common");
const object_1 = require("common/model/object");
let AccordHotel = class AccordHotel extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(val) { }
    //协议价格
    get accordPrice() { return null; }
    set accordPrice(value) { }
    //城市名称
    get cityName() { return null; }
    set cityName(val) { }
    //城市代码
    get cityCode() { return null; }
    set cityCode(val) { }
    //所属企业
    get company() { return null; }
    set company(val) { }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], AccordHotel.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.NUMERIC(15, 2) })
], AccordHotel.prototype, "accordPrice", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(50) })
], AccordHotel.prototype, "cityName", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(50) })
], AccordHotel.prototype, "cityCode", null);
tslib_1.__decorate([
    common_1.ResolveRef({ type: model_1.Types.UUID }, _types_1.Models.company)
], AccordHotel.prototype, "company", null);
tslib_1.__decorate([
    common_1.Create()
], AccordHotel, "create", null);
AccordHotel = tslib_1.__decorate([
    common_1.Table(_types_1.Models.accordHotel, "accordHotel.")
], AccordHotel);
exports.AccordHotel = AccordHotel;

//# sourceMappingURL=accordHotel.js.map
