/**
 * Created by chen on 2017/3/22.
 */
//包含的条数
//有效期 days 3个月,1年的
//名称
// ID
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const common_1 = require("common/model/common");
const _types_1 = require("_types");
const object_1 = require("common/model/object");
const model_1 = require("common/model");
let TripFuelAddPackage = class TripFuelAddPackage extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(id) { }
    get name() { return null; }
    set name(name) { }
    get tripNum() { return 0; }
    set tripNum(num) { }
    get validDays() { return 30; }
    set validDays(days) { }
    get price() { return 0; }
    set price(price) { }
    get remark() { return null; }
    set remark(remark) { }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], TripFuelAddPackage.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.TEXT })
], TripFuelAddPackage.prototype, "name", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.NUMERIC(15, 2) })
], TripFuelAddPackage.prototype, "tripNum", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.NUMERIC(15, 2) })
], TripFuelAddPackage.prototype, "validDays", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.NUMERIC(15, 2) })
], TripFuelAddPackage.prototype, "price", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.TEXT })
], TripFuelAddPackage.prototype, "remark", null);
tslib_1.__decorate([
    common_1.Create()
], TripFuelAddPackage, "create", null);
TripFuelAddPackage = tslib_1.__decorate([
    common_1.Table(_types_1.Models.tripFuelAddPackage, "tripPackage.")
], TripFuelAddPackage);
exports.TripFuelAddPackage = TripFuelAddPackage;

//# sourceMappingURL=tripFuelAddPackage.js.map
