/**
 * Created by chen on 2017/3/22.
 */
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
// 每月包含行程数
// 名称
// ID
const common_1 = require("common/model/common");
const _types_1 = require("_types");
const object_1 = require("common/model/object");
const model_1 = require("common/model");
let TripBasicPackage = class TripBasicPackage extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(id) { }
    get name() { return null; }
    set name(name) { }
    get tripNum() { return 0; }
    set tripNum(num) { }
    get price() { return 0; }
    set price(price) { }
    get remark() { return null; }
    set remark(remark) { }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], TripBasicPackage.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.TEXT })
], TripBasicPackage.prototype, "name", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.NUMERIC(15, 2) })
], TripBasicPackage.prototype, "tripNum", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.NUMERIC(15, 2) })
], TripBasicPackage.prototype, "price", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.TEXT })
], TripBasicPackage.prototype, "remark", null);
tslib_1.__decorate([
    common_1.Create()
], TripBasicPackage, "create", null);
TripBasicPackage = tslib_1.__decorate([
    common_1.Table(_types_1.Models.tripBasicPackage, "tripPackage.")
], TripBasicPackage);
exports.TripBasicPackage = TripBasicPackage;

//# sourceMappingURL=tripBasicPackage.js.map
