"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const helper_1 = require("common/api/helper");
let Place = class Place {
    constructor(obj) {
        this.id = obj.id;
        this.name = obj.name;
        this.skyCode = obj.skyCode;
        this.baiduCode = obj.baiduCode;
        this.pinyin = obj.pinyin;
        this.letter = obj.letter;
        this.latitude = obj.latitude;
        this.longitude = obj.longitude;
        this.type = obj.type;
        this.cityLevel = obj.cityLevel;
        this.didaCode = obj.didaCode;
        this.parentId = obj.parentId;
        this.isAbroad = obj.isAbroad;
        this.enName = obj.enName;
    }
};
Place = tslib_1.__decorate([
    helper_1.regApiType('API.')
], Place);
exports.Place = Place;
let AirCompany = class AirCompany {
    constructor(obj) {
        this.id = obj.id;
        this.name = obj.name;
        this.code = obj.code;
        this.shortname = obj.shortname;
    }
};
AirCompany = tslib_1.__decorate([
    helper_1.regApiType('API.')
], AirCompany);
exports.AirCompany = AirCompany;
let Airport = class Airport {
    constructor(obj) {
        this.id = obj.id;
        this.name = obj.name;
        this.cityId = obj.cityId;
        this.skyCode = obj.skyCode;
        this.latitude = obj.latitude;
        this.longitude = obj.longitude;
    }
};
Airport = tslib_1.__decorate([
    helper_1.regApiType('API.')
], Airport);
exports.Airport = Airport;

//# sourceMappingURL=place.js.map
