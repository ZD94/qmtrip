"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const _types_1 = require("_types");
const common_1 = require("common/model/common");
const object_1 = require("common/model/object");
const model_1 = require("common/model");
const _ = require("lodash");
let db = require("common/model").DB;
let API = require("common/api");
let Department = class Department extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(val) { }
    get code() { return null; }
    set code(code) { }
    get name() { return null; }
    set name(name) { }
    get isDefault() { return false; }
    set isDefault(isDefault) { }
    get parent() { return null; }
    set parent(val) { }
    get manager() { return null; }
    set manager(val) { }
    get company() { return null; }
    set company(val) { }
    getStaffs(options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let staffs = yield API.department.getStaffs({ id: this.id, options: options });
            return staffs;
        });
    }
    getAllStaffNum() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!this.isLocal) {
                API.require('department');
                yield API.onload();
            }
            return API.department.getAllStaffNum({ departmentId: this.id });
        });
    }
    getChildDepartments() {
        return _types_1.Models.department.find({ where: { parentId: this.id, companyId: this.company.id }, order: [['createdAt', 'desc']] });
    }
    getChildDeptStaffNum() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            // console.log(this.id , this.company.id)
            let pagers = yield _types_1.Models.department.find({ where: { parentId: this.id, companyId: self['companyId'] }, order: [['createdAt', 'desc']] });
            let childDepartments = [];
            childDepartments.push.apply(childDepartments, pagers);
            while (pagers.hasNextPage()) {
                let nextPager = yield pagers.nextPage();
                childDepartments.push.apply(childDepartments, nextPager);
            }
            let ps = childDepartments.map((d) => tslib_1.__awaiter(this, void 0, void 0, function* () {
                d['staffNum'] = yield d.getStaffNum();
                return d;
            }));
            let departments = yield Promise.all(ps);
            return departments;
        });
    }
    getAllChildren() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            let pager = yield _types_1.Models.department.find({ where: { parentId: self.id, companyId: self['companyId'] } });
            let children = [];
            let allChildren = [];
            do {
                if (pager) {
                    pager.forEach((d) => {
                        children.push(d);
                    });
                    pager = yield pager.nextPage();
                }
            } while (pager && pager.hasNextPage());
            //查找children所有的子元素
            for (let i, ii = children.length; i < ii; i++) {
                allChildren = _.concat(allChildren, yield children[i].getAllChildren());
            }
            return allChildren;
        });
    }
    //获取当前部门以及所有子部门下的总人数
    getStaffNum() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            let total = 0;
            let sql = `
         select count(1) as total from (
            select distinct staff_id from department.staff_departments as SD
            where SD.department_id in
                (
                    with RECURSIVE d as
                    (
                    select d1.id from department.departments as d1 where id = '${self.id}' AND deleted_at is null
                    union all
                    select d2.id from department.departments as d2
                    inner join d on d.id = d2.parent_id
                    where d2.deleted_at is null
                    ) select id from d
                ) AND SD.deleted_at is null
        ) as R;
        `;
            let ret = yield db.query(sql);
            return ret[0][0]['total'];
        });
    }
    getOneDepartmentStructure() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let department = yield _types_1.Models.department.get(this.id);
            let departmentStructure = new Array();
            let m = new Array();
            let pagers = yield _types_1.Models.department.find({ where: { companyId: this.company.id }, order: [['created_at', 'desc']] });
            let departments = [];
            departments.push.apply(departments, pagers);
            while (pagers.hasNextPage()) {
                let nextPager = yield pagers.nextPage();
                departments.push.apply(departments, nextPager);
                // pagers = nextPager;
            }
            for (let i = 0; i < departments.length; i++) {
                let t = departments[i];
                t["childDepartments"] = new Array();
                m.push(t);
            }
            dg(department, m);
            departmentStructure.push(department);
            return departmentStructure;
        });
    }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], Department.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(50) })
], Department.prototype, "code", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(50) })
], Department.prototype, "name", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], Department.prototype, "isDefault", null);
tslib_1.__decorate([
    common_1.ResolveRef({ type: model_1.Types.UUID }, _types_1.Models.department)
], Department.prototype, "parent", null);
tslib_1.__decorate([
    common_1.ResolveRef({ type: model_1.Types.UUID }, _types_1.Models.staff)
], Department.prototype, "manager", null);
tslib_1.__decorate([
    common_1.ResolveRef({ type: model_1.Types.UUID }, _types_1.Models.company)
], Department.prototype, "company", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Department.prototype, "getStaffs", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Department.prototype, "getAllStaffNum", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Department.prototype, "getChildDepartments", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Department.prototype, "getAllChildren", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Department.prototype, "getStaffNum", null);
tslib_1.__decorate([
    common_1.Create()
], Department, "create", null);
Department = tslib_1.__decorate([
    common_1.Table(_types_1.Models.department, "department.")
], Department);
exports.Department = Department;
//p为父菜单节点。o为菜单列表
function dg(p, o) {
    for (var i = 0; i < o.length; i++) {
        var t = o[i];
        if (t.parent && t.parent.id == p.id) {
            if (!p.childDepartments) {
                p.childDepartments = [];
            }
            p.childDepartments.push(t);
            dg(t, o);
        }
    }
}

//# sourceMappingURL=department.js.map
