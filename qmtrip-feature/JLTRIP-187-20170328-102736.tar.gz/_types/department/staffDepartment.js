/**
 * Created by wangyali on 2017/01/13.
 */
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const model_1 = require("common/model");
const common_1 = require("common/model/common");
const _types_1 = require("_types");
const object_1 = require("common/model/object");
let StaffDepartment = class StaffDepartment extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(val) { }
    //员工id
    get staffId() { return null; }
    set staffId(val) { }
    //通知id
    get departmentId() { return null; }
    set departmentId(val) { }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], StaffDepartment.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], StaffDepartment.prototype, "staffId", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], StaffDepartment.prototype, "departmentId", null);
tslib_1.__decorate([
    common_1.Create()
], StaffDepartment, "create", null);
StaffDepartment = tslib_1.__decorate([
    common_1.Table(_types_1.Models.staffDepartment, "department.")
], StaffDepartment);
exports.StaffDepartment = StaffDepartment;

//# sourceMappingURL=staffDepartment.js.map
