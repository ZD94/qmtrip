/**
 * Created by yumiao on 16-5-17.
 */
'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const _types_1 = require("_types");
const common_1 = require("common/model/common");
const object_1 = require("common/model/object");
const model_1 = require("common/model");
let Seed = class Seed extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get type() { return ''; }
    set type(val) { }
    get minNo() { return 0; }
    set minNo(val) { }
    get maxNo() { return 0; }
    set maxNo(val) { }
    get nowNo() { return 0; }
    set nowNo(val) { }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Seed.prototype, "type", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], Seed.prototype, "minNo", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], Seed.prototype, "maxNo", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], Seed.prototype, "nowNo", null);
tslib_1.__decorate([
    common_1.Create()
], Seed, "create", null);
Seed = tslib_1.__decorate([
    common_1.Table(_types_1.Models.seed, 'seeds.')
], Seed);
exports.Seed = Seed;

//# sourceMappingURL=seed.js.map
