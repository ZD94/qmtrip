/**
 * Created by wlh on 16/9/8.
 */
'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const object_1 = require("common/model/object");
const common_1 = require("common/model/common");
const index_1 = require("./index");
const model_1 = require("common/model");
let DDTalkCorp = class DDTalkCorp extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(id) { }
    getCompany(id) {
        return index_1.Models.company.get(id);
    }
    get corpId() { return null; }
    ;
    set corpId(corpId) { }
    get permanentCode() { return null; }
    ;
    set permanentCode(code) { }
    get isSuiteRelieve() { return false; }
    ;
    set isSuiteRelieve(val) { }
    get agentid() { return ''; }
    set agentid(id) { }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], DDTalkCorp.prototype, "id", null);
tslib_1.__decorate([
    common_1.Reference({ type: model_1.Types.UUID })
], DDTalkCorp.prototype, "getCompany", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(50) })
], DDTalkCorp.prototype, "corpId", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(255) })
], DDTalkCorp.prototype, "permanentCode", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], DDTalkCorp.prototype, "isSuiteRelieve", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(20) })
], DDTalkCorp.prototype, "agentid", null);
tslib_1.__decorate([
    common_1.Create()
], DDTalkCorp, "create", null);
DDTalkCorp = tslib_1.__decorate([
    common_1.Table(index_1.Models.ddtalkCorp, "ddtalk.corps")
], DDTalkCorp);
exports.DDTalkCorp = DDTalkCorp;
let DDTalkDepartment = class DDTalkDepartment extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(id) { }
    //local department id
    get localDepartmentId() { return null; }
    set localDepartmentId(val) { }
    //dd department id
    get DdDepartmentId() { return null; }
    set DdDepartmentId(val) { }
    //dd corpId
    get corpId() { return null; }
    ;
    set corpId(corpId) { }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], DDTalkDepartment.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], DDTalkDepartment.prototype, "localDepartmentId", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], DDTalkDepartment.prototype, "DdDepartmentId", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(50) })
], DDTalkDepartment.prototype, "corpId", null);
tslib_1.__decorate([
    common_1.Create()
], DDTalkDepartment, "create", null);
DDTalkDepartment = tslib_1.__decorate([
    common_1.Table(index_1.Models.ddtalkDepartment, "ddtalk.department")
], DDTalkDepartment);
exports.DDTalkDepartment = DDTalkDepartment;
let DDTalkUser = class DDTalkUser extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(id) { }
    get ddUserId() { return null; }
    ;
    set ddUserId(userId) { }
    get dingId() { return null; }
    set dingId(dingId) { }
    get isAdmin() { return false; }
    set isAdmin(isAdmin) { }
    get avatar() { return null; }
    set avatar(avatar) { }
    get name() { return null; }
    ;
    set name(name) { }
    get corpid() { return null; }
    set corpid(corpid) { }
    // '获取到的钉钉信息'
    get ddInfo() { return ''; }
    set ddInfo(val) { }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], DDTalkUser.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(50) })
], DDTalkUser.prototype, "ddUserId", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(50) })
], DDTalkUser.prototype, "dingId", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], DDTalkUser.prototype, "isAdmin", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.TEXT })
], DDTalkUser.prototype, "avatar", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(50) })
], DDTalkUser.prototype, "name", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(50) })
], DDTalkUser.prototype, "corpid", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.TEXT })
], DDTalkUser.prototype, "ddInfo", null);
tslib_1.__decorate([
    common_1.Create()
], DDTalkUser, "create", null);
DDTalkUser = tslib_1.__decorate([
    common_1.Table(index_1.Models.ddtalkUser, "ddtalk.users")
], DDTalkUser);
exports.DDTalkUser = DDTalkUser;

//# sourceMappingURL=ddtalk.js.map
