/**
 * Created by wlh on 2016/10/19.
 */
'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const object_1 = require("common/model/object");
const index_1 = require("common/model/index");
const tripPlan_1 = require("./tripPlan");
const common_1 = require("common/model/common");
const index_2 = require("../index");
const tripDetail_1 = require("./tripDetail");
let TripDetailTraffic = class TripDetailTraffic extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    get id() { return index_1.Values.UUIDV1(); }
    set id(id) { }
    //出发时间(发车或起飞时间)
    get deptDateTime() { return null; }
    set deptDateTime(d) { }
    //最晚到达时间（到达时间）
    get arrivalDateTime() { return null; }
    set arrivalDateTime(d) { }
    //预算出发时间
    get leaveDate() { return null; }
    set leaveDate(d) { }
    get cabin() { return null; }
    set cabin(cabin) { }
    get invoiceType() { return null; }
    set invoiceType(type) { }
    get deptCity() { return null; }
    set deptCity(deptCity) { }
    get arrivalCity() { return null; }
    set arrivalCity(arrivalCity) { }
    uploadInvoice(params) {
        return API.tripPlan.uploadInvoice({ tripDetailId: this.id, pictureFileId: params.pictureFileId });
    }
    getInvoices() {
        let self = this;
        return index_2.Models.tripDetailInvoice.find({ where: { tripDetailId: self.id } });
    }
    auditPlanInvoice(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!this.isLocal) {
                API.require('tripPlan');
                yield API.onload();
            }
            params['id'] = this.id;
            return API.tripPlan.auditPlanInvoice(params);
        });
    }
    getBookLink(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var supplier = yield index_2.Models.supplier.get(params.supplierId);
            return supplier.getBookLink({ reserveType: params.reserveType, fromCity: this.deptCity, toCity: this.arrivalCity, leaveDate: this.deptDateTime });
        });
    }
};
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.UUID })
], TripDetailTraffic.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.DATE })
], TripDetailTraffic.prototype, "deptDateTime", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.DATE })
], TripDetailTraffic.prototype, "arrivalDateTime", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.DATE })
], TripDetailTraffic.prototype, "leaveDate", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.INTEGER })
], TripDetailTraffic.prototype, "cabin", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.INTEGER })
], TripDetailTraffic.prototype, "invoiceType", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.STRING(10) })
], TripDetailTraffic.prototype, "deptCity", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.STRING(50) })
], TripDetailTraffic.prototype, "arrivalCity", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], TripDetailTraffic.prototype, "getBookLink", null);
TripDetailTraffic = tslib_1.__decorate([
    common_1.TableExtends(tripDetail_1.TripDetail, 'tripDetailInfo', 'type', [tripPlan_1.ETripType.OUT_TRIP, tripPlan_1.ETripType.BACK_TRIP]),
    common_1.Table(index_2.Models.tripDetailTraffic, "tripPlan.")
], TripDetailTraffic);
exports.TripDetailTraffic = TripDetailTraffic;
let TripDetailHotel = class TripDetailHotel extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    get id() { return index_1.Values.UUIDV1(); }
    set id(id) { }
    get checkInDate() { return null; }
    set checkInDate(d) { }
    get checkOutDate() { return null; }
    set checkOutDate(d) { }
    get city() { return null; }
    set city(city) { }
    get name() { return null; }
    set name(name) { }
    get placeName() { return null; }
    set placeName(placeName) { }
    get position() { return null; }
    set position(p) { }
    uploadInvoice(params) {
        return API.tripPlan.uploadInvoice({ tripDetailId: this.id, pictureFileId: params.pictureFileId });
    }
    getInvoices() {
        let self = this;
        return index_2.Models.tripDetailInvoice.find({ where: { tripDetailId: self.id } });
    }
    auditPlanInvoice(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!this.isLocal) {
                API.require('tripPlan');
                yield API.onload();
            }
            params['id'] = this.id;
            return API.tripPlan.auditPlanInvoice(params);
        });
    }
    getBookLink(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var supplier = yield index_2.Models.supplier.get(params.supplierId);
            return supplier.getBookLink({ reserveType: params.reserveType, city: this.city, leaveDate: this.checkInDate });
        });
    }
};
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.UUID })
], TripDetailHotel.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.DATEONLY }) //入住日期
], TripDetailHotel.prototype, "checkInDate", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.DATEONLY }) //离开日期
], TripDetailHotel.prototype, "checkOutDate", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.STRING(20) }) //住宿城市
], TripDetailHotel.prototype, "city", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.STRING(50) }) //酒店名称
], TripDetailHotel.prototype, "name", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.STRING(50) }) //住宿地点
], TripDetailHotel.prototype, "placeName", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.STRING(255) }) //定位地点
], TripDetailHotel.prototype, "position", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], TripDetailHotel.prototype, "getBookLink", null);
TripDetailHotel = tslib_1.__decorate([
    common_1.TableExtends(tripDetail_1.TripDetail, 'tripDetailInfo', 'type', tripPlan_1.ETripType.HOTEL),
    common_1.Table(index_2.Models.tripDetailHotel, 'tripPlan.')
], TripDetailHotel);
exports.TripDetailHotel = TripDetailHotel;
let TripDetailSubsidy = class TripDetailSubsidy extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    get id() { return index_1.Values.UUIDV1(); }
    set id(id) { }
    get hasFirstDaySubsidy() { return true; }
    set hasFirstDaySubsidy(b) { }
    get hasLastDaySubsidy() { return true; }
    set hasLastDaySubsidy(b) { }
    get startDateTime() { return null; }
    set startDateTime(d) { }
    get endDateTime() { return null; }
    set endDateTime(d) { }
    get subsidyMoney() { return 0; }
    set subsidyMoney(money) { }
    get subsidyTemplateId() { return null; }
    set subsidyTemplateId(id) { }
    uploadInvoice(params) {
        return API.tripPlan.uploadInvoice({ tripDetailId: this.id, pictureFileId: params.pictureFileId });
    }
    getInvoices() {
        let self = this;
        return index_2.Models.tripDetailInvoice.find({ where: { tripDetailId: self.id } });
    }
    auditPlanInvoice(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!this.isLocal) {
                API.require('tripPlan');
                yield API.onload();
            }
            params['id'] = this.id;
            return API.tripPlan.auditPlanInvoice(params);
        });
    }
};
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.UUID })
], TripDetailSubsidy.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.BOOLEAN })
], TripDetailSubsidy.prototype, "hasFirstDaySubsidy", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.BOOLEAN })
], TripDetailSubsidy.prototype, "hasLastDaySubsidy", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.DATE })
], TripDetailSubsidy.prototype, "startDateTime", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.DATE })
], TripDetailSubsidy.prototype, "endDateTime", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.NUMERIC(15, 2) })
], TripDetailSubsidy.prototype, "subsidyMoney", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.UUID })
], TripDetailSubsidy.prototype, "subsidyTemplateId", null);
TripDetailSubsidy = tslib_1.__decorate([
    common_1.TableExtends(tripDetail_1.TripDetail, 'tripDetailInfo', 'type', tripPlan_1.ETripType.SUBSIDY),
    common_1.Table(index_2.Models.tripDetailSubsidy, 'tripPlan.')
], TripDetailSubsidy);
exports.TripDetailSubsidy = TripDetailSubsidy;
let TripDetailSpecial = class TripDetailSpecial extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    get id() { return index_1.Values.UUIDV1(); }
    set id(id) { }
    get deptCity() { return null; }
    set deptCity(city) { }
    get arrivalCity() { return null; }
    set arrivalCity(city) { }
    get deptDateTime() { return null; }
    set deptDateTime(d) { }
    get arrivalDateTime() { return null; }
    set arrivalDateTime(d) { }
    uploadInvoice(params) {
        return API.tripPlan.uploadInvoice({ tripDetailId: this.id, pictureFileId: params.pictureFileId });
    }
    getInvoices() {
        let self = this;
        return index_2.Models.tripDetailInvoice.find({ where: { tripDetailId: self.id } });
    }
    auditPlanInvoice(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!this.isLocal) {
                API.require('tripPlan');
                yield API.onload();
            }
            params['id'] = this.id;
            return API.tripPlan.auditPlanInvoice(params);
        });
    }
};
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.UUID })
], TripDetailSpecial.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.STRING(50) })
], TripDetailSpecial.prototype, "deptCity", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.STRING(50) })
], TripDetailSpecial.prototype, "arrivalCity", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.DATE })
], TripDetailSpecial.prototype, "deptDateTime", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.DATE })
], TripDetailSpecial.prototype, "arrivalDateTime", null);
TripDetailSpecial = tslib_1.__decorate([
    common_1.TableExtends(tripDetail_1.TripDetail, 'tripDetailInfo', 'type', tripPlan_1.ETripType.SPECIAL_APPROVE),
    common_1.Table(index_2.Models.tripDetailSpecial, 'tripPlan.')
], TripDetailSpecial);
exports.TripDetailSpecial = TripDetailSpecial;

//# sourceMappingURL=tripDetailInfo.js.map
