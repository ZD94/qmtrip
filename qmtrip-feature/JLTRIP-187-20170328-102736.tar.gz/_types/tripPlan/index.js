/**
 * Created by wlh on 2016/10/19.
 */
'use strict';
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
const _ = require("lodash");
var ECabin;
(function (ECabin) {
    ECabin[ECabin["PLANE_FIRST"] = 1] = "PLANE_FIRST";
    ECabin[ECabin["PLANE_BUSINESS"] = 2] = "PLANE_BUSINESS";
    ECabin[ECabin["PLANE_ECONOMY"] = 4] = "PLANE_ECONOMY";
    ECabin[ECabin["TRAIN_BUSINESS"] = 10] = "TRAIN_BUSINESS";
    ECabin[ECabin["TRAIN_FIRST"] = 11] = "TRAIN_FIRST";
    ECabin[ECabin["TRAIN_SECOND"] = 12] = "TRAIN_SECOND";
    ECabin[ECabin["TRAIN_HARD_SEAT"] = 13] = "TRAIN_HARD_SEAT";
    ECabin[ECabin["TRAIN_SOFT_SEAT"] = 14] = "TRAIN_SOFT_SEAT";
    ECabin[ECabin["TRAIN_SOFT_SLEEPER"] = 15] = "TRAIN_SOFT_SLEEPER";
    ECabin[ECabin["TRAIN_HARD_SLEEPER"] = 16] = "TRAIN_HARD_SLEEPER";
})(ECabin = exports.ECabin || (exports.ECabin = {}));
let _cabin_text = {};
_cabin_text[ECabin.PLANE_FIRST] = ['头等舱', 'first'];
_cabin_text[ECabin.PLANE_BUSINESS] = ['商务舱', 'business'];
_cabin_text[ECabin.PLANE_ECONOMY] = ['经济舱', 'economy'];
_cabin_text[ECabin.TRAIN_BUSINESS] = '商务座';
_cabin_text[ECabin.TRAIN_FIRST] = '一等座';
_cabin_text[ECabin.TRAIN_SECOND] = '二等座';
function getECabinByName(name) {
    let cabinKey = undefined;
    for (let key of Object.keys(_cabin_text)) {
        if (_cabin_text[key].indexOf(name.toLowerCase()) >= 0) {
            cabinKey = key;
            break;
        }
    }
    return cabinKey;
}
exports.getECabinByName = getECabinByName;
function getNameByECabin(key) {
    let r = _cabin_text[key];
    if (_.isArray(r)) {
        return r[0];
    }
    return r;
}
exports.getNameByECabin = getNameByECabin;
var EInvoiceFeeTypes;
(function (EInvoiceFeeTypes) {
    EInvoiceFeeTypes[EInvoiceFeeTypes["PLANE_TICKET"] = 1] = "PLANE_TICKET";
    EInvoiceFeeTypes[EInvoiceFeeTypes["TRAIN_TICKET"] = 2] = "TRAIN_TICKET";
    EInvoiceFeeTypes[EInvoiceFeeTypes["TICKET_CHANGE_FEE"] = 3] = "TICKET_CHANGE_FEE";
    EInvoiceFeeTypes[EInvoiceFeeTypes["CANCEL_TICKET_FEE"] = 4] = "CANCEL_TICKET_FEE";
    EInvoiceFeeTypes[EInvoiceFeeTypes["HOTEL"] = 5] = "HOTEL";
    EInvoiceFeeTypes[EInvoiceFeeTypes["INSURANCE"] = 6] = "INSURANCE";
    EInvoiceFeeTypes[EInvoiceFeeTypes["EXPRESS"] = 7] = "EXPRESS";
    EInvoiceFeeTypes[EInvoiceFeeTypes["ORDER_TICKET_FEE"] = 8] = "ORDER_TICKET_FEE";
    EInvoiceFeeTypes[EInvoiceFeeTypes["OTHER"] = 99] = "OTHER";
})(EInvoiceFeeTypes = exports.EInvoiceFeeTypes || (exports.EInvoiceFeeTypes = {}));
exports.InvoiceFeeTypeNames = [];
exports.InvoiceFeeTypeNames[EInvoiceFeeTypes.PLANE_TICKET] = '机票行程单';
exports.InvoiceFeeTypeNames[EInvoiceFeeTypes.TRAIN_TICKET] = '火车票';
exports.InvoiceFeeTypeNames[EInvoiceFeeTypes.TICKET_CHANGE_FEE] = '改签费';
exports.InvoiceFeeTypeNames[EInvoiceFeeTypes.CANCEL_TICKET_FEE] = '退票费';
exports.InvoiceFeeTypeNames[EInvoiceFeeTypes.HOTEL] = '住宿费';
exports.InvoiceFeeTypeNames[EInvoiceFeeTypes.INSURANCE] = '保险费';
exports.InvoiceFeeTypeNames[EInvoiceFeeTypes.EXPRESS] = '快递费';
exports.InvoiceFeeTypeNames[EInvoiceFeeTypes.ORDER_TICKET_FEE] = '订票费';
exports.InvoiceFeeTypeNames[EInvoiceFeeTypes.OTHER] = '其他';
var EPayType;
(function (EPayType) {
    EPayType[EPayType["PERSONAL_PAY"] = 1] = "PERSONAL_PAY";
    EPayType[EPayType["COMPANY_PAY"] = 2] = "COMPANY_PAY";
})(EPayType = exports.EPayType || (exports.EPayType = {}));
exports.PayTypeNames = [];
exports.PayTypeNames[EPayType.PERSONAL_PAY] = '个人支付';
exports.PayTypeNames[EPayType.COMPANY_PAY] = '公司支付';
var ESourceType;
(function (ESourceType) {
    ESourceType[ESourceType["MANUALLY_ADD"] = 1] = "MANUALLY_ADD";
    ESourceType[ESourceType["RELATE_ORDER"] = 2] = "RELATE_ORDER";
})(ESourceType = exports.ESourceType || (exports.ESourceType = {}));
var EInvoiceStatus;
(function (EInvoiceStatus) {
    EInvoiceStatus[EInvoiceStatus["WAIT_AUDIT"] = 0] = "WAIT_AUDIT";
    EInvoiceStatus[EInvoiceStatus["AUDIT_PASS"] = 1] = "AUDIT_PASS";
    EInvoiceStatus[EInvoiceStatus["AUDIT_FAIL"] = -1] = "AUDIT_FAIL";
})(EInvoiceStatus = exports.EInvoiceStatus || (exports.EInvoiceStatus = {}));
__export(require("./tripPlan"));
__export(require("./tripDetail"));
__export(require("./tripDetailInfo"));

//# sourceMappingURL=index.js.map
