/**
 * Created by wlh on 2016/10/19.
 */
'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const object_1 = require("common/model/object");
const index_1 = require("common/model/index");
const common_1 = require("common/model/common");
const index_2 = require("../index");
const index_3 = require("./index");
let TripDetail = class TripDetail extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return index_1.Values.UUIDV1(); }
    set id(val) { }
    get tripPlanId() { return null; }
    set tripPlanId(val) { }
    get accountId() { return null; }
    set accountId(val) { }
    get type() { return 0; }
    set type(val) { }
    get status() { return 0; }
    set status(val) { }
    get auditRemark() { return ''; }
    set auditRemark(val) { }
    get auditUser() { return null; }
    set auditUser(val) { }
    get remark() { return null; }
    set remark(val) { }
    get budget() { return 0; }
    set budget(val) { }
    get expenditure() { return 0; }
    set expenditure(val) { }
    get personalExpenditure() { return 0; }
    set personalExpenditure(expenditure) { }
    get tripPlan() { return null; }
    set tripPlan(val) { }
    getInvoices() {
        let self = this;
        return index_2.Models.tripDetailInvoice.find({ where: { tripDetailId: self.id } });
    }
    // editBudget(params: {budget: number}): Promise<boolean> {
    //     //    f3ac3f50-2c70-11e6-bb82-8dd809b99199
    //     return API.tripPlan.editTripDetailBudget({id: this.id, budget: params.budget});
    // }
    //
    uploadInvoice(params) {
        return API.tripPlan.uploadInvoice({ tripDetailId: this.id, pictureFileId: params.pictureFileId });
    }
    auditPlanInvoice(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!this.isLocal) {
                API.require('tripPlan');
                yield API.onload();
            }
            params['id'] = this.id;
            return API.tripPlan.auditPlanInvoice(params);
        });
    }
};
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.UUID })
], TripDetail.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.UUID })
], TripDetail.prototype, "tripPlanId", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.UUID })
], TripDetail.prototype, "accountId", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.INTEGER })
], TripDetail.prototype, "type", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.INTEGER })
], TripDetail.prototype, "status", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.STRING })
], TripDetail.prototype, "auditRemark", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.UUID })
], TripDetail.prototype, "auditUser", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.STRING })
], TripDetail.prototype, "remark", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.DOUBLE })
], TripDetail.prototype, "budget", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.DOUBLE })
], TripDetail.prototype, "expenditure", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.NUMERIC(15, 2) })
], TripDetail.prototype, "personalExpenditure", null);
tslib_1.__decorate([
    common_1.ResolveRef({ type: index_1.Types.UUID }, index_2.Models.tripPlan)
], TripDetail.prototype, "tripPlan", null);
tslib_1.__decorate([
    common_1.Create()
], TripDetail, "create", null);
TripDetail = tslib_1.__decorate([
    common_1.Table(index_2.Models.tripDetail, 'tripPlan.')
], TripDetail);
exports.TripDetail = TripDetail;
let TripDetailInvoice = class TripDetailInvoice extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return index_1.Values.UUIDV1(); }
    set id(id) { }
    get tripDetailId() { return null; }
    set tripDetailId(tripDetailId) { }
    get accountId() { return null; }
    set accountId(accountId) { }
    get supplier() { return null; }
    set supplier(val) { }
    get orderId() { return null; }
    set orderId(orderId) { }
    get sourceType() { return index_3.ESourceType.MANUALLY_ADD; }
    set sourceType(payType) { }
    get pictureFileId() { return null; }
    set pictureFileId(pictureFileId) { }
    //票据类型
    get type() { return null; }
    set type(type) { }
    get payType() { return index_3.EPayType.PERSONAL_PAY; }
    set payType(payType) { }
    get invoiceDateTime() { return null; }
    set invoiceDateTime(invoiceDate) { }
    //金额
    get totalMoney() { return 0; }
    set totalMoney(totalMoney) { }
    //用户提交时备注
    get remark() { return null; }
    set remark(remark) { }
    //审核状态
    get status() { return index_3.EInvoiceStatus.WAIT_AUDIT; }
    set status(status) { }
    //审核失败时备注
    get auditRemark() { return null; }
    set auditRemark(auditRemark) { }
    get times() { return 0; }
    set times(times) { }
    get approveAt() { return null; }
    set approveAt(approveAt) { }
};
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.UUID })
], TripDetailInvoice.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.UUID })
], TripDetailInvoice.prototype, "tripDetailId", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.UUID })
], TripDetailInvoice.prototype, "accountId", null);
tslib_1.__decorate([
    common_1.ResolveRef({ type: index_1.Types.UUID }, index_2.Models.supplier)
], TripDetailInvoice.prototype, "supplier", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.STRING })
], TripDetailInvoice.prototype, "orderId", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.INTEGER })
], TripDetailInvoice.prototype, "sourceType", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.TEXT })
], TripDetailInvoice.prototype, "pictureFileId", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.INTEGER })
], TripDetailInvoice.prototype, "type", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.INTEGER })
], TripDetailInvoice.prototype, "payType", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.DATE })
], TripDetailInvoice.prototype, "invoiceDateTime", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.NUMERIC(15, 2) })
], TripDetailInvoice.prototype, "totalMoney", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.TEXT })
], TripDetailInvoice.prototype, "remark", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.INTEGER })
], TripDetailInvoice.prototype, "status", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.TEXT })
], TripDetailInvoice.prototype, "auditRemark", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.INTEGER })
], TripDetailInvoice.prototype, "times", null);
tslib_1.__decorate([
    common_1.Field({ type: index_1.Types.DATE })
], TripDetailInvoice.prototype, "approveAt", null);
tslib_1.__decorate([
    common_1.Create()
], TripDetailInvoice, "create", null);
TripDetailInvoice = tslib_1.__decorate([
    common_1.Table(index_2.Models.tripDetailInvoice, "tripPlan.")
], TripDetailInvoice);
exports.TripDetailInvoice = TripDetailInvoice;

//# sourceMappingURL=tripDetail.js.map
