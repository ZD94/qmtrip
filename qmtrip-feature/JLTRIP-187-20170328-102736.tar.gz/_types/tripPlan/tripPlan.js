"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const _types_1 = require("_types");
const model_1 = require("common/model");
const common_1 = require("common/model/common");
const object_1 = require("common/model/object");
var EPlanStatus;
(function (EPlanStatus) {
    EPlanStatus[EPlanStatus["CANCEL"] = -4] = "CANCEL";
    EPlanStatus[EPlanStatus["AUDIT_NOT_PASS"] = -3] = "AUDIT_NOT_PASS";
    // APPROVE_NOT_PASS = -2, //审批未通过
    EPlanStatus[EPlanStatus["NO_BUDGET"] = -1] = "NO_BUDGET";
    // WAIT_APPROVE = 0, //待审批状态
    EPlanStatus[EPlanStatus["WAIT_UPLOAD"] = 1] = "WAIT_UPLOAD";
    EPlanStatus[EPlanStatus["WAIT_COMMIT"] = 2] = "WAIT_COMMIT";
    EPlanStatus[EPlanStatus["AUDITING"] = 3] = "AUDITING";
    EPlanStatus[EPlanStatus["COMPLETE"] = 4] = "COMPLETE"; //审核完，已完成状态
})(EPlanStatus = exports.EPlanStatus || (exports.EPlanStatus = {}));
var QMEApproveStatus;
(function (QMEApproveStatus) {
    QMEApproveStatus[QMEApproveStatus["CANCEL"] = -3] = "CANCEL";
    QMEApproveStatus[QMEApproveStatus["NO_BUDGET"] = -2] = "NO_BUDGET";
    QMEApproveStatus[QMEApproveStatus["REJECT"] = -1] = "REJECT";
    QMEApproveStatus[QMEApproveStatus["WAIT_APPROVE"] = 0] = "WAIT_APPROVE";
    QMEApproveStatus[QMEApproveStatus["PASS"] = 1] = "PASS"; //审批通过
})(QMEApproveStatus = exports.QMEApproveStatus || (exports.QMEApproveStatus = {}));
exports.EApproveStatus2Text = {
    [QMEApproveStatus.CANCEL]: '已撤销',
    [QMEApproveStatus.NO_BUDGET]: '没有预算',
    [QMEApproveStatus.PASS]: '审批通过',
    [QMEApproveStatus.REJECT]: '审批驳回',
    [QMEApproveStatus.WAIT_APPROVE]: '等待审批',
};
var EApproveResult;
(function (EApproveResult) {
    EApproveResult[EApproveResult["NULL"] = -1] = "NULL";
    EApproveResult[EApproveResult["WAIT_APPROVE"] = 0] = "WAIT_APPROVE";
    EApproveResult[EApproveResult["AUTO_APPROVE"] = 1] = "AUTO_APPROVE";
    EApproveResult[EApproveResult["PASS"] = 2] = "PASS";
    EApproveResult[EApproveResult["REJECT"] = 3] = "REJECT"; //驳回
})(EApproveResult = exports.EApproveResult || (exports.EApproveResult = {}));
exports.EApproveResult2Text = {
    [EApproveResult.AUTO_APPROVE]: '自动通过',
    [EApproveResult.PASS]: '审批通过',
    [EApproveResult.REJECT]: '审批驳回',
    [EApproveResult.WAIT_APPROVE]: '提交审批',
};
var ETripType;
(function (ETripType) {
    ETripType[ETripType["OUT_TRIP"] = 0] = "OUT_TRIP";
    ETripType[ETripType["BACK_TRIP"] = 1] = "BACK_TRIP";
    ETripType[ETripType["HOTEL"] = 2] = "HOTEL";
    ETripType[ETripType["SUBSIDY"] = 3] = "SUBSIDY";
    ETripType[ETripType["SPECIAL_APPROVE"] = 4] = "SPECIAL_APPROVE";
})(ETripType = exports.ETripType || (exports.ETripType = {}));
var EInvoiceType;
(function (EInvoiceType) {
    EInvoiceType[EInvoiceType["TRAIN"] = 0] = "TRAIN";
    EInvoiceType[EInvoiceType["PLANE"] = 1] = "PLANE";
    EInvoiceType[EInvoiceType["HOTEL"] = 2] = "HOTEL";
    EInvoiceType[EInvoiceType["SUBSIDY"] = 3] = "SUBSIDY";
    EInvoiceType[EInvoiceType["SPECIAL_APPROVE"] = 4] = "SPECIAL_APPROVE";
})(EInvoiceType = exports.EInvoiceType || (exports.EInvoiceType = {}));
var EAuditStatus;
(function (EAuditStatus) {
    EAuditStatus[EAuditStatus["INVOICE_NOT_PASS"] = -2] = "INVOICE_NOT_PASS";
    EAuditStatus[EAuditStatus["NOT_PASS"] = -1] = "NOT_PASS";
    EAuditStatus[EAuditStatus["AUDITING"] = 0] = "AUDITING";
    EAuditStatus[EAuditStatus["PASS"] = 1] = "PASS";
    EAuditStatus[EAuditStatus["INVOICE_PASS"] = 2] = "INVOICE_PASS";
})(EAuditStatus = exports.EAuditStatus || (exports.EAuditStatus = {}));
let Project = class Project extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(val) { }
    get companyId() { return null; }
    set companyId(val) { }
    get createUser() { return null; }
    set createUser(val) { }
    get code() { return ''; }
    set code(val) { }
    get name() { return ''; }
    set name(val) { }
    get weight() { return 0; }
    set weight(val) { }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], Project.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], Project.prototype, "companyId", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], Project.prototype, "createUser", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Project.prototype, "code", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Project.prototype, "name", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], Project.prototype, "weight", null);
tslib_1.__decorate([
    common_1.Create()
], Project, "create", null);
Project = tslib_1.__decorate([
    common_1.Table(_types_1.Models.project, 'tripPlan.')
], Project);
exports.Project = Project;
let TripPlan = class TripPlan extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(val) { }
    get planNo() { return ''; }
    set planNo(val) { }
    get isInvoiceUpload() { return false; }
    set isInvoiceUpload(val) { }
    get isCommit() { return false; }
    set isCommit(val) { }
    get isNeedTraffic() { return false; }
    set isNeedTraffic(val) { }
    get isRoundTrip() { return true; }
    set isRoundTrip(bool) { }
    get isNeedHotel() { return false; }
    set isNeedHotel(val) { }
    get isSpecialApprove() { return false; }
    set isSpecialApprove(val) { }
    get specialApproveRemark() { return ''; }
    set specialApproveRemark(val) { }
    get cancelRemark() { return ''; }
    set cancelRemark(val) { }
    get query() { return null; }
    ;
    set query(obj) { }
    get projectIds() { return null; }
    ;
    set projectIds(obj) { }
    get arrivalCityCodes() { return null; }
    ;
    set arrivalCityCodes(obj) { }
    get title() { return ''; }
    set title(val) { }
    get description() { return ''; }
    set description(val) { }
    get status() { return 0; }
    set status(val) { }
    get deptCity() { return ''; }
    set deptCity(val) { }
    get arrivalCity() { return ''; }
    set arrivalCity(val) { }
    get deptCityCode() { return ''; }
    set deptCityCode(val) { }
    get arrivalCityCode() { return ''; }
    set arrivalCityCode(val) { }
    get startAt() { return null; }
    set startAt(val) { }
    get backAt() { return null; }
    set backAt(val) { }
    get budget() { return 0; }
    set budget(val) { }
    get expenditure() { return 0; }
    set expenditure(val) { }
    get personalExpenditure() { return 0; }
    set personalExpenditure(val) { }
    get expendInfo() { return null; }
    set expendInfo(val) { }
    get auditStatus() { return EAuditStatus.AUDITING; }
    set auditStatus(val) { }
    get auditUser() { return null; }
    set auditUser(val) { }
    get auditRemark() { return ''; }
    set auditRemark(val) { }
    get score() { return 0; }
    set score(val) { }
    get expireAt() { return null; }
    set expireAt(val) { }
    get remark() { return ''; }
    set remark(val) { }
    get commitTime() { return null; }
    set commitTime(val) { }
    get originalBudget() { return 0; }
    ;
    set originalBudget(v) { }
    get isFinalBudget() { return false; }
    set isFinalBudget(bool) { }
    get finalBudgetCreateAt() { return null; }
    set finalBudgetCreateAt(d) { }
    ;
    // @Field({type: Types.DATE})
    // get autoApproveTime() : Date { return null;}
    // set autoApproveTime(d: Date) {};
    get project() { return null; }
    set project(val) { }
    get account() { return null; }
    set account(val) { }
    getCompany(id) {
        return _types_1.Models.company.get(id);
    }
    setCompany(val) { }
    getOutTrip() {
        return _types_1.Models.tripDetail.find({ where: { tripPlanId: this.id, type: ETripType.OUT_TRIP } });
    }
    getBackTrip() {
        return _types_1.Models.tripDetail.find({ where: { tripPlanId: this.id, type: ETripType.BACK_TRIP } });
    }
    getHotel() {
        return _types_1.Models.tripDetail.find({ where: { tripPlanId: this.id, type: ETripType.HOTEL } });
    }
    getTripDetails(options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!options) {
                options = { where: {} };
            }
            if (!options.where) {
                options.where = {};
            }
            if (!options.order) {
                options.order = [['created_at', 'asc']];
            }
            options.where.tripPlanId = this.id;
            return _types_1.Models.tripDetail.find(options);
        });
    }
    /**
     * 提交出差计划
     * @returns {Promise<boolean>}
     */
    commit() {
        return API.tripPlan.commitTripPlan({ id: this.id });
    }
    cancel(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!this.isLocal) {
                API.require('tripPlan');
                yield API.onload();
            }
            var obj = {};
            obj.id = this.id;
            if (params && params.remark) {
                obj.remark = params.remark;
            }
            return API.tripPlan.cancelTripPlan(obj);
        });
    }
    /**
     * 获取出差记录日志
     * @returns {Promise<FindResult>}
     */
    getLogs(options) {
        if (!options) {
            options = { where: {} };
        }
        if (!options.where) {
            options.where = {};
        }
        options.where.tripPlanId = this.id;
        return _types_1.Models.tripPlanLog.find(options);
    }
    getOddBudget() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!this.isLocal) {
                API.require('tripPlan');
                yield API.onload();
            }
            return API.tripPlan.getOddBudget({ id: this.id });
        });
    }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], TripPlan.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], TripPlan.prototype, "planNo", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], TripPlan.prototype, "isInvoiceUpload", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], TripPlan.prototype, "isCommit", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], TripPlan.prototype, "isNeedTraffic", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], TripPlan.prototype, "isRoundTrip", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], TripPlan.prototype, "isNeedHotel", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], TripPlan.prototype, "isSpecialApprove", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.TEXT })
], TripPlan.prototype, "specialApproveRemark", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.TEXT })
], TripPlan.prototype, "cancelRemark", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.JSONB })
], TripPlan.prototype, "query", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.JSONB })
], TripPlan.prototype, "projectIds", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.JSONB })
], TripPlan.prototype, "arrivalCityCodes", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], TripPlan.prototype, "title", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], TripPlan.prototype, "description", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], TripPlan.prototype, "status", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], TripPlan.prototype, "deptCity", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], TripPlan.prototype, "arrivalCity", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], TripPlan.prototype, "deptCityCode", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], TripPlan.prototype, "arrivalCityCode", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DATE })
], TripPlan.prototype, "startAt", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DATE })
], TripPlan.prototype, "backAt", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DOUBLE })
], TripPlan.prototype, "budget", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DOUBLE })
], TripPlan.prototype, "expenditure", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.NUMERIC(15, 2) })
], TripPlan.prototype, "personalExpenditure", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.JSONB })
], TripPlan.prototype, "expendInfo", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], TripPlan.prototype, "auditStatus", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], TripPlan.prototype, "auditUser", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], TripPlan.prototype, "auditRemark", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], TripPlan.prototype, "score", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DATE })
], TripPlan.prototype, "expireAt", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], TripPlan.prototype, "remark", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DATE })
], TripPlan.prototype, "commitTime", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DOUBLE })
], TripPlan.prototype, "originalBudget", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], TripPlan.prototype, "isFinalBudget", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DATE })
], TripPlan.prototype, "finalBudgetCreateAt", null);
tslib_1.__decorate([
    common_1.ResolveRef({ type: model_1.Types.UUID }, _types_1.Models.project)
], TripPlan.prototype, "project", null);
tslib_1.__decorate([
    common_1.ResolveRef({ type: model_1.Types.UUID }, _types_1.Models.staff)
], TripPlan.prototype, "account", null);
tslib_1.__decorate([
    common_1.Reference({ type: model_1.Types.UUID })
], TripPlan.prototype, "getCompany", null);
tslib_1.__decorate([
    common_1.Create()
], TripPlan, "create", null);
TripPlan = tslib_1.__decorate([
    common_1.Table(_types_1.Models.tripPlan, 'tripPlan.'),
    common_1.TableIndex('accountId')
], TripPlan);
exports.TripPlan = TripPlan;
let TripPlanLog = class TripPlanLog extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(val) { }
    get tripPlanId() { return null; }
    set tripPlanId(val) { }
    get tripDetailId() { return null; }
    set tripDetailId(val) { }
    get userId() { return null; }
    set userId(val) { }
    get remark() { return null; }
    set remark(val) { }
    get approveStatus() { return EApproveResult.NULL; }
    set approveStatus(val) { }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], TripPlanLog.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], TripPlanLog.prototype, "tripPlanId", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], TripPlanLog.prototype, "tripDetailId", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], TripPlanLog.prototype, "userId", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], TripPlanLog.prototype, "remark", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], TripPlanLog.prototype, "approveStatus", null);
tslib_1.__decorate([
    common_1.Create()
], TripPlanLog, "create", null);
TripPlanLog = tslib_1.__decorate([
    common_1.Table(_types_1.Models.tripPlanLog, 'tripPlan.')
], TripPlanLog);
exports.TripPlanLog = TripPlanLog;
let TripApprove = class TripApprove extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(val) { }
    get accountId() { return null; }
    set accountId(val) { }
    get isNeedTraffic() { return false; }
    set isNeedTraffic(val) { }
    get isRoundTrip() { return true; }
    set isRoundTrip(bool) { }
    get isNeedHotel() { return false; }
    set isNeedHotel(val) { }
    get query() { return null; }
    ;
    set query(obj) { }
    get projectIds() { return null; }
    ;
    set projectIds(obj) { }
    get arrivalCityCodes() { return null; }
    ;
    set arrivalCityCodes(obj) { }
    get title() { return ''; }
    set title(val) { }
    get description() { return ''; }
    set description(val) { }
    get status() { return QMEApproveStatus.WAIT_APPROVE; }
    set status(val) { }
    get deptCity() { return ''; }
    set deptCity(val) { }
    get arrivalCity() { return ''; }
    set arrivalCity(val) { }
    get deptCityCode() { return ''; }
    set deptCityCode(val) { }
    get arrivalCityCode() { return ''; }
    set arrivalCityCode(val) { }
    get approvedUsers() { return ''; }
    set approvedUsers(val) { }
    get isSpecialApprove() { return false; }
    set isSpecialApprove(val) { }
    get specialApproveRemark() { return ''; }
    set specialApproveRemark(val) { }
    get cancelRemark() { return ''; }
    set cancelRemark(val) { }
    get startAt() { return null; }
    set startAt(val) { }
    get backAt() { return null; }
    set backAt(val) { }
    get budget() { return 0; }
    set budget(val) { }
    get budgetInfo() { return []; }
    set budgetInfo(val) { }
    get autoApproveTime() { return null; }
    set autoApproveTime(d) { }
    ;
    get project() { return null; }
    set project(val) { }
    get account() { return null; }
    set account(val) { }
    get approveUser() { return null; }
    set approveUser(val) { }
    get approveRemark() { return ''; }
    set approveRemark(val) { }
    getCompany(id) {
        return _types_1.Models.company.get(id);
    }
    setCompany(val) { }
    /**
     * 审批人审批出差计划
     * @param params
     * @returns {Promise<boolean>}
     */
    approve(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            params.id = this.id;
            if (!this.isLocal) {
                API.require("tripApprove");
                yield API.onload();
            }
            return API.tripApprove.approveTripPlan(params);
        });
    }
    getApproveLogs(options) {
        if (!options)
            options = { where: {} };
        if (!options.where)
            options.where = {};
        options.where.tripPlanId = this.id;
        options.where.approveStatus = { $ne: EApproveResult.NULL };
        options.order = [['created_at', 'desc']];
        return _types_1.Models.tripPlanLog.find(options);
    }
    cancel(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!this.isLocal) {
                API.require('tripPlan');
                yield API.onload();
            }
            var obj = {};
            obj.id = this.id;
            if (params && params.remark) {
                obj.remark = params.remark;
            }
            return API.tripApprove.cancelTripApprove(obj);
        });
    }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], TripApprove.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], TripApprove.prototype, "accountId", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], TripApprove.prototype, "isNeedTraffic", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], TripApprove.prototype, "isRoundTrip", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], TripApprove.prototype, "isNeedHotel", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.JSONB })
], TripApprove.prototype, "query", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.JSONB })
], TripApprove.prototype, "projectIds", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.JSONB })
], TripApprove.prototype, "arrivalCityCodes", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], TripApprove.prototype, "title", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], TripApprove.prototype, "description", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], TripApprove.prototype, "status", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], TripApprove.prototype, "deptCity", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], TripApprove.prototype, "arrivalCity", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], TripApprove.prototype, "deptCityCode", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], TripApprove.prototype, "arrivalCityCode", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.TEXT })
], TripApprove.prototype, "approvedUsers", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], TripApprove.prototype, "isSpecialApprove", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.TEXT })
], TripApprove.prototype, "specialApproveRemark", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.TEXT })
], TripApprove.prototype, "cancelRemark", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DATE })
], TripApprove.prototype, "startAt", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DATE })
], TripApprove.prototype, "backAt", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DOUBLE })
], TripApprove.prototype, "budget", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.JSONB })
], TripApprove.prototype, "budgetInfo", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DATE })
], TripApprove.prototype, "autoApproveTime", null);
tslib_1.__decorate([
    common_1.ResolveRef({ type: model_1.Types.UUID }, _types_1.Models.project)
], TripApprove.prototype, "project", null);
tslib_1.__decorate([
    common_1.ResolveRef({ type: model_1.Types.UUID }, _types_1.Models.staff)
], TripApprove.prototype, "account", null);
tslib_1.__decorate([
    common_1.ResolveRef({ type: model_1.Types.UUID }, _types_1.Models.staff)
], TripApprove.prototype, "approveUser", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], TripApprove.prototype, "approveRemark", null);
tslib_1.__decorate([
    common_1.Reference({ type: model_1.Types.UUID })
], TripApprove.prototype, "getCompany", null);
tslib_1.__decorate([
    common_1.Create()
], TripApprove, "create", null);
TripApprove = tslib_1.__decorate([
    common_1.Table(_types_1.Models.tripApprove, 'tripPlan.'),
    common_1.TableIndex('accountId')
], TripApprove);
exports.TripApprove = TripApprove;
let FinanceCheckCode = class FinanceCheckCode extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(id) { }
    get tripPlanId() { return null; }
    ;
    set tripPlanId(id) { }
    get code() { return getRndCode(6); }
    set code(code) { }
    get isValid() { return true; }
    set isValid(b) { }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], FinanceCheckCode.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], FinanceCheckCode.prototype, "tripPlanId", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(50) })
], FinanceCheckCode.prototype, "code", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], FinanceCheckCode.prototype, "isValid", null);
tslib_1.__decorate([
    common_1.Create()
], FinanceCheckCode, "create", null);
FinanceCheckCode = tslib_1.__decorate([
    common_1.Table(_types_1.Models.financeCheckCode, 'tripPlan.')
], FinanceCheckCode);
exports.FinanceCheckCode = FinanceCheckCode;
function getRndCode(length) {
    let ret = '';
    for (let i = 0; i < length; i++) {
        ret += Math.floor(Math.random() * 10);
    }
    return ret;
}

//# sourceMappingURL=tripPlan.js.map
