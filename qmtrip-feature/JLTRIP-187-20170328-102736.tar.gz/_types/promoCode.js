"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const _types_1 = require("_types");
const common_1 = require("common/model/common");
const object_1 = require("common/model/object");
const model_1 = require("common/model");
let PromoCode = class PromoCode extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(val) { }
    get code() { return null; }
    set code(code) { }
    get expiryDate() { return null; }
    set expiryDate(val) { }
    get times() { return null; }
    set times(val) { }
    get type() { return null; }
    set type(val) { }
    get params() { return {}; }
    ;
    set params(val) { }
    get description() { return null; }
    ;
    set description(val) { }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], PromoCode.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(50) })
], PromoCode.prototype, "code", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DATE })
], PromoCode.prototype, "expiryDate", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], PromoCode.prototype, "times", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], PromoCode.prototype, "type", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.JSONB })
], PromoCode.prototype, "params", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.TEXT })
], PromoCode.prototype, "description", null);
tslib_1.__decorate([
    common_1.Create()
], PromoCode, "create", null);
PromoCode = tslib_1.__decorate([
    common_1.Table(_types_1.Models.promoCode, "promoCode.")
], PromoCode);
exports.PromoCode = PromoCode;

//# sourceMappingURL=promoCode.js.map
