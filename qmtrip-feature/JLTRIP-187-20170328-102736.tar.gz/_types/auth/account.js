"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const language_1 = require("common/language");
const common_1 = require("common/model/common");
const _types_1 = require("_types");
const object_1 = require("common/model/object");
const model_1 = require("common/model");
const coin_1 = require("_types/coin");
const validator = require("validator");
var ACCOUNT_STATUS;
(function (ACCOUNT_STATUS) {
    ACCOUNT_STATUS[ACCOUNT_STATUS["ACTIVE"] = 1] = "ACTIVE";
    ACCOUNT_STATUS[ACCOUNT_STATUS["NOT_ACTIVE"] = 0] = "NOT_ACTIVE";
    ACCOUNT_STATUS[ACCOUNT_STATUS["FORBIDDEN"] = -1] = "FORBIDDEN";
})(ACCOUNT_STATUS = exports.ACCOUNT_STATUS || (exports.ACCOUNT_STATUS = {}));
;
let Account = class Account extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return null; }
    set id(id) { }
    get email() { return null; }
    set email(email) { }
    //邮箱
    get pwd() { return null; }
    set pwd(pwd) { }
    //密码
    get mobile() { return null; }
    set mobile(mobile) { }
    //手机
    get status() { return 0; }
    set status(status) { }
    //创建时间
    get forbiddenExpireAt() { return null; }
    set forbiddenExpireAt(forbiddenExpireAt) { }
    //连续错误次数
    get loginFailTimes() { return null; }
    set loginFailTimes(loginFailTimes) { }
    //最近登录时间
    get lastLoginAt() { return null; }
    set lastLoginAt(lastLoginAt) { }
    //最近登录Ip
    get lastLoginIp() { return ''; }
    set lastLoginIp(lastLoginIp) { }
    get activeToken() { return null; }
    set activeToken(activeToken) { }
    get pwdToken() { return null; }
    set pwdToken(pwdToken) { }
    get oldQrcodeToken() { return null; }
    set oldQrcodeToken(oldQrcodeToken) { }
    get qrcodeToken() { return null; }
    set qrcodeToken(qrcodeToken) { }
    get checkcodeToken() { return null; }
    set checkcodeToken(checkcodeToken) { }
    get type() { return _types_1.EAccountType.STAFF; }
    set type(type) { }
    get isFirstLogin() { return true; }
    set isFirstLogin(isFirstLogin) { }
    get isValidateMobile() { return false; }
    set isValidateMobile(isValidateMobile) { }
    get isValidateEmail() { return false; }
    set isValidateEmail(isValidateEmail) { }
    get coinAccount() { return null; }
    ;
    set coinAccount(coinAccount) { }
    get isNeedChangePwd() { return false; }
    set isNeedChangePwd(isNeedChangePwd) { }
    getCoinAccountChanges() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            if (!this.coinAccount) {
                let ca = coin_1.CoinAccount.create();
                yield ca.save();
                self.coinAccount = ca;
                yield self.save();
            }
            let coinAccount = self.coinAccount;
            return coinAccount.getCoinAccountChanges({});
        });
    }
    validate() {
        if (validator.isMobilePhone(this.mobile, 'zh-CN')) {
            throw language_1.default.ERR.INVALID_FORMAT('mobile');
        }
        if (validator.isEmail(this.email)) {
            throw language_1.default.ERR.INVALID_FORMAT('email');
        }
    }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], Account.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Account.prototype, "email", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Account.prototype, "pwd", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Account.prototype, "mobile", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], Account.prototype, "status", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DATE })
], Account.prototype, "forbiddenExpireAt", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], Account.prototype, "loginFailTimes", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DATE })
], Account.prototype, "lastLoginAt", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Account.prototype, "lastLoginIp", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Account.prototype, "activeToken", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Account.prototype, "pwdToken", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Account.prototype, "oldQrcodeToken", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Account.prototype, "qrcodeToken", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Account.prototype, "checkcodeToken", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], Account.prototype, "type", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], Account.prototype, "isFirstLogin", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], Account.prototype, "isValidateMobile", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], Account.prototype, "isValidateEmail", null);
tslib_1.__decorate([
    common_1.ResolveRef({ type: model_1.Types.UUID }, _types_1.Models.coinAccount)
], Account.prototype, "coinAccount", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], Account.prototype, "isNeedChangePwd", null);
tslib_1.__decorate([
    common_1.Create()
], Account, "create", null);
Account = tslib_1.__decorate([
    common_1.Table(_types_1.Models.account, "auth."),
    common_1.TableIndex('email', { unique: true }),
    common_1.TableIndex('mobile', { unique: true })
], Account);
exports.Account = Account;

//# sourceMappingURL=account.js.map
