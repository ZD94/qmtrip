"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const common_1 = require("common/model/common");
const _types_1 = require("_types");
const object_1 = require("common/model/object");
const model_1 = require("common/model");
exports.OS_TYPE = {
    WEB: 'web',
    TMP_CODE: 'tmpCode',
    WECHAT: 'wechat',
};
let Token = class Token extends object_1.ModelObject {
    get id() { return model_1.Values.UUIDV1(); }
    ;
    set id(id) { }
    get accountId() { return null; }
    ;
    set accountId(accountId) { }
    get type() { return null; }
    set type(os) { }
    get token() { return null; }
    ;
    set token(token) { }
    get expireAt() { return null; }
    set expireAt(expireAt) { }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], Token.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], Token.prototype, "accountId", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Token.prototype, "type", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Token.prototype, "token", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DATE })
], Token.prototype, "expireAt", null);
Token = tslib_1.__decorate([
    common_1.Table(_types_1.Models.token, "auth."),
    common_1.TableIndex(['accountId', 'type'])
], Token);
exports.Token = Token;

//# sourceMappingURL=token.js.map
