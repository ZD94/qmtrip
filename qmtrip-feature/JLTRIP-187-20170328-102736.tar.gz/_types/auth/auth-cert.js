"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const helper_1 = require("common/api/helper");
const utils_1 = require("common/utils");
let LoginRequest = class LoginRequest {
    constructor(account, timestamp, sign) {
        this.account = account;
        this.timestamp = timestamp;
        this.sign = sign;
    }
};
LoginRequest = tslib_1.__decorate([
    helper_1.regApiType('API.')
], LoginRequest);
exports.LoginRequest = LoginRequest;
let LoginResponse = class LoginResponse {
    constructor(accountId, tokenId, token) {
        this.accountId = accountId;
        this.tokenId = tokenId;
        this.token = token;
    }
};
LoginResponse = tslib_1.__decorate([
    helper_1.regApiType('API.')
], LoginResponse);
exports.LoginResponse = LoginResponse;
let AuthRequest = class AuthRequest {
    constructor(tokenId, timestamp, sign) {
        this.tokenId = tokenId;
        this.timestamp = timestamp;
        this.sign = sign;
    }
};
AuthRequest = tslib_1.__decorate([
    helper_1.regApiType('API.')
], AuthRequest);
exports.AuthRequest = AuthRequest;
let AuthResponse = class AuthResponse {
    constructor(accountId) {
        this.accountId = accountId;
    }
};
AuthResponse = tslib_1.__decorate([
    helper_1.regApiType('API.')
], AuthResponse);
exports.AuthResponse = AuthResponse;
function signToken(...args) {
    args = args.map((arg) => {
        if (typeof arg === 'number') {
            return arg.toString(16);
        }
        if (arg instanceof Date) {
            return Math.floor(arg.getTime() / 1000).toString(16);
        }
        if (typeof arg === 'object') {
            throw new TypeError('signToken not accept argument of type:' + (typeof arg));
        }
        return arg;
    });
    return utils_1.md5(args.join('|'));
}
exports.signToken = signToken;
var replace_map = { '+': '-', '/': '_', '=': '~', };
var reverse_map = { '-': '+', '_': '/', '~': '=', };
function genAuthString(req) {
    var strlist = [];
    strlist.push(req.tokenId.replace(/\-/g, ''));
    strlist.push(req.sign);
    strlist.push(Math.floor(req.timestamp.getTime() / 1000).toString(16));
    var str = new Buffer(strlist.join(''), 'hex')
        .toString('base64')
        .replace(/[\+\/=]/g, function (s) {
        return replace_map[s];
    });
    return str;
}
exports.genAuthString = genAuthString;
function parseAuthString(str) {
    str = str.replace(/[-_~]/g, function (s) {
        return reverse_map[s];
    });
    str = new Buffer(str, 'base64').toString('hex');
    var tokenId = str.substring(0, 8) + '-' + str.substring(8, 12) + '-' + str.substring(12, 16) + '-' + str.substring(16, 20) + '-' + str.substring(20, 32);
    var sign = str.substr(32, 32);
    var timestamp = new Date(parseInt(str.substr(64), 16) * 1000);
    return { tokenId, timestamp, sign };
}
exports.parseAuthString = parseAuthString;

//# sourceMappingURL=auth-cert.js.map
