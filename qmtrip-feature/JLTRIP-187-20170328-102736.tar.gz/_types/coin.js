/**
 * Created by wlh on 2016/9/27.
 */
'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const object_1 = require("common/model/object");
const common_1 = require("common/model/common");
const index_1 = require("./index");
const index_2 = require("common/model/index");
var COIN_CHANGE_TYPE;
(function (COIN_CHANGE_TYPE) {
    COIN_CHANGE_TYPE[COIN_CHANGE_TYPE["INCOME"] = 1] = "INCOME";
    COIN_CHANGE_TYPE[COIN_CHANGE_TYPE["AWARD"] = 2] = "AWARD";
    COIN_CHANGE_TYPE[COIN_CHANGE_TYPE["FREE_LOCK"] = 3] = "FREE_LOCK";
    COIN_CHANGE_TYPE[COIN_CHANGE_TYPE["CONSUME"] = -1] = "CONSUME";
    COIN_CHANGE_TYPE[COIN_CHANGE_TYPE["LOCK"] = -2] = "LOCK";
})(COIN_CHANGE_TYPE = exports.COIN_CHANGE_TYPE || (exports.COIN_CHANGE_TYPE = {}));
exports.coin_change_str = {
    1: '收入',
    2: '奖励',
    3: '解锁',
    '-1': '消费',
    '-2': '冻结'
};
let CoinAccount = class CoinAccount extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    ;
    get id() { return index_2.Values.UUIDV1(); }
    set id(id) { }
    //总收入
    get income() { return 0; }
    set income(income) { }
    //消费掉的
    get consume() { return 0; }
    set consume(consume) { }
    //锁定金额
    get locks() { return 0; }
    set locks(coins) { }
    //是否允许超支
    get isAllowOverCost() { return false; }
    set isAllowOverCost(bool) { }
    //可用余额
    get balance() { return this.income - this.consume - this.locks; }
    findChanges(options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!options) {
                options = {};
            }
            if (!options.where) {
                options.where = {};
            }
            options.where.coinAccountId = this.id;
            return index_1.Models.coinAccountChange.find(options);
        });
    }
    addCoin(coins, remark, duiBaOrderNum, type) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            //先记录日志
            let coinAccountNo = getOrderNo();
            let log = yield index_1.Models.coinAccountChange.create({ orderNum: coinAccountNo, type: type || COIN_CHANGE_TYPE.INCOME, coinAccountId: self.id, coins: coins, remark: remark, duiBaOrderNum: duiBaOrderNum });
            log = yield log.save();
            if (!self.income) {
                self.income = 0;
            }
            if (typeof self.income == 'string') {
                self.income = Number(self.income);
            }
            if (typeof coins == 'string') {
                coins = Number(coins);
            }
            self.income = self.income + coins;
            let coinAccount = yield self.save();
            return { coinAccount: coinAccount, coinAccountChange: log };
        });
    }
    costCoin(coins, remark, duiBaOrderNum) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            let balance = self.balance;
            if (!self.isAllowOverCost && balance <= 0 || self.balance < coins) {
                throw new Error(`余额不足`);
            }
            /*if(!this.isLocal){
                API.require('seeds');
                await API.onload();
            }
            //先记录日志
            let coinAccountNo = await API.seeds.getSeedNo('CoinAccountNo');*/
            let coinAccountNo = getOrderNo();
            let log = yield index_1.Models.coinAccountChange.create({ orderNum: coinAccountNo, type: COIN_CHANGE_TYPE.CONSUME, coinAccountId: self.id, coins: coins, remark: remark, duiBaOrderNum: duiBaOrderNum });
            log = yield log.save();
            if (!self.consume) {
                self.consume = 0;
            }
            if (typeof self.consume == 'string') {
                self.consume = Number(self.consume);
            }
            if (typeof coins == 'string') {
                coins = Number(coins);
            }
            self.consume = self.consume + coins;
            let coinAccount = yield self.save();
            return { coinAccount: coinAccount, coinAccountChange: log };
        });
    }
    lockCoin(coins, remark, duiBaOrderNum) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            let balance = self.balance;
            if (!self.isAllowOverCost && balance <= 0 || self.balance < coins) {
                throw new Error(`余额不足`);
            }
            /*if(!this.isLocal){
                API.require('seeds');
                await API.onload();
            }
            //先记录日志
            let coinAccountNo = await API.seeds.getSeedNo('CoinAccountNo');*/
            let coinAccountNo = getOrderNo();
            let log = yield index_1.Models.coinAccountChange.create({ orderNum: coinAccountNo, type: COIN_CHANGE_TYPE.LOCK, coinAccountId: self.id, coins: coins, remark: remark, duiBaOrderNum: duiBaOrderNum });
            log = yield log.save();
            if (!self.locks) {
                self.locks = 0;
            }
            if (typeof self.locks == 'string') {
                self.locks = Number(self.locks);
            }
            if (typeof coins == 'string') {
                coins = Number(coins);
            }
            self.locks = self.locks + coins;
            let coinAccount = yield self.save();
            return { coinAccount: coinAccount, coinAccountChange: log };
        });
    }
    freeCoin(coins, remark) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            if (self.locks < coins) {
                throw new Error('解锁金额大于锁定金额');
            }
            /*if(!this.isLocal){
                API.require('seeds');
                await API.onload();
            }
            //先记录日志
            let coinAccountNo = await API.seeds.getSeedNo('CoinAccountNo');*/
            let coinAccountNo = getOrderNo();
            let log = yield index_1.Models.coinAccountChange.create({ orderNum: coinAccountNo, type: COIN_CHANGE_TYPE.FREE_LOCK, coinAccountId: self.id, coins: coins, remark: remark });
            log = yield log.save();
            if (typeof self.locks == 'string') {
                self.locks = Number(self.locks);
            }
            if (typeof coins == 'string') {
                coins = Number(coins);
            }
            self.locks = self.locks - coins;
            if (self.locks < 0) {
                self.locks = 0;
            }
            return self.save();
        });
    }
    getCoinAccountChanges(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            if (!params)
                params = {};
            if (!params.where)
                params.where = {};
            params.where.coinAccountId = self.id;
            return index_1.Models.coinAccountChange.find(params);
        });
    }
};
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.UUID })
], CoinAccount.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.NUMERIC(15, 2), defaultValue: 0 })
], CoinAccount.prototype, "income", null);
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.NUMERIC(15, 2), defaultValue: 0 })
], CoinAccount.prototype, "consume", null);
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.NUMERIC(15, 2), defaultValue: 0 })
], CoinAccount.prototype, "locks", null);
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.BOOLEAN })
], CoinAccount.prototype, "isAllowOverCost", null);
tslib_1.__decorate([
    common_1.LocalCall()
], CoinAccount.prototype, "findChanges", null);
tslib_1.__decorate([
    common_1.LocalCall()
], CoinAccount.prototype, "addCoin", null);
tslib_1.__decorate([
    common_1.LocalCall()
], CoinAccount.prototype, "costCoin", null);
tslib_1.__decorate([
    common_1.LocalCall()
], CoinAccount.prototype, "lockCoin", null);
tslib_1.__decorate([
    common_1.LocalCall()
], CoinAccount.prototype, "freeCoin", null);
tslib_1.__decorate([
    common_1.Create()
], CoinAccount, "create", null);
CoinAccount = tslib_1.__decorate([
    common_1.Table(index_1.Models.coinAccount, "coin.coin_accounts")
], CoinAccount);
exports.CoinAccount = CoinAccount;
let CoinAccountChange = class CoinAccountChange extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return index_2.Values.UUIDV1(); }
    set id(id) { }
    get coinAccountId() { return null; }
    set coinAccountId(id) { }
    get type() { return COIN_CHANGE_TYPE.INCOME; }
    set type(type) { }
    set coins(coins) { }
    get coins() { return 0; }
    set remark(remark) { }
    get remark() { return ''; }
    get orderNum() { return null; }
    set orderNum(orderNum) { }
    get duiBaOrderNum() { return null; }
    set duiBaOrderNum(duiBaOrderNum) { }
};
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.UUID })
], CoinAccountChange.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.UUID })
], CoinAccountChange.prototype, "coinAccountId", null);
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.INTEGER })
], CoinAccountChange.prototype, "type", null);
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.NUMERIC(15, 2), defaultValue: 0 })
], CoinAccountChange.prototype, "coins", null);
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.TEXT })
], CoinAccountChange.prototype, "remark", null);
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.STRING })
], CoinAccountChange.prototype, "orderNum", null);
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.STRING })
], CoinAccountChange.prototype, "duiBaOrderNum", null);
tslib_1.__decorate([
    common_1.Create()
], CoinAccountChange, "create", null);
CoinAccountChange = tslib_1.__decorate([
    common_1.Table(index_1.Models.coinAccountChange, "coin.coin_account_changes")
], CoinAccountChange);
exports.CoinAccountChange = CoinAccountChange;
function getOrderNo() {
    var d = new Date();
    var rnd = (Math.ceil(Math.random() * 1000));
    var str = `${d.getFullYear()}${d.getMonth() + 1}${d.getDate()}${d.getHours()}${d.getMinutes()}${d.getSeconds()}-${rnd}`;
    return str;
}

//# sourceMappingURL=coin.js.map
