"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const helper_1 = require("common/api/helper");
let TrafficBudget = class TrafficBudget {
    constructor(obj) {
        this.price = obj.price;
        this.trafficType = obj.trafficType;
        this.bookUrl = obj.bookUrl;
        this.recommend = obj.recommend;
    }
};
TrafficBudget = tslib_1.__decorate([
    helper_1.regApiType('API.')
], TrafficBudget);
exports.TrafficBudget = TrafficBudget;
let HotelBudget = class HotelBudget {
    constructor(obj) {
        this.price = obj.price;
        this.bookUrl = obj.bookUrl;
        this.recommend = obj.recommend;
        this.city = obj.city;
    }
};
HotelBudget = tslib_1.__decorate([
    helper_1.regApiType('API.')
], HotelBudget);
exports.HotelBudget = HotelBudget;

//# sourceMappingURL=budget.js.map
