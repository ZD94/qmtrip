/**
 * Created by wlh on 2016/11/15.
 */
'use strict';
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const object_1 = require("common/model/object");
const common_1 = require("common/model/common");
const index_1 = require("../index");
const index_2 = require("common/model/index");
const types_1 = require("./types");
let Approve = class Approve extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static Create(obj) {
        return null;
    }
    //审批单ID
    get id() { return index_2.Values.UUIDV1(); }
    set id(id) { }
    //提交人
    get submitter() { return null; }
    set submitter(submitter) { }
    //审核人
    get approveUser() { return null; }
    set approveUser(approveUser) { }
    //审批单描述
    get title() { return null; }
    set title(title) { }
    //审批时间
    get approveDateTime() { return null; }
    set approveDateTime(d) { }
    get status() { return types_1.EApproveStatus.WAIT_APPROVE; }
    set status(status) { }
    get type() { return types_1.EApproveType.TRAVEL_BUDGET; }
    set type(type) { }
    get channel() { return types_1.EApproveChannel.QM; }
    set channel(channel) { }
    get data() { return null; }
    set data(data) { }
    get isSpecialApprove() { return false; }
    set isSpecialApprove(isSpecialApprove) { }
    get specialApproveRemark() { return null; }
    set specialApproveRemark(remark) { }
    get outerId() { return null; }
    set outerId(outerId) { }
    get companyId() { return null; }
    set companyId(companyId) { }
};
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.UUID })
], Approve.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.UUID })
], Approve.prototype, "submitter", null);
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.UUID })
], Approve.prototype, "approveUser", null);
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.STRING })
], Approve.prototype, "title", null);
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.DATE })
], Approve.prototype, "approveDateTime", null);
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.INTEGER })
], Approve.prototype, "status", null);
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.INTEGER })
], Approve.prototype, "type", null);
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.INTEGER })
], Approve.prototype, "channel", null);
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.JSONB })
], Approve.prototype, "data", null);
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.BOOLEAN })
], Approve.prototype, "isSpecialApprove", null);
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.TEXT })
], Approve.prototype, "specialApproveRemark", null);
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.STRING(50) })
], Approve.prototype, "outerId", null);
tslib_1.__decorate([
    common_1.Field({ type: index_2.Types.UUID })
], Approve.prototype, "companyId", null);
tslib_1.__decorate([
    common_1.Create()
], Approve, "Create", null);
Approve = tslib_1.__decorate([
    common_1.Table(index_1.Models.approve, "approve.")
], Approve);
exports.Approve = Approve;
__export(require("./types"));

//# sourceMappingURL=index.js.map
