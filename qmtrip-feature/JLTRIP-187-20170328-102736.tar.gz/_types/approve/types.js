/**
 * Created by wlh on 2016/11/15.
 */
'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
var EApproveStatus;
(function (EApproveStatus) {
    EApproveStatus[EApproveStatus["FAIL"] = -1] = "FAIL";
    EApproveStatus[EApproveStatus["WAIT_APPROVE"] = 0] = "WAIT_APPROVE";
    EApproveStatus[EApproveStatus["SUCCESS"] = 1] = "SUCCESS";
})(EApproveStatus = exports.EApproveStatus || (exports.EApproveStatus = {}));
var EApproveType;
(function (EApproveType) {
    EApproveType[EApproveType["TRAVEL_BUDGET"] = 1] = "TRAVEL_BUDGET";
})(EApproveType = exports.EApproveType || (exports.EApproveType = {}));
var EApproveChannel;
(function (EApproveChannel) {
    EApproveChannel[EApproveChannel["QM"] = 1] = "QM";
    EApproveChannel[EApproveChannel["DING_TALK"] = 2] = "DING_TALK";
    EApproveChannel[EApproveChannel["AUTO"] = 3] = "AUTO";
})(EApproveChannel = exports.EApproveChannel || (exports.EApproveChannel = {}));

//# sourceMappingURL=types.js.map
