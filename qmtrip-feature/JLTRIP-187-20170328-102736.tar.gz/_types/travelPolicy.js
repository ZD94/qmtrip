"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const _types_1 = require("_types");
const model_1 = require("common/model");
const common_1 = require("common/model/common");
const object_1 = require("common/model/object");
exports.MTrainLevel = {
    1: "商务座",
    2: "一等座",
    3: "二等座",
    4: '特等座',
    5: '高级软卧',
    6: '软卧',
    7: '硬卧',
    8: '软座',
    9: '硬座',
    10: '无座'
};
var ETrainLevel;
(function (ETrainLevel) {
    // BUSINESS = 1,
    // FIRST_CLASS = 2,
    // SECOND_CLASS = 3,
    ETrainLevel[ETrainLevel["BUSINESS_SEAT"] = 1] = "BUSINESS_SEAT";
    ETrainLevel[ETrainLevel["FIRST_SEAT"] = 2] = "FIRST_SEAT";
    ETrainLevel[ETrainLevel["SECOND_SEAT"] = 3] = "SECOND_SEAT";
    ETrainLevel[ETrainLevel["PRINCIPAL_SEAT"] = 4] = "PRINCIPAL_SEAT";
    ETrainLevel[ETrainLevel["SENIOR_SOFT_SLEEPER"] = 5] = "SENIOR_SOFT_SLEEPER";
    ETrainLevel[ETrainLevel["SOFT_SLEEPER"] = 6] = "SOFT_SLEEPER";
    ETrainLevel[ETrainLevel["HARD_SLEEPER"] = 7] = "HARD_SLEEPER";
    ETrainLevel[ETrainLevel["SOFT_SEAT"] = 8] = "SOFT_SEAT";
    ETrainLevel[ETrainLevel["HARD_SEAT"] = 9] = "HARD_SEAT";
    ETrainLevel[ETrainLevel["NO_SEAT"] = 10] = "NO_SEAT";
})(ETrainLevel = exports.ETrainLevel || (exports.ETrainLevel = {}));
function enumTrainLevelToStr(trainLevels) {
    if (!trainLevels)
        return '';
    return trainLevels.map((trainLevel) => {
        return exports.MTrainLevel[trainLevel];
    }).join("、");
}
exports.enumTrainLevelToStr = enumTrainLevelToStr;
exports.MHotelLevel = {
    5: "国际五星",
    4: "高端商务",
    3: "精品连锁",
    2: "快捷连锁"
};
var EHotelLevel;
(function (EHotelLevel) {
    EHotelLevel[EHotelLevel["FIVE_STAR"] = 5] = "FIVE_STAR";
    EHotelLevel[EHotelLevel["FOUR_STAR"] = 4] = "FOUR_STAR";
    EHotelLevel[EHotelLevel["THREE_STAR"] = 3] = "THREE_STAR";
    EHotelLevel[EHotelLevel["TWO_STAR"] = 2] = "TWO_STAR";
})(EHotelLevel = exports.EHotelLevel || (exports.EHotelLevel = {}));
function enumHotelLevelToStr(hotelLevels) {
    if (!hotelLevels)
        return '';
    return hotelLevels.map((hotelLevel) => {
        return exports.MHotelLevel[hotelLevel];
    }).join("、");
}
exports.enumHotelLevelToStr = enumHotelLevelToStr;
function enumHotelsFormat(hotelLevels) {
    if (!hotelLevels)
        return [];
    return hotelLevels.map((v) => {
        return { name: exports.MHotelLevel[v], value: v };
    });
}
exports.enumHotelsFormat = enumHotelsFormat;
exports.MPlaneLevel = {
    // 1: "公务舱/头等舱",
    2: "经济舱",
    3: '头等舱',
    4: '商务舱',
    5: '高端经济舱',
};
var EPlaneLevel;
(function (EPlaneLevel) {
    // BUSINESS_FIRST = 1,
    EPlaneLevel[EPlaneLevel["ECONOMY"] = 2] = "ECONOMY";
    EPlaneLevel[EPlaneLevel["FIRST"] = 3] = "FIRST";
    EPlaneLevel[EPlaneLevel["BUSINESS"] = 4] = "BUSINESS";
    EPlaneLevel[EPlaneLevel["PREMIUM_ECONOMY"] = 5] = "PREMIUM_ECONOMY";
})(EPlaneLevel = exports.EPlaneLevel || (exports.EPlaneLevel = {}));
function enumPlaneLevelToStr(planeLevels) {
    if (!planeLevels)
        return '';
    return planeLevels.map((planeLevel) => {
        return exports.MPlaneLevel[planeLevel];
    }).join('、');
}
exports.enumPlaneLevelToStr = enumPlaneLevelToStr;
let TravelPolicy = class TravelPolicy extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(val) { }
    get name() { return null; }
    set name(name) { }
    get planeLevels() { return null; }
    set planeLevels(val) { }
    get planeDiscount() { return null; }
    set planeDiscount(planeDiscount) { }
    get trainLevels() { return null; }
    set trainLevels(val) { }
    get hotelLevels() { return null; }
    set hotelLevels(val) { }
    get hotelPrice() { return null; }
    set hotelPrice(hotelPrice) { }
    get subsidy() { return 0; }
    set subsidy(subsidy) { }
    get isChangeLevel() { return null; }
    set isChangeLevel(isChangeLevel) { }
    get isDefault() { return false; }
    set isDefault(isDefault) { }
    get company() { return null; }
    set company(val) { }
    get isOpenAbroad() { return false; }
    set isOpenAbroad(b) { }
    get abroadPlaneLevels() { return null; }
    set abroadPlaneLevel(planeLevel) { }
    get abroadTrainLevels() { return null; }
    set abroadTrainLevel(trainLevel) { }
    get abroadHotelLevels() { return null; }
    set abroadHotelLevel(hotelLevel) { }
    getStaffs() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let query = { where: { companyId: this.company.id, travelPolicyId: this.id } };
            let pager = yield _types_1.Models.staff.find(query);
            return pager;
        });
    }
    getSubsidyTemplates() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let query = { where: { travelPolicyId: this.id } };
            return _types_1.Models.subsidyTemplate.find(query);
        });
    }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], TravelPolicy.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(50) })
], TravelPolicy.prototype, "name", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.ARRAY(model_1.Types.INTEGER) })
], TravelPolicy.prototype, "planeLevels", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DOUBLE })
], TravelPolicy.prototype, "planeDiscount", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.ARRAY(model_1.Types.INTEGER) })
], TravelPolicy.prototype, "trainLevels", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.ARRAY(model_1.Types.INTEGER) })
], TravelPolicy.prototype, "hotelLevels", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DOUBLE })
], TravelPolicy.prototype, "hotelPrice", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.NUMERIC(15, 2) })
], TravelPolicy.prototype, "subsidy", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], TravelPolicy.prototype, "isChangeLevel", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], TravelPolicy.prototype, "isDefault", null);
tslib_1.__decorate([
    common_1.ResolveRef({ type: model_1.Types.UUID }, _types_1.Models.company)
], TravelPolicy.prototype, "company", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], TravelPolicy.prototype, "isOpenAbroad", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.ARRAY(model_1.Types.INTEGER) }) //国际机票
], TravelPolicy.prototype, "abroadPlaneLevels", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.ARRAY(model_1.Types.INTEGER) }) //国际火车
], TravelPolicy.prototype, "abroadTrainLevels", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.ARRAY(model_1.Types.INTEGER) }) //国际酒店
], TravelPolicy.prototype, "abroadHotelLevels", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], TravelPolicy.prototype, "getStaffs", null);
tslib_1.__decorate([
    common_1.Create()
], TravelPolicy, "create", null);
TravelPolicy = tslib_1.__decorate([
    common_1.Table(_types_1.Models.travelPolicy, "travelPolicy.")
], TravelPolicy);
exports.TravelPolicy = TravelPolicy;
let SubsidyTemplate = class SubsidyTemplate extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(val) { }
    //补助金额
    get subsidyMoney() { return null; }
    set subsidyMoney(value) { }
    //模板名称
    get name() { return null; }
    set name(val) { }
    //所属差旅标准
    get travelPolicy() { return null; }
    set travelPolicy(val) { }
    get isInternal() { return false; }
    set isInternal(b) { }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], SubsidyTemplate.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.NUMERIC(15, 2) })
], SubsidyTemplate.prototype, "subsidyMoney", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(50) })
], SubsidyTemplate.prototype, "name", null);
tslib_1.__decorate([
    common_1.ResolveRef({ type: model_1.Types.UUID }, _types_1.Models.travelPolicy)
], SubsidyTemplate.prototype, "travelPolicy", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], SubsidyTemplate.prototype, "isInternal", null);
tslib_1.__decorate([
    common_1.Create()
], SubsidyTemplate, "create", null);
SubsidyTemplate = tslib_1.__decorate([
    common_1.Table(_types_1.Models.subsidyTemplate, "travelPolicy.")
], SubsidyTemplate);
exports.SubsidyTemplate = SubsidyTemplate;

//# sourceMappingURL=travelPolicy.js.map
