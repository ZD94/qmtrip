'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const _types_1 = require("_types");
const model_1 = require("common/model");
const common_1 = require("common/model/common");
const object_1 = require("common/model/object");
let StaffSupplierInfo = class StaffSupplierInfo extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(val) { }
    // 用户供应商网站登录信息
    get loginInfo() { return null; }
    ;
    set loginInfo(val) { }
    // 是否经过验证
    get isVerified() { return true; }
    set isVerified(val) { }
    //所属员工
    get staff() { return null; }
    set staff(val) { }
    //所属供应商
    get supplier() { return null; }
    set supplier(val) { }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], StaffSupplierInfo.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.JSONB })
], StaffSupplierInfo.prototype, "loginInfo", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.BOOLEAN })
], StaffSupplierInfo.prototype, "isVerified", null);
tslib_1.__decorate([
    common_1.ResolveRef({ type: model_1.Types.UUID }, _types_1.Models.staff)
], StaffSupplierInfo.prototype, "staff", null);
tslib_1.__decorate([
    common_1.ResolveRef({ type: model_1.Types.UUID }, _types_1.Models.supplier)
], StaffSupplierInfo.prototype, "supplier", null);
tslib_1.__decorate([
    common_1.Create()
], StaffSupplierInfo, "create", null);
StaffSupplierInfo = tslib_1.__decorate([
    common_1.Table(_types_1.Models.staffSupplierInfo, 'staff.')
], StaffSupplierInfo);
exports.StaffSupplierInfo = StaffSupplierInfo;

//# sourceMappingURL=staff-supplier-info.js.map
