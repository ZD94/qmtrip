"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const common_1 = require("common/model/common");
const _types_1 = require("_types");
const object_1 = require("common/model/object");
const model_1 = require("common/model");
let PointChange = class PointChange extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(val) { }
    get staff() { return null; }
    getCompany(id) {
        return _types_1.Models.company.get(id);
    }
    getTripPlan(id) {
        return _types_1.Models.tripPlan.get(id);
    }
    get status() { return 1; }
    set status(status) { }
    get points() { return null; }
    set points(points) { }
    get currentPoint() { return null; }
    set currentPoint(currentPoint) { }
    get remark() { return null; }
    set remark(remark) { }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], PointChange.prototype, "id", null);
tslib_1.__decorate([
    common_1.ResolveRef({ type: model_1.Types.UUID }, _types_1.Models.staff)
], PointChange.prototype, "staff", null);
tslib_1.__decorate([
    common_1.Reference({ type: model_1.Types.UUID })
], PointChange.prototype, "getCompany", null);
tslib_1.__decorate([
    common_1.Reference({ type: model_1.Types.UUID }, 'orderId')
], PointChange.prototype, "getTripPlan", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER, defaultValue: 1 })
], PointChange.prototype, "status", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.NUMERIC(15, 2) })
], PointChange.prototype, "points", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.NUMERIC(15, 2) })
], PointChange.prototype, "currentPoint", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.TEXT })
], PointChange.prototype, "remark", null);
tslib_1.__decorate([
    common_1.Create()
], PointChange, "create", null);
PointChange = tslib_1.__decorate([
    common_1.Table(_types_1.Models.pointChange, "staff.")
], PointChange);
exports.PointChange = PointChange;

//# sourceMappingURL=point-change.js.map
