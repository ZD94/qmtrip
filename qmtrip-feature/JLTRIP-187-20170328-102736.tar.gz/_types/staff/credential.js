"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const common_1 = require("common/model/common");
const _types_1 = require("_types");
const object_1 = require("common/model/object");
const model_1 = require("common/model");
let Credential = class Credential extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(val) { }
    get type() { return 0; }
    set type(type) { }
    get idNo() { return null; }
    set idNo(idNo) { }
    get birthday() { return null; }
    set birthday(birthday) { }
    get validData() { return null; }
    set validData(validData) { }
    get owner() { return null; }
    set owner(val) { }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], Credential.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER, defaultValue: 0 })
], Credential.prototype, "type", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(50) })
], Credential.prototype, "idNo", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DATE })
], Credential.prototype, "birthday", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DATE })
], Credential.prototype, "validData", null);
tslib_1.__decorate([
    common_1.ResolveRef({ type: model_1.Types.UUID }, _types_1.Models.staff)
], Credential.prototype, "owner", null);
tslib_1.__decorate([
    common_1.Create()
], Credential, "create", null);
Credential = tslib_1.__decorate([
    common_1.Table(_types_1.Models.credential, "staff.")
], Credential);
exports.Credential = Credential;

//# sourceMappingURL=credential.js.map
