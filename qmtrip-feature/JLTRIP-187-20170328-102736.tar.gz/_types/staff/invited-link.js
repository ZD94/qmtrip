"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const model_1 = require("common/model");
const common_1 = require("common/model/common");
const _types_1 = require("_types");
const object_1 = require("common/model/object");
var EInvitedLinkStatus;
(function (EInvitedLinkStatus) {
    EInvitedLinkStatus[EInvitedLinkStatus["ACTIVE"] = 1] = "ACTIVE";
    EInvitedLinkStatus[EInvitedLinkStatus["FORBIDDEN"] = 0] = "FORBIDDEN";
})(EInvitedLinkStatus = exports.EInvitedLinkStatus || (exports.EInvitedLinkStatus = {}));
;
let InvitedLink = class InvitedLink extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    get id() { return model_1.Values.UUIDV1(); }
    set id(val) { }
    get staff() { return null; }
    set staff(val) { }
    get expiresTime() { return null; }
    set expiresTime(val) { }
    get status() { return EInvitedLinkStatus.ACTIVE; }
    set status(status) { }
    get goInvitedLink() { return ''; }
    set goInvitedLink(val) { }
    get linkToken() { return null; }
    set linkToken(linkToken) { }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], InvitedLink.prototype, "id", null);
tslib_1.__decorate([
    common_1.ResolveRef({ type: model_1.Types.UUID }, _types_1.Models.staff)
], InvitedLink.prototype, "staff", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DATE })
], InvitedLink.prototype, "expiresTime", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER, defaultValue: EInvitedLinkStatus.ACTIVE })
], InvitedLink.prototype, "status", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], InvitedLink.prototype, "goInvitedLink", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], InvitedLink.prototype, "linkToken", null);
tslib_1.__decorate([
    common_1.Create()
], InvitedLink, "create", null);
InvitedLink = tslib_1.__decorate([
    common_1.Table(_types_1.Models.invitedLink, "staff.")
], InvitedLink);
exports.InvitedLink = InvitedLink;

//# sourceMappingURL=invited-link.js.map
