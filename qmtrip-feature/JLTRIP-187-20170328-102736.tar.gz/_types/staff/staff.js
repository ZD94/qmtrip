"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const _types_1 = require("_types");
const tripPlan_1 = require("_types/tripPlan");
const model_1 = require("common/model");
const auth_1 = require("_types/auth");
const model_2 = require("common/model");
const common_1 = require("common/model/common");
const object_1 = require("common/model/object");
const coin_1 = require("_types/coin");
const language_1 = require("common/language");
const notice_1 = require("../notice/notice");
const staffDepartment_1 = require("../department/staffDepartment");
const C = require("config");
const moment = require("moment");
const token_1 = require("_types/auth/token");
const helper_1 = require("common/api/helper");
let db = require("common/model").DB;
let API = require("common/api");
let getSupplier;
var EStaffStatus;
(function (EStaffStatus) {
    EStaffStatus[EStaffStatus["FORBIDDEN"] = 0] = "FORBIDDEN";
    EStaffStatus[EStaffStatus["ON_JOB"] = 1] = "ON_JOB";
    EStaffStatus[EStaffStatus["QUIT_JOB"] = -1] = "QUIT_JOB";
    EStaffStatus[EStaffStatus["DELETE"] = -2] = "DELETE";
})(EStaffStatus = exports.EStaffStatus || (exports.EStaffStatus = {}));
var EAddWay;
(function (EAddWay) {
    EAddWay[EAddWay["ADMIN_ADD"] = 0] = "ADMIN_ADD";
    EAddWay[EAddWay["BATCH_IMPORT"] = 1] = "BATCH_IMPORT";
    EAddWay[EAddWay["INVITED"] = 2] = "INVITED";
})(EAddWay = exports.EAddWay || (exports.EAddWay = {}));
var EStaffRole;
(function (EStaffRole) {
    EStaffRole[EStaffRole["OWNER"] = 0] = "OWNER";
    EStaffRole[EStaffRole["COMMON"] = 1] = "COMMON";
    EStaffRole[EStaffRole["ADMIN"] = 2] = "ADMIN";
    // FINANCE = 3
})(EStaffRole = exports.EStaffRole || (exports.EStaffRole = {}));
exports.EStaffRoleNames = [];
exports.EStaffRoleNames[EStaffRole.OWNER] = '创建者';
exports.EStaffRoleNames[EStaffRole.COMMON] = '员工';
exports.EStaffRoleNames[EStaffRole.ADMIN] = '管理员';
// EStaffRoleNames[EStaffRole.FINANCE] = '财务';
//function enumValues(e){
//    return Object.keys(e).map((k)=>e[k]).filter((v)=>(typeof v != 'number'));
//}
let Staff = Staff_1 = class Staff extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    static getCurrent() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            yield Staff_1['$model'].$resolve();
            let session = model_2.getSession();
            if (session.currentStaff)
                return session.currentStaff;
            if (!session.accountId)
                return null;
            var account = yield _types_1.Models.account.get(session.accountId);
            if (!account || account.type != _types_1.EAccountType.STAFF)
                return null;
            var staff = yield _types_1.Models.staff.get(session.accountId);
            session.currentStaff = staff;
            return staff;
        });
    }
    get id() { return model_1.Values.UUIDV1(); }
    set id(val) { }
    // '员工名称'
    get name() { return null; }
    set name(val) { }
    // '性别'
    get sex() { return _types_1.EGender.MALE; }
    set sex(val) { }
    // '员工头像'
    get avatar() { return ''; }
    set avatar(val) { }
    // '员工头像颜色'
    get avatarColor() { return ''; }
    set avatarColor(val) { }
    //状态
    get staffStatus() { return EStaffStatus.ON_JOB; }
    set staffStatus(val) { }
    // '员工总获取的积分'
    get totalPoints() { return 0.00; }
    set totalPoints(val) { }
    // '员工剩余积分'
    get balancePoints() { return 0.00; }
    set balancePoints(val) { }
    // '权限'
    get roleId() { return EStaffRole.COMMON; }
    set roleId(val) { }
    // '操作人id'
    get operatorId() { return null; }
    set operatorId(val) { }
    // '离职时间'
    get quitTime() { return null; }
    set quitTime(val) { }
    get company() { return null; }
    set company(val) { }
    getTravelPolicy(id) {
        return _types_1.Models.travelPolicy.get(id);
    }
    setTravelPolicy(val) { }
    // '添加方式'
    get addWay() { return EAddWay.ADMIN_ADD; }
    set addWay(val) { }
    getDepartments() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let departmentStaffs = yield _types_1.Models.staffDepartment.find({ where: { staffId: this.id }, order: [['createdAt', 'desc']] });
            let ids = [];
            departmentStaffs.forEach(function (t) {
                ids.push(t.departmentId);
            });
            let departments = yield _types_1.Models.department.find({ where: { id: { $in: ids }, companyId: this.company.id }, order: [['createdAt', 'desc']] });
            return departments;
        });
    }
    getDepartmentsStr() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let departmentStaffs = yield _types_1.Models.staffDepartment.find({ where: { staffId: this.id }, order: [['createdAt', 'desc']] });
            let ids = [];
            departmentStaffs.forEach(function (t) {
                ids.push(t.departmentId);
            });
            let departments = yield _types_1.Models.department.find({ where: { id: { $in: ids }, companyId: this.company.id }, order: [['createdAt', 'desc']] });
            let departmentNames = departments.map(function (item) {
                return item.name;
            });
            return departmentNames.join(',');
        });
    }
    saveStaffDepartments(departmentIds) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            let staffId = this.id;
            let company = this.company;
            let defaultDeptment = yield company.getDefaultDepartment();
            if (!departmentIds || !(departmentIds.length > 0)) {
                let staffDepartment = staffDepartment_1.StaffDepartment.create({ staffId: self.id, departmentId: defaultDeptment.id });
                yield staffDepartment.save();
            }
            else {
                yield Promise.all(departmentIds.map(function (item) {
                    return tslib_1.__awaiter(this, void 0, void 0, function* () {
                        let staffDept = staffDepartment_1.StaffDepartment.create({ staffId: staffId, departmentId: item });
                        yield staffDept.save();
                    });
                }));
            }
            return true;
        });
    }
    /**
     *  批量移动员工
     *  @time 2017.3.7
     *  @param params
     *  @return {*}
     */
    moveStaffsDepartment(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            let { staffIds, departmentIds, fromDepartmentId } = params;
            if (self.roleId != EStaffRole.ADMIN && self.roleId != EStaffRole.OWNER) {
                throw language_1.default.ERR.PERMISSION_DENY();
            }
            for (let i = 0, ii = staffIds.length; i < ii; i++) {
                let staff = yield _types_1.Models.staff.get(staffIds[i]);
                for (let j = 0, jj = departmentIds.length; j < jj; j++) {
                    let department = yield _types_1.Models.department.get(departmentIds[j]);
                    //比较部门是否与员工是一个公司
                    if (staff.company.id != department.company.id) {
                        continue;
                    }
                    //查关系表
                    let staffDepartment = yield _types_1.Models.staffDepartment.find({
                        where: {
                            "staffId": staff.id,
                            "departmentId": department.id
                        }
                    });
                    if (staffDepartment && staffDepartment.length) {
                        //已经有了，准备删除
                    }
                    else {
                        //插入数据
                        yield (yield _types_1.Models.staffDepartment.create({
                            staffId: staff.id, departmentId: department.id
                        })).save();
                    }
                }
                //删除数据
                if (departmentIds.indexOf(fromDepartmentId) > -1) {
                    //移入的部门中包含了本部门
                }
                else {
                    let fromData = yield _types_1.Models.staffDepartment.find({
                        where: {
                            "staffId": staff.id,
                            "departmentId": fromDepartmentId
                        }
                    });
                    if (fromData && fromData.length) {
                        yield fromData[0].destroy();
                    }
                }
            }
            return true;
        });
    }
    deleteStaffDepartments() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            let staffDepartments = yield _types_1.Models.staffDepartment.find({ where: { staffId: self.id } });
            if (staffDepartments && staffDepartments.length > 0) {
                yield Promise.all(staffDepartments.map(function (item) {
                    return tslib_1.__awaiter(this, void 0, void 0, function* () {
                        yield item.destroy();
                    });
                }));
            }
            return true;
        });
    }
    getSelfNotices(options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var self = this;
            if (!options)
                options = { where: {} };
            if (!options.where)
                options.where = {};
            let ids = [];
            let no_ids = [];
            let mna = {};
            //若不查已删除的下边逻辑就会以为已删除的那条通知是未读的全员通知会再加一条进关系表
            let sql = `select id, notice_id as "noticeId", deleted_at as "deletedAt" from notice.notice_accounts where account_id = '${self.id}'`;
            let ret = yield db.query(sql);
            let ids_query = ret[0];
            if (ids_query && ids_query.length > 0) {
                ids_query.forEach(function (t) {
                    mna[t.noticeId] = t;
                    if (t.deletedAt) {
                        no_ids.push(t.noticeId);
                    }
                    else {
                        ids.push(t.noticeId);
                    }
                });
            }
            options.where.$or = [{ id: { $in: ids } }, { sendType: notice_1.ESendType.ALL_ACCOUNT }];
            if (no_ids && no_ids.length > 0) {
                options.where.id = { $notIn: no_ids };
            }
            options.order = options.order || [['createdAt', 'desc']];
            // let sql_query = `select * from notice.notices nn join notice.notice_accounts na on nn.id = na.notice_id
            //  where (na.account_id = '${self.id}' or nn.send_type = ${ESendType.ALL_ACCOUNT}) and nn.type = 1 order by nn.created_at desc limit 5 offset 0`;
            var notices = yield _types_1.Models.notice.find(options);
            var result = yield Promise.all(notices.map(function (n) {
                return tslib_1.__awaiter(this, void 0, void 0, function* () {
                    // 此处处理发给全体员工的 员工拉取通知列表时存入noticeAccount关系表记录（其余发给一个人或多个人的 发消息的时候存入关系表）
                    if (!mna[n.id]) {
                        var na = _types_1.Models.noticeAccount.create({ accountId: self.id, noticeId: n.id, isRead: false });
                        yield na.save();
                    }
                    return n;
                });
            }));
            return notices;
        });
    }
    getTripPlans(options) {
        if (!options) {
            options = { where: {} };
        }
        if (!options.where) {
            options.where = {};
        }
        options.where.accountId = this.id;
        options['order'] = [['startAt', 'desc']];
        return _types_1.Models.tripPlan.find(options);
    }
    getTripApproves(options) {
        if (!options)
            options = { where: {} };
        if (!options.where)
            options.where = {};
        options.where.accountId = this.id;
        return _types_1.Models.tripApprove.find(options);
    }
    getTripApprovesByApproverUser(options) {
        if (!options)
            options = { where: {} };
        if (!options.where)
            options.where = {};
        if (options.where.isApproving) {
            options.where.$or = [{ approveUserId: this.id }, { approvedUsers: { $like: `%${this.id}%` } }];
            delete options.where.isApproving;
        }
        else {
            options.where.approveUserId = this.id;
        }
        return _types_1.Models.tripApprove.find(options);
    }
    getTripPlanSave() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!this.isLocal) {
                API.require('tripPlan');
                yield API.onload();
            }
            return API.tripPlan.getTripPlanSave({ accountId: this.id });
        });
    }
    modifyMobile(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!this.isLocal) {
                API.require('staff');
                yield API.onload();
            }
            params.id = this.id;
            return API.staff.modifyMobile(params);
        });
    }
    modifyEmail(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!this.isLocal) {
                API.require('staff');
                yield API.onload();
            }
            params.id = this.id;
            return API.staff.modifyEmail(params);
        });
    }
    modifyPwd(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!this.isLocal) {
                API.require('staff');
                yield API.onload();
            }
            params.id = this.id;
            return API.staff.modifyPwd(params);
        });
    }
    activeByModifyPwd(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!this.isLocal) {
                API.require('auth');
                yield API.onload();
            }
            params.accountId = this.id;
            return API.auth.activeByModifyPwd(params);
        });
    }
    getOneStaffSupplierInfo(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var options = {};
            options.where = { staffId: this.id, supplierId: params.supplierId };
            var staffInfos = yield _types_1.Models.staffSupplierInfo.find(options);
            if (staffInfos && staffInfos.length > 0) {
                return staffInfos[0];
            }
            return null;
        });
    }
    getOrders(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let supplier = yield _types_1.Models.supplier.get(params.supplierId);
            if (!getSupplier) {
                getSupplier = require('libs/suppliers').getSupplier;
            }
            let client = getSupplier(supplier.supplierKey);
            let staffSupplierInfo = yield this.getOneStaffSupplierInfo({ supplierId: params.supplierId });
            if (!staffSupplierInfo) {
                throw language_1.default.ERR.HAS_NOT_BIND();
            }
            let loginInfo = JSON.parse(staffSupplierInfo.loginInfo);
            try {
                yield client.login({ username: loginInfo.userName, password: loginInfo.pwd });
                let list = yield client.getOrderList();
                //过滤掉不是本人的订单
                list = list.filter((item) => {
                    return item.persons.indexOf(this.name) >= 0;
                });
                let alreadyBindIds = [];
                let invoices = yield _types_1.Models.tripDetailInvoice.find({ where: { accountId: this.id, sourceType: tripPlan_1.ESourceType.RELATE_ORDER } });
                if (invoices && invoices.length > 0) {
                    invoices.forEach(function (item) {
                        alreadyBindIds.push(item.orderId);
                    });
                }
                list = list.map(function (l) {
                    if (alreadyBindIds.indexOf(l.id) >= 0) {
                        l["isBind"] = true;
                    }
                    else {
                        l["isBind"] = false;
                    }
                    return l;
                });
                return list;
            }
            catch (e) {
                throw language_1.default.ERR.BIND_ACCOUNT_ERR();
            }
        });
    }
    relateOrders(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!this.isLocal) {
                API.require('tripPlan');
                yield API.onload();
            }
            return API.tripPlan.relateOrders(params);
        });
    }
    checkStaffSupplierInfo(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let supplier = yield _types_1.Models.supplier.get(params.supplierId);
            if (!getSupplier) {
                getSupplier = require('libs/suppliers').getSupplier;
            }
            let client = getSupplier(supplier.supplierKey);
            try {
                yield client.login({ username: params.userName, password: params.pwd });
                return true;
            }
            catch (e) {
                return false;
            }
        });
    }
    statisticNoticeByType() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            let result = {};
            let sql = `select type, count(*) from notice.notice_accounts na 
        right join notice.notices nn on na.notice_id = nn.id where na.account_id = '${self.id}'  
        and na.deleted_at is null and na.is_read = false or nn.send_type = ${notice_1.ESendType.ALL_ACCOUNT} 
        group by nn.type order by nn.type asc`;
            let ret = yield db.query(sql);
            let arr = ret[0];
            for (let i = 0; i < arr.length; i++) {
                let _sql = `select nn.* from notice.notice_accounts na right join notice.notices nn 
            on na.notice_id = nn.id where na.account_id = '${self.id}' and na.deleted_at is null  
            and na.is_read = false and nn.type = '${arr[i].type}' order by created_at desc limit 1`;
                let na = yield db.query(_sql);
                result[arr[i].type] = { unReadNum: parseInt(arr[i].count), latestInfo: na[0][0] };
            }
            return result;
        });
    }
    getDuiBaLoginUrl(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!this.isLocal) {
                API.require('duiba');
                yield API.onload();
            }
            return API.duiba.getLoginUrl(params);
        });
    }
    getCoinAccountChanges() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            this.coinAccount = this.$parents["account"]["coinAccount"];
            if (!this.coinAccount) {
                let ca = coin_1.CoinAccount.create();
                yield ca.save();
                self.coinAccount = ca;
                let account = yield _types_1.Models.account.get(self.id);
                account.coinAccount = ca;
                yield account.save();
            }
            let coinAccount = self.coinAccount;
            return coinAccount.getCoinAccountChanges({});
        });
    }
    score2Coin(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!this.isLocal) {
                API.require('coin');
                yield API.onload();
            }
            let { points } = params;
            return API.coin.staffPoint2Coin({ staffId: this.id, points: points });
        });
    }
    addCoin(coins, remark, duiBaOrderNum) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            let account = yield _types_1.Models.account.get(self.id);
            this.coinAccount = this.$parents["account"]["coinAccount"];
            if (!this.coinAccount) {
                let ca = coin_1.CoinAccount.create();
                yield ca.save();
                account.coinAccount = ca;
                self.coinAccount = ca;
                yield account.save();
            }
            let coinAccount = yield this.coinAccount.addCoin(coins, remark, duiBaOrderNum);
            return coinAccount;
        });
    }
    testServerFunc() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            console.log('testServerFunc');
            return 'OK';
        });
    }
    getAutoLoginUrl(backUrl, os) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!this.isLocal) {
                API.require('auth');
                yield API.onload();
            }
            let self = this;
            if (os != token_1.OS_TYPE.TMP_CODE) {
                throw language_1.default.ERR.INVALID_ARGUMENT(`目前仅支持企业PC平台自动登录`);
            }
            let expireAt = new Date(moment().add(1, 'days').valueOf());
            let ret = yield API.auth.makeAuthenticateToken(self.id, os, expireAt);
            let authstr = new Buffer(JSON.stringify(ret)).toString('base64');
            return `${C.host}/corp-mgr.html?#/login/?backurl=${backUrl}&authstr=${authstr}`;
        });
    }
    getBatchAddStaffEmail() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            if (!self.email) {
                throw language_1.default.ERR.EMAIL_EMPTY('邮箱还未绑定');
            }
            let url = yield self.getAutoLoginUrl(`${C.host}/corp-mgr.html`, token_1.OS_TYPE.TMP_CODE);
            yield API.notify.submitNotify({
                accountId: self.id,
                values: {
                    url: url,
                    name: self.name,
                },
                key: 'qm_notify_batch_add_staff'
            });
        });
    }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], Staff.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(50) })
], Staff.prototype, "name", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], Staff.prototype, "sex", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.TEXT })
], Staff.prototype, "avatar", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(50) })
], Staff.prototype, "avatarColor", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], Staff.prototype, "staffStatus", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.NUMERIC(15, 2) })
], Staff.prototype, "totalPoints", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.NUMERIC(15, 2) })
], Staff.prototype, "balancePoints", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], Staff.prototype, "roleId", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], Staff.prototype, "operatorId", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.DATE })
], Staff.prototype, "quitTime", null);
tslib_1.__decorate([
    common_1.ResolveRef({ type: model_1.Types.UUID }, _types_1.Models.company)
], Staff.prototype, "company", null);
tslib_1.__decorate([
    common_1.Reference({ type: model_1.Types.UUID })
], Staff.prototype, "getTravelPolicy", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], Staff.prototype, "addWay", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Staff.prototype, "getDepartments", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Staff.prototype, "getDepartmentsStr", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Staff.prototype, "saveStaffDepartments", null);
tslib_1.__decorate([
    helper_1.requireParams(["staffIds", "departmentIds", "fromDepartmentId"]),
    common_1.RemoteCall()
], Staff.prototype, "moveStaffsDepartment", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Staff.prototype, "deleteStaffDepartments", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Staff.prototype, "getSelfNotices", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Staff.prototype, "getOrders", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Staff.prototype, "checkStaffSupplierInfo", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Staff.prototype, "statisticNoticeByType", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Staff.prototype, "addCoin", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Staff.prototype, "testServerFunc", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Staff.prototype, "getAutoLoginUrl", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Staff.prototype, "getBatchAddStaffEmail", null);
tslib_1.__decorate([
    common_1.Create()
], Staff, "create", null);
Staff = Staff_1 = tslib_1.__decorate([
    common_1.TableExtends(auth_1.Account, 'account'),
    common_1.Table(_types_1.Models.staff, "staff.")
], Staff);
exports.Staff = Staff;
var Staff_1;

//# sourceMappingURL=staff.js.map
