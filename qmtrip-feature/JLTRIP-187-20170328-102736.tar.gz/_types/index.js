///<reference path="agency/agency-operate-log.ts"/>
"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
const delegate_1 = require("common/model/delegate");
var EGender;
(function (EGender) {
    EGender[EGender["MALE"] = 1] = "MALE";
    EGender[EGender["FEMALE"] = 2] = "FEMALE";
})(EGender = exports.EGender || (exports.EGender = {}));
;
var EAccountType;
(function (EAccountType) {
    EAccountType[EAccountType["STAFF"] = 1] = "STAFF";
    EAccountType[EAccountType["AGENCY"] = 2] = "AGENCY";
})(EAccountType = exports.EAccountType || (exports.EAccountType = {}));
;
exports.Models = {
    staff: new delegate_1.ModelDelegate(),
    credential: new delegate_1.ModelDelegate(),
    pointChange: new delegate_1.ModelDelegate(),
    invitedLink: new delegate_1.ModelDelegate(),
    staffSupplierInfo: new delegate_1.ModelDelegate(),
    company: new delegate_1.ModelDelegate(),
    moneyChange: new delegate_1.ModelDelegate(),
    supplier: new delegate_1.ModelDelegate(),
    tripPlanNumChange: new delegate_1.ModelDelegate(),
    promoCode: new delegate_1.ModelDelegate(),
    department: new delegate_1.ModelDelegate(),
    staffDepartment: new delegate_1.ModelDelegate(),
    travelPolicy: new delegate_1.ModelDelegate(),
    subsidyTemplate: new delegate_1.ModelDelegate(),
    accordHotel: new delegate_1.ModelDelegate(),
    notice: new delegate_1.ModelDelegate(),
    noticeAccount: new delegate_1.ModelDelegate(),
    agency: new delegate_1.ModelDelegate(),
    agencyUser: new delegate_1.ModelDelegate(),
    agencyOperateLog: new delegate_1.ModelDelegate(),
    tripBasicPackage: new delegate_1.ModelDelegate(),
    tripFuelAddPackage: new delegate_1.ModelDelegate(),
    seed: new delegate_1.ModelDelegate(),
    tripPlan: new delegate_1.ModelDelegate(),
    tripDetail: new delegate_1.ModelDelegate(),
    tripDetailInvoice: new delegate_1.ModelDelegate(),
    tripDetailTraffic: new delegate_1.ModelDelegate(),
    tripDetailHotel: new delegate_1.ModelDelegate(),
    tripDetailSubsidy: new delegate_1.ModelDelegate(),
    tripDetailSpecial: new delegate_1.ModelDelegate(),
    tripPlanLog: new delegate_1.ModelDelegate(),
    project: new delegate_1.ModelDelegate(),
    tripApprove: new delegate_1.ModelDelegate(),
    approve: new delegate_1.ModelDelegate(),
    travelBudgetLog: new delegate_1.ModelDelegate(),
    account: new delegate_1.ModelDelegate(),
    token: new delegate_1.ModelDelegate(),
    financeCheckCode: new delegate_1.ModelDelegate(),
    ddtalkCorp: new delegate_1.ModelDelegate(),
    ddtalkUser: new delegate_1.ModelDelegate(),
    ddtalkDepartment: new delegate_1.ModelDelegate(),
    coinAccount: new delegate_1.ModelDelegate(),
    coinAccountChange: new delegate_1.ModelDelegate(),
};
function initModels(models) {
    for (let k in models) {
        if (exports.Models[k])
            exports.Models[k].setTarget(models[k]);
    }
}
exports.initModels = initModels;
__export(require("./company"));
__export(require("./staff"));
__export(require("./travelPolicy"));
__export(require("./department"));
__export(require("./promoCode"));
__export(require("./accordHotel"));
__export(require("./agency"));
__export(require("./tripPlan"));
__export(require("./auth"));
__export(require("./seed"));
__export(require("./notice"));
__export(require("./tripPackage"));

//# sourceMappingURL=index.js.map
