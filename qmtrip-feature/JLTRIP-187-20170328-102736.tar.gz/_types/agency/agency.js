/**
 * Created by yumiao on 16-4-26.
 */
'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const _types_1 = require("_types");
const model_1 = require("common/model");
const common_1 = require("common/model/common");
const object_1 = require("common/model/object");
const agency_user_1 = require("./agency-user");
//每一个.ts对应一个表，下面的代码是创建一个表，agency.是表的前缀
let Agency = 
//表名使用驼峰命名法
class Agency extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    destroy(options) {
        const _super = name => super[name];
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (this.isLocal) {
                let agencyUsers = yield _types_1.Models.agencyUser.find({ agencyId: this.id });
                yield Promise.all(agencyUsers.map((user) => user.destroy(options)));
            }
            _super("destroy").call(this, options);
        });
    }
    get id() { return model_1.Values.UUIDV1(); }
    set id(val) { }
    get agencyNo() { return ''; }
    set agencyNo(val) { }
    get createUser() { return null; }
    set createUser(val) { }
    get name() { return ''; }
    set name(val) { }
    get description() { return ''; }
    set description(val) { }
    get status() { return agency_user_1.EAgencyStatus.UN_ACTIVE; }
    set status(val) { }
    get email() { return ''; }
    set email(val) { }
    get mobile() { return ''; }
    set mobile(val) { }
    get companyNum() { return 0; }
    set companyNum(val) { }
    get remark() { return ''; }
    set remark(val) { }
    getCompanys() {
        let query = { where: { agencyId: this.id } };
        return _types_1.Models.company.find(query);
    }
    getUsers(options) {
        return _types_1.Models.agencyUser.find(options);
    }
    getTripPlans(options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!options.where) {
                options.where = {};
            }
            if (!options.where.companyId) {
                let companies = yield this.getCompanys();
                let compIds = companies.map((o) => o.id);
                options.where.companyId = { $in: compIds };
            }
            return _types_1.Models.tripPlan.find(options);
        });
    }
    getOperateLogs() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            return _types_1.Models.agencyOperateLog.find({ where: { agencyId: self.id } });
        });
    }
};
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], Agency.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(10) })
], Agency.prototype, "agencyNo", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], Agency.prototype, "createUser", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(100) })
], Agency.prototype, "name", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.TEXT })
], Agency.prototype, "description", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], Agency.prototype, "status", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(30) })
], Agency.prototype, "email", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING(15) })
], Agency.prototype, "mobile", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], Agency.prototype, "companyNum", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], Agency.prototype, "remark", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], Agency.prototype, "getOperateLogs", null);
tslib_1.__decorate([
    common_1.Create()
], Agency, "create", null);
Agency = tslib_1.__decorate([
    common_1.Table(_types_1.Models.agency, 'agency.')
    //表名使用驼峰命名法
], Agency);
exports.Agency = Agency;

//# sourceMappingURL=agency.js.map
