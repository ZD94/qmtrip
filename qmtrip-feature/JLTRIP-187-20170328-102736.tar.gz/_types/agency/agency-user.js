"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const common_1 = require("common/model/common");
const auth_1 = require("../auth");
const _types_1 = require("_types");
const object_1 = require("common/model/object");
const model_1 = require("common/model");
const moment = require("moment");
const company_1 = require("../company/company");
const language_1 = require("common/language");
const coin_1 = require("../coin");
const trip_plan_num_change_1 = require("../company/trip-plan-num-change");
const API = require("common/api");
let sequelize = require("common/model").DB;
var EAgencyStatus;
(function (EAgencyStatus) {
    EAgencyStatus[EAgencyStatus["DELETE"] = -2] = "DELETE";
    EAgencyStatus[EAgencyStatus["UN_ACTIVE"] = 0] = "UN_ACTIVE";
    EAgencyStatus[EAgencyStatus["ACTIVE"] = 1] = "ACTIVE"; //激活状态
})(EAgencyStatus = exports.EAgencyStatus || (exports.EAgencyStatus = {}));
var EAgencyUserRole;
(function (EAgencyUserRole) {
    EAgencyUserRole[EAgencyUserRole["OWNER"] = 0] = "OWNER";
    EAgencyUserRole[EAgencyUserRole["COMMON"] = 1] = "COMMON";
    EAgencyUserRole[EAgencyUserRole["ADMIN"] = 2] = "ADMIN";
})(EAgencyUserRole = exports.EAgencyUserRole || (exports.EAgencyUserRole = {}));
let AgencyUser = AgencyUser_1 = class AgencyUser extends object_1.ModelObject {
    constructor(target) {
        super(target);
    }
    static create(obj) { return null; }
    static getCurrent() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            yield AgencyUser_1['$model'].$resolve();
            let session = model_1.getSession();
            if (session.currentAgencyUser)
                return session.currentAgencyUser;
            if (!session.accountId)
                return null;
            var account = yield _types_1.Models.account.get(session.accountId);
            if (!account || account.type != _types_1.EAccountType.AGENCY)
                return null;
            var agencyUser = yield _types_1.Models.agencyUser.get(session.accountId);
            session.currentAgencyUser = agencyUser;
            return agencyUser;
        });
    }
    findCompanies(options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            let { page, perPage } = options;
            if (!page || !/^\d+$/.test(page)) {
                page = 1;
            }
            if (!perPage || !/^\d+$/.test(perPage)) {
                perPage = 20;
            }
            let sql = `SELECT C.id FROM company.companies AS C `;
            //分页
            let countSQL = `SELECT  count(1) as total FROM company.companies AS C`;
            let where = ` WHERE C.agency_id = '${self.agency.id}' AND `;
            if (options.userName || options.mobile) {
                let piece = ' LEFT JOIN staff.staffs AS S ON S.id = C.create_user ';
                sql += piece;
                countSQL += piece;
            }
            //创建者
            if (options.userName) {
                where += ` S.name like '%${options.userName}%' AND `;
            }
            //关键词
            if (options.keyword) {
                where += ` C.name like '%${options.keyword}%' AND `;
            }
            //联系人的手机号
            if (options.mobile) {
                let piece = ` LEFT JOIN auth.accounts AS A ON A.id = S.id `;
                sql += piece;
                countSQL += piece;
                where += ` A.mobile like '%${options.mobile}%' AND `;
            }
            //注册时间段
            if (options.regDateStart && options.regDateEnd) {
                where += ` C.created_at > '${moment(options.regDateStart).format('YYYY-MM-DD HH:mm:ss')}' AND  C.created_at < ' ${moment(options.regDateEnd).format('YYYY-MM-DD HH:mm:ss')} ' AND `;
            }
            //到期时间
            if (options.days) {
                where += ` C.expiry_date <  '${moment().add(options.days, 'days').format('YYYY-MM-DD HH:mm:ss')}' AND `;
            }
            where = where.replace(/AND\s*$/i, '');
            sql = sql + where;
            sql += `  ORDER BY C.created_at desc LIMIT ${perPage} OFFSET ${(page - 1) * perPage} `;
            countSQL += where;
            let company_ret = yield sequelize.query(sql);
            let num_ret = yield sequelize.query(countSQL);
            let result = {
                total: (num_ret[0][0]['total']),
                items: company_ret[0],
                page: page,
                perPage: perPage
            };
            return result;
        });
    }
    get id() { return model_1.Values.UUIDV1(); }
    set id(val) { }
    get status() { return EAgencyStatus.UN_ACTIVE; }
    set status(val) { }
    get name() { return ''; }
    set name(val) { }
    get sex() { return _types_1.EGender.MALE; }
    set sex(val) { }
    get avatar() { return ''; }
    set avatar(val) { }
    get roleId() { return EAgencyUserRole.COMMON; }
    set roleId(val) { }
    get agency() { return null; }
    set agency(val) { }
    //充值鲸币
    addCompanyCoin(companyId, coin, remark) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            let company = yield _types_1.Models.company.get(companyId);
            let agency = yield company.getAgency();
            if (agency.createUser != self.id) {
                throw language_1.default.ERR.PERMISSION_DENY();
            }
            //先记录操作日志
            let log = yield _types_1.Models.agencyOperateLog.create({
                agency_userId: this.id,
                agencyId: agency.id,
                remark: `因【${remark}】为【${company.name}(${company.id})】充值了【${coin}】鲸币`
            });
            yield log.save();
            //如果没有鲸币账户，创建
            if (!company.coinAccount) {
                let coinAccount = coin_1.CoinAccount.create({});
                coinAccount = yield coinAccount.save();
                company.coinAccount = coinAccount;
                company = yield company.save();
            }
            //给企业加鲸币
            let ret = yield company.coinAccount.addCoin(coin, remark);
            return ret;
        });
    }
    //修改到期时间
    addExpiryDate(companyId, qs) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            let company = yield _types_1.Models.company.get(companyId);
            let agency = yield company.getAgency();
            if (agency.createUser != self.id) {
                throw language_1.default.ERR.PERMISSION_DENY();
            }
            //先记录操作日志
            let log = yield _types_1.Models.agencyOperateLog.create({
                agency_userId: this.id,
                agencyId: agency.id,
                remark: `因【${qs.remark}】为【${company.name}(${company.id})】增加了【${qs.months}】月有效期`
            });
            yield log.save();
            //修改企业到期时间
            let ret = new Date(moment(company.expiryDate).add(qs.months, 'months').valueOf());
            company.expiryDate = ret;
            //企业购买的套餐包id
            if (qs.packageType) {
                company.tripPackageId = qs.packageType.id;
            }
            if (qs.IsChange) {
                company.type = company_1.ECompanyType.PAYED;
            }
            company = yield company.save();
            let staffs = yield this.getCompanyAllStaffs({ companyId: company.id });
            let ps = staffs.map((s) => {
                //给各个员工发送通知
                return API.notify.submitNotify({
                    accountId: s.id,
                    key: "qm_notify_lengthen_expiry_date",
                    values: {
                        expiryDate: moment(company.expiryDate).format('YYYY-MM-DD')
                    }
                });
            });
            yield Promise.all(ps);
            return ret;
        });
    }
    //增加行程流量包
    addFlowPackage(companyId, qs) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            let company = yield _types_1.Models.company.get(companyId);
            let agency = yield company.getAgency();
            if (agency.createUser != self.id) {
                throw language_1.default.ERR.PERMISSION_DENY();
            }
            let chargePackage;
            if (qs.AddFifty) {
                chargePackage = 50;
            }
            else if (qs.AddTwenty) {
                chargePackage = 20;
            }
            //先记录操作日志
            let log = yield _types_1.Models.agencyOperateLog.create({
                agency_userId: this.id,
                agencyId: agency.id,
                remark: `因【${qs.remark}】为【${company.name}(${company.id})】充值了【${chargePackage}】流量包到期时间增加了【3】个月`
            });
            yield log.save();
            //trip_plan_num_changes添加数据
            let changes = yield _types_1.Models.tripPlanNumChange.create({
                companyId: companyId,
                type: trip_plan_num_change_1.NUM_CHANGE_TYPE.SYSTEM_ADD,
                number: chargePackage,
                remark: '后台增加流量包',
                content: '后台增加流量包',
            });
            yield changes.save();
            //修改行程流量包
            let newExtraTripPlanNum;
            if (qs.AddTwenty) {
                newExtraTripPlanNum = company.extraTripPlanNum + 20;
            }
            if (qs.AddFifty) {
                newExtraTripPlanNum = company.extraTripPlanNum + 50;
            }
            company.extraTripPlanNum = newExtraTripPlanNum;
            let newExtraExpiryDate = new Date(moment().add(3, 'months').valueOf());
            company.extraExpiryDate = newExtraExpiryDate;
            return company.save();
        });
    }
    //配置企业偏好
    configPreference(companyId, budgetConfig) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            let company = yield _types_1.Models.company.get(companyId);
            let agency = yield company.getAgency();
            if (agency.createUser != self.id) {
                throw language_1.default.ERR.PERMISSION_DENY();
            }
            let log = yield _types_1.Models.agencyOperateLog.create({
                agency_userId: this.id,
                agencyId: agency.id,
                remark: `为【${company.name}(${company.id})】配置了企业偏好`
            });
            yield log.save();
            //修改企业偏好
            company.budgetConfig = budgetConfig;
            return company.save();
        });
    }
    //agency后台管理流量包 增加流量包种类
    addTripFuelPackage(qs) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let addPackage = yield _types_1.Models.tripFuelAddPackage.create({
                name: qs.name,
                tripNum: qs.tripNum,
                validDays: qs.validDays,
                price: qs.price,
                remark: qs.remark
            });
            yield addPackage.save();
        });
    }
    //agency后台查詢流量包
    findPackages() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let pager = yield _types_1.Models.tripFuelAddPackage.find({ where: {} });
            return pager;
        });
    }
    getCompanyAllStaffs(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            let company = yield _types_1.Models.company.get(params.companyId);
            let staffs = [];
            if (!company) {
                throw language_1.default.ERR.COMPANY_NOT_EXIST();
            }
            let agency = yield company.getAgency();
            if (agency.id != self.agency.id) {
                throw language_1.default.ERR.PERMISSION_DENY("该企业员工");
            }
            let pager = yield _types_1.Models.staff.find({ where: params });
            pager.forEach((s) => {
                staffs.push(s);
            });
            while (pager && pager.hasNextPage()) {
                pager = yield pager.nextPage();
                pager.forEach((s) => {
                    staffs.push(s);
                });
            }
            return staffs;
        });
    }
};
tslib_1.__decorate([
    common_1.RemoteCall()
], AgencyUser.prototype, "findCompanies", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.UUID })
], AgencyUser.prototype, "id", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], AgencyUser.prototype, "status", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], AgencyUser.prototype, "name", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], AgencyUser.prototype, "sex", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.STRING })
], AgencyUser.prototype, "avatar", null);
tslib_1.__decorate([
    common_1.Field({ type: model_1.Types.INTEGER })
], AgencyUser.prototype, "roleId", null);
tslib_1.__decorate([
    common_1.ResolveRef({ type: model_1.Types.UUID }, _types_1.Models.agency)
], AgencyUser.prototype, "agency", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], AgencyUser.prototype, "addCompanyCoin", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], AgencyUser.prototype, "addExpiryDate", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], AgencyUser.prototype, "addFlowPackage", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], AgencyUser.prototype, "configPreference", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], AgencyUser.prototype, "addTripFuelPackage", null);
tslib_1.__decorate([
    common_1.RemoteCall()
], AgencyUser.prototype, "findPackages", null);
tslib_1.__decorate([
    common_1.Create()
], AgencyUser, "create", null);
AgencyUser = AgencyUser_1 = tslib_1.__decorate([
    common_1.TableExtends(auth_1.Account, 'account'),
    common_1.Table(_types_1.Models.agencyUser, 'agency.')
], AgencyUser);
exports.AgencyUser = AgencyUser;
var AgencyUser_1;

//# sourceMappingURL=agency-user.js.map
