INSERT INTO company.suppliers(
            id, name, traffic_book_link, hotel_book_link, logo, company_id, created_at, updated_at)
    VALUES ('e3a4adc0-977f-11e6-87ee-1bf6381bbd7b', '携程商旅', 'http://ct.ctrip.com/m/Book/Flight', 'http://ct.ctrip.com/m/Book/Hotel', 'c3ebd500-385f-11e6-8e0a-d53d0d2d4e19', null, now(), now());