alter table company.suppliers add supplier_key varchar;
update company.suppliers set supplier_key = 'ct_ctrip_com_m' where id = 'e3a4adc0-977f-11e6-87ee-1bf6381bbd7b';