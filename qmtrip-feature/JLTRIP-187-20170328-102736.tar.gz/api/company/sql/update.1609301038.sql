alter table company.companies add coin_account_id uuid;
alter table company.companies add point2coin_rate numeric(10, 2);