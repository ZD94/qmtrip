"use strict";
const tslib_1 = require("tslib");
/**
 * Created by yumiao on 15-12-9.
 */
var sequelize = require("common/model").DB;
var DBM = sequelize.models;
const language_1 = require("common/language");
let C = require("config");
let API = require("common/api");
let Logger = require('common/logger');
let logger = new Logger('company');
let moment = require('moment');
let promoCodeType = require('libs/promoCodeType');
let scheduler = require('common/scheduler');
let schedule = require("node-schedule");
let _ = require("lodash");
const helper_1 = require("common/api/helper");
const _types_1 = require("_types");
const company_1 = require("_types/company");
const staff_1 = require("_types/staff");
const agency_1 = require("_types/agency");
const department_1 = require("_types/department");
const _decorator_1 = require("api/_decorator");
const utils_1 = require("common/utils");
const coin_1 = require("_types/coin");
const supplierCols = company_1.Supplier['$fieldnames'];
const DEFAULT_EXPIRE_MONTH = 1;
class CompanyModule {
    /**
     * 创建企业
     * @param {Object} params
     * @param {UUID} params.createUser 创建人
     * @param {String} params.name 企业名称
     * @param {String} params.domainName 域名,邮箱后缀
     * @returns {Promise<Company>}
     */
    static createCompany(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let results = yield _types_1.Models.company.find({ where: { $or: [{ email: params.email }, { mobile: params.mobile }] } });
            if (results && results.length > 0) {
                throw { code: -2, msg: '邮箱或手机号已注册企业' };
            }
            return company_1.Company.create(params).save();
        });
    }
    /**
     * @method createCompany
     *
     * 代理商创建企业
     *
     * @param params
     * @param params.mobile 手机号
     * @param params.name 企业名字
     * @param params.email 企业邮箱
     * @param params.userName 企业创建人姓名
     * @param params.pwd 登录密码
     * @param params.remark 备注
     * @param params.description 企业描述
     * @returns {Promise<Company>}
     */
    static registerCompany(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let session = Zone.current.get('session');
            let pwd = params.pwd;
            let agencyId = agency_1.Agency.__defaultAgencyId;
            let domain = ""; //企业域名
            if (params.email) {
                domain = params.email.match(/.*\@(.*)/)[1];
            }
            if (domain && domain != "" && params.email.indexOf(domain) == -1) {
                throw { code: -6, msg: "邮箱格式不符合要求" };
            }
            /*let companies = await Models.company.find({where: {$or: [{email: params.email}, {mobile: params.mobile}/!*, {domain_name: domain}*!/]}});
    
            if(companies && companies.length > 0) {
                throw {code: -7, msg: '邮箱或手机号已经注册'};
            }*/
            if (session && session.accountId) {
                let agencyUser = yield _types_1.Models.agencyUser.get(session.accountId);
                if (agencyUser) {
                    agencyId = agencyUser.agency.id;
                }
            }
            let staff = staff_1.Staff.create({ email: params.email, name: params.userName, mobile: params.mobile, roleId: staff_1.EStaffRole.OWNER, pwd: utils_1.md5(pwd), status: params.status, isValidateMobile: params.isValidateMobile });
            let company = company_1.Company.create(params);
            company.domainName = domain;
            company.expiryDate = moment().add(DEFAULT_EXPIRE_MONTH, 'months').toDate();
            company.isApproveOpen = true;
            company.points2coinRate = 50;
            let department = department_1.Department.create({ name: company.name, isDefault: true });
            let staffDepartment = department_1.StaffDepartment.create({ staffId: staff.id, departmentId: department.id });
            department.company = company;
            staff.company = company;
            company.createUser = staff.id;
            company['agencyId'] = agencyId;
            //新注册企业默认套餐行程数为60
            company.tripPlanNumLimit = 60;
            yield Promise.all([staff.save(), company.save(), department.save(), staffDepartment.save()]);
            let promoCode;
            if (params.promoCode) {
                promoCode = yield company.doPromoCode({ code: params.promoCode });
            }
            //为企业设置资金账户
            let ca = coin_1.CoinAccount.create();
            yield ca.save();
            company.coinAccount = ca;
            yield company.save();
            //为创建人设置资金账户
            let ca_staff = coin_1.CoinAccount.create();
            yield ca_staff.save();
            let account = yield _types_1.Models.account.get(staff.id);
            account.coinAccount = ca;
            yield account.save();
            return { company: company, description: promoCode ? promoCode.description : "" };
        });
    }
    /**
     * 更新企业信息
     * @param params
     * @returns {Promise<Company>}
     */
    static updateCompany(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let companyId = params.id;
            let company = yield _types_1.Models.company.get(companyId);
            for (let key in params) {
                company[key] = params[key];
            }
            return company.save();
        });
    }
    /**
     * 获取企业信息
     * @param {Object} params
     * @param {String} params.id 企业ID
     * @returns {Promise<Company>}
     */
    static getCompany(params) {
        return _types_1.Models.company.get(params.id);
    }
    /**
     * 获取企业列表
     * @param params
     * @returns {Promise<string[]>}
     */
    static listCompany(options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let agencyUser = yield agency_1.AgencyUser.getCurrent();
            options.order = options.order || [['created_at', 'desc']];
            if (!options.where) {
                options.where = {};
            }
            options.where.agencyId = agencyUser.agency.id;
            let companies = yield _types_1.Models.company.find(options);
            let ids = companies.map((c) => c.id);
            return { ids: ids, count: companies['total'] };
        });
    }
    static getCompanyNoAgency() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let agencies = yield _types_1.Models.company.find({ where: { agencyId: null } });
            return agencies;
        });
    }
    /**
     * 删除企业
     * @param params
     * @returns {*}
     */
    static deleteCompany(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let companyId = params.id;
            let company = yield _types_1.Models.company.get(companyId);
            yield company.destroy();
            return true;
        });
    }
    /**
     * 判断某代理商是否有权限访问某企业
     * @param params
     * @param params.userId 代理商id
     * @param params.companyId 企业id
     */
    static checkAgencyCompany(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var c = yield _types_1.Models.company.get(params.companyId);
            var user = yield _types_1.Models.agencyUser.get(params.userId);
            if (!c || c.status == -2) {
                throw language_1.default.ERR.COMPANY_NOT_EXIST();
            }
            if (c['agencyId'] != user.agency.id || (user.roleId != agency_1.EAgencyUserRole.OWNER && user.roleId != agency_1.EAgencyUserRole.ADMIN)) {
                throw language_1.default.ERR.PERMISSION_DENY();
            }
            return true;
        });
    }
    /**
     * 保存资金变动记录
     * @param params
     * @returns {Promise<MoneyChange>}
     */
    static saveMoneyChange(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            return company_1.MoneyChange.create(params).save();
        });
    }
    /**
     *
     * @param params
     * @returns {Promise<MoneyChange>}
     */
    static getMoneyChange(params) {
        return _types_1.Models.moneyChange.get(params.id);
    }
    /**
     *
     * @param params
     * @returns {Promise<string[]>}
     */
    static listMoneyChange(options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let staff = yield staff_1.Staff.getCurrent();
            if (!options.where) {
                options.where = {};
            }
            options.where.companyId = staff.company.id;
            let changes = yield _types_1.Models.moneyChange.find(options);
            let ids = changes.map((c) => c.id);
            return { ids: ids, count: changes['total'] };
        });
    }
    /**
     * @method fundsCharge
     * 企业资金账户充值
     * @param params
     * @param params.channel 充值渠道
     * @param params.money 充值金额
     * @param params.companyId 充值企业id
     * @param params.remark 备注 可选
     * @returns {Promise}
     */
    static fundsCharge(params) {
        let self = this;
        params['userId'] = self.accountId;
        params['type'] = 1;
        params.remark = params.remark || '充值';
        return API.company.changeMoney(params);
    }
    /**
     * @method frozenMoney
     * 冻结账户资金
     * @param params
     * @param params.channel 充值渠道
     * @param params.money 充值金额
     * @param params.companyId 充值企业id
     * @returns {Promise}
     */
    static frozenMoney(params) {
        let self = this;
        params.channel = params.channel || '冻结';
        params['userId'] = self.accountId;
        params['type'] = -2;
        params['remark'] = '冻结账户资金';
        return API.company.changeMoney(params);
    }
    /**
     * @method consumeMoney
     * 消费企业账户余额
     * @param params
     * @returns {Promise}
     */
    static consumeMoney(params) {
        let self = this;
        params.userId = self.accountId;
        params.type = -1;
        params.channel = params.channel || '消费';
        params.remark = params.remark || '账户余额消费';
        return API.company.changeMoney(params);
    }
    /**
     * 域名是否已被占用
     *
     * @param {Object} params
     * @param {String} params.domain 域名
     * @return {Promise} true|false
     */
    static domainIsExist(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (C.is_allow_domain_repeat) {
                return false;
            }
            let domain = params.domain;
            let company = yield _types_1.Models.company.find({ where: { domainName: domain } });
            return company && company.length > 0;
        });
    }
    /**
     * 是否在域名黑名单中
     *
     * @param {Object} params 参数
     * @param {String} params.domain 域名
     * @return {Promise}
     */
    static isBlackDomain(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            //var domain = params.domain.toLowerCase();
            // let black = await DBM.BlackDomain.findAll({where: params});
            // if(black && black.length > 0) {
            //     return true;
            // }
            return false;
        });
    }
    /**
     * 测试用例删除企业，不在client调用
     * @param params
     * @returns {*}
     */
    static deleteCompanyByTest(params) {
        var mobile = params.mobile;
        var email = params.email;
        return DBM.Company.findAll({ where: { $or: [{ mobile: mobile }, { email: email }] } })
            .then(function (companys) {
            return companys.map(function (c) {
                return true;
            });
        })
            .then(function () {
            return DBM.Company.destroy({ where: { $or: [{ mobile: mobile }, { email: email }] } });
        })
            .then(function () {
            return true;
        });
    }
    /*************************************供应商begin***************************************/
    /**
     * 创建供应商
     * @param data
     * @returns {*}
     */
    static createSupplier(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var supplier = company_1.Supplier.create(params);
            return supplier.save();
        });
    }
    /**
     * 删除供应商
     * @param params
     * @returns {*}
     */
    static deleteSupplier(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var id = params.id;
            var st_delete = yield _types_1.Models.supplier.get(id);
            yield st_delete.destroy();
            return true;
        });
    }
    /**
     * 更新供应商
     * @param id
     * @param data
     * @returns {*}
     */
    static updateSupplier(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var id = params.id;
            var sp = yield _types_1.Models.supplier.get(id);
            for (var key in params) {
                sp[key] = params[key];
            }
            return sp.save();
        });
    }
    /**
     * 根据id查询供应商
     * @param {String} params.id
     * @returns {*}
     */
    static getSupplier(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let id = params.id;
            var ah = yield _types_1.Models.supplier.get(id);
            return ah;
        });
    }
    ;
    /**
     * 根据属性查找属于企业的供应商
     * @param params
     * @returns {*}
     */
    static getSuppliers(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            params.order = params.order || [['created_at', 'desc']];
            let paginate = yield _types_1.Models.supplier.find(params);
            let ids = paginate.map(function (s) {
                return s.id;
            });
            return { ids: ids, count: paginate['total'] };
        });
    }
    /**
     * 查找系统公共供应商
     * @param params
     * @returns {*}
     */
    static getPublicSuppliers(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            params.order = params.order || [['created_at', 'desc']];
            params.where.companyId = null; //查询companyId为空的公共供应商
            let paginate = yield _types_1.Models.supplier.find(params);
            let ids = paginate.map(function (s) {
                return s.id;
            });
            return { ids: ids, count: paginate['total'] };
        });
    }
    /*************************************供应商end***************************************/
    /*************************************企业行程点数变更日志begin***************************************/
    static createTripPlanNumChange(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var tpc = company_1.TripPlanNumChange.create(params);
            return tpc.save();
        });
    }
    static getTripPlanNumChange(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            return _types_1.Models.tripPlanNumChange.get(params.id);
        });
    }
    /**
     * 企业行程点数变更记录
     * @param params
     * @returns {*}
     */
    static getTripPlanNumChanges(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            params.order = params.order || [['createdAt', 'desc']];
            let paginate = yield _types_1.Models.tripPlanNumChange.find(params);
            let ids = paginate.map(function (t) {
                return t.id;
            });
            return { ids: ids, count: paginate['total'] };
        });
    }
    /*************************************企业行程点数变更日志end***************************************/
    static _scheduleTask() {
        let taskId = "resetTripPlanPassNum";
        scheduler('0 5 0 1 * ?', taskId, function () {
            //每月1号付费企业消耗行程数，冻结数归零
            (() => tslib_1.__awaiter(this, void 0, void 0, function* () {
                let companies = [];
                let pager = yield _types_1.Models.company.find({ where: { $or: [{ tripPlanPassNum: { $gt: 0 } }, { tripPlanFrozenNum: { $gt: 0 } }], expiryDate: { $gt: moment().format('YYYY-MM-DD HH:mm:ss') }, type: company_1.ECompanyType.PAYED } });
                pager.forEach((company) => {
                    companies.push(company);
                });
                while (pager && pager.hasNextPage()) {
                    pager = yield pager.nextPage();
                    pager.forEach((company) => {
                        companies.push(company);
                    });
                }
                yield Promise.all(companies.map((co) => tslib_1.__awaiter(this, void 0, void 0, function* () {
                    let num = co.tripPlanNumLimit - co.tripPlanPassNum;
                    co.tripPlanPassNum = 0;
                    co.tripPlanFrozenNum = 0;
                    yield co.save();
                    if (num > 0) {
                        let log1 = company_1.TripPlanNumChange.create({ companyId: co.id, type: company_1.NUM_CHANGE_TYPE.SYSTEM_REDUCE, number: 0 - num, remark: "上月套餐余额及冻结余额过期", content: "套餐包余额过期" });
                        yield log1.save();
                    }
                    let log2 = company_1.TripPlanNumChange.create({ companyId: co.id, type: company_1.NUM_CHANGE_TYPE.SYSTEM_ADD, number: co.tripPlanNumLimit, remark: "本月套餐新增行程", content: "本月套餐新增行程" });
                    yield log2.save();
                })));
            }))()
                .catch((err) => {
                logger.error(`执行任务${taskId}错误:${err.stack}`);
            });
        });
        let taskId2 = 'notifyExpireCompany';
        scheduler('0 0 1 * * *', taskId2, function () {
            //失效日期前1,7,15天时发送 App, 短信, 邮件通知
            (function () {
                return tslib_1.__awaiter(this, void 0, void 0, function* () {
                    let companies = [];
                    let now = new Date();
                    const EXPIRE_BEFORE_DAYS = 15;
                    const PAYED_COMPANY_EXPIRE_NOTIFY = [1, 7, 15];
                    const TRYING_COMPANY_EXPIRE_NOTIFY = [7];
                    //获取所有待失效企业
                    let pager = yield _types_1.Models.company.find({
                        where: {
                            expiryDate: {
                                $lte: moment().add(EXPIRE_BEFORE_DAYS, 'days'),
                                $gte: now,
                            },
                        }
                    });
                    pager.forEach((company) => {
                        companies.push(company);
                    });
                    while (pager && pager.hasNextPage()) {
                        pager = yield pager.nextPage();
                        pager.forEach((company) => {
                            companies.push(company);
                        });
                    }
                    for (let company of companies) {
                        if (!company.expiryDate) {
                            continue;
                        }
                        let diffDays = moment(company.expiryDate).diff([now.getFullYear(), now.getMonth(), now.getDate()], 'days');
                        let key = null;
                        if (company.type == company_1.ECompanyType.PAYED
                            && PAYED_COMPANY_EXPIRE_NOTIFY.indexOf(diffDays) >= 0) {
                            key = 'qm_notify_will_expire_company';
                        }
                        if (company.type != company_1.ECompanyType.PAYED
                            && TRYING_COMPANY_EXPIRE_NOTIFY.indexOf(diffDays) >= 0) {
                            key = 'qm_notify_trying_will_expire_company';
                        }
                        if (key) {
                            //查询公司管理员和创建人
                            let managers = yield company.getManagers({ withOwner: true });
                            let ps = managers.map((manager) => {
                                //给各个企业发送通知
                                return API.notify.submitNotify({
                                    accountId: manager.id,
                                    key: key,
                                    values: {
                                        expiryDate: moment(company.expiryDate).format('YYYY-MM-DD'),
                                        days: diffDays,
                                    }
                                });
                            });
                            yield Promise.all(ps);
                        }
                    }
                });
            })()
                .catch((err) => {
                logger.error(`run stark ${taskId2} error:`, err.stack);
            });
        });
        let taskId3 = "companyExpire";
        scheduler('0 0 * * * *', taskId3, function () {
            //每小时检查一次企业是否过期 将过期企业套餐行程数置为0
            (() => tslib_1.__awaiter(this, void 0, void 0, function* () {
                let companies = [];
                let pager = yield _types_1.Models.company.find({ where: { expiryDate: { $lt: moment().format('YYYY-MM-DD HH:mm:ss') }, tripPlanNumLimit: { $gt: 0 } } });
                pager.forEach((company) => {
                    companies.push(company);
                });
                while (pager && pager.hasNextPage()) {
                    pager = yield pager.nextPage();
                    pager.forEach((company) => {
                        companies.push(company);
                    });
                }
                yield Promise.all(companies.map((co) => tslib_1.__awaiter(this, void 0, void 0, function* () {
                    let num = co.tripPlanNumLimit - co.tripPlanPassNum - co.tripPlanFrozenNum;
                    co.tripPlanNumLimit = 0;
                    yield co.save();
                    if (num > 0) {
                        let log = company_1.TripPlanNumChange.create({ companyId: co.id, type: company_1.NUM_CHANGE_TYPE.SYSTEM_REDUCE, number: 0 - num, remark: "企业服务到期套餐内行程数置为0", content: "套餐包余额过期" });
                        yield log.save();
                    }
                })));
            }))()
                .catch((err) => {
                logger.error(`执行任务${taskId3}错误:${err.stack}`);
            });
        });
        let taskId4 = "extraExpiryDate";
        scheduler('0 0 * * * *', taskId4, function () {
            //每小时检查一次增量包是否过期
            (() => tslib_1.__awaiter(this, void 0, void 0, function* () {
                let companies = [];
                let pager = yield _types_1.Models.company.find({ where: { extraExpiryDate: { $lt: moment().format('YYYY-MM-DD HH:mm:ss') }, extraTripPlanNum: { $gt: 0 } } });
                pager.forEach((company) => {
                    companies.push(company);
                });
                while (pager && pager.hasNextPage()) {
                    pager = yield pager.nextPage();
                    pager.forEach((company) => {
                        companies.push(company);
                    });
                }
                yield Promise.all(companies.map((co) => tslib_1.__awaiter(this, void 0, void 0, function* () {
                    if (co.extraTripPlanNum) {
                        let num = co.extraTripPlanNum;
                        co.extraTripPlanNum = 0;
                        co.extraTripPlanFrozenNum = 0;
                        yield co.save();
                        if (num > 0) {
                            let log = company_1.TripPlanNumChange.create({ companyId: co.id, type: company_1.NUM_CHANGE_TYPE.SYSTEM_REDUCE, number: 0 - num, remark: "增量包余额过期", content: "增量包余额过期" });
                            yield log.save();
                        }
                    }
                })));
            }))()
                .catch((err) => {
                logger.error(`执行任务${taskId4}错误:${err.stack}`);
            });
        });
        let taskId5 = 'qm:task:perDayMail';
        scheduler('0 10 8 * * *', taskId5, function () {
            if (!C.perDayRegisterEmail) {
                return false;
            }
            //每天八点10分发送每日企业注册邮件
            (() => tslib_1.__awaiter(this, void 0, void 0, function* () {
                let pager;
                let companies = [];
                do {
                    pager = yield _types_1.Models.company.find({
                        where: {
                            createdAt: {
                                "$lte": new Date(),
                                "$gte": moment().add(-1, 'days').format('YYYY-MM-DD 08:00')
                            }
                        }
                    });
                    let ps = pager.map((company) => tslib_1.__awaiter(this, void 0, void 0, function* () {
                        let staff = yield _types_1.Models.staff.get(company.createUser);
                        company['createUserObj'] = staff;
                        return company;
                    }));
                    let _companies = yield Promise.all(ps);
                    _companies.forEach((company) => {
                        companies.push({
                            name: company.name,
                            createUser: {
                                name: company['createUserObj']['name'],
                                mobile: company['createUserObj']['mobile']
                            },
                            createdAt: company.createdAt
                        });
                    });
                } while (pager && pager.hasNextPage());
                yield API.notify.submitNotify({
                    key: "qm_notify_perday_mail",
                    values: {
                        companies: companies,
                    },
                    email: C.perDayRegisterEmail
                });
                logger.info(`成功执行任务${taskId5}`);
            }))()
                .catch((err) => {
                logger.error(`执行任务${taskId5}错误:${err.stack}`);
            });
        });
    }
}
tslib_1.__decorate([
    helper_1.requireParams(['createUser', 'name', 'domainName', 'mobile', 'email', 'agencyId'], ['id', 'description', 'telephone', 'remark'])
], CompanyModule, "createCompany", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['mobile', 'name', 'pwd', 'userName'], ['email', 'status', 'remark', 'description', 'isValidateMobile', 'promoCode'])
], CompanyModule, "registerCompany", null);
tslib_1.__decorate([
    helper_1.clientExport,
    _decorator_1.requirePermit('company.edit', 2),
    helper_1.requireParams(['id'], ['agencyId', 'name', 'description', 'mobile', 'remark', 'status']),
    _decorator_1.modelNotNull('company')
], CompanyModule, "updateCompany", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id']),
    _decorator_1.modelNotNull('company'),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isMyCompany("0.id") },
        { if: _decorator_1.condition.isCompanyAgency("0.id") }
    ])
], CompanyModule, "getCompany", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams([], ['where.status'])
], CompanyModule, "listCompany", null);
tslib_1.__decorate([
    helper_1.clientExport,
    _decorator_1.requirePermit('company.delete', 2),
    helper_1.requireParams(['id']),
    _decorator_1.modelNotNull('company')
], CompanyModule, "deleteCompany", null);
tslib_1.__decorate([
    helper_1.requireParams(['companyId', 'userId'])
], CompanyModule, "checkAgencyCompany", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id']),
    _decorator_1.modelNotNull('moneyChange')
], CompanyModule, "getMoneyChange", null);
tslib_1.__decorate([
    helper_1.clientExport
], CompanyModule, "listMoneyChange", null);
tslib_1.__decorate([
    helper_1.requireParams(['channel', 'money', 'companyId'], ['remark'])
], CompanyModule, "fundsCharge", null);
tslib_1.__decorate([
    helper_1.requireParams(['money', 'companyId'], ['channel'])
], CompanyModule, "frozenMoney", null);
tslib_1.__decorate([
    helper_1.requireParams(['domain'])
], CompanyModule, "domainIsExist", null);
tslib_1.__decorate([
    helper_1.requireParams(['domain'])
], CompanyModule, "isBlackDomain", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["name", "companyId"], supplierCols),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isCompanyAdminOrOwner("0.companyId") }
    ])
], CompanyModule, "createSupplier", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"]),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isSupplierAdminOrOwner("0.id") }
    ])
], CompanyModule, "deleteSupplier", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"], supplierCols),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isSupplierAdminOrOwner("0.id") }
    ])
], CompanyModule, "updateSupplier", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"])
], CompanyModule, "getSupplier", null);
tslib_1.__decorate([
    helper_1.clientExport
], CompanyModule, "getSuppliers", null);
tslib_1.__decorate([
    helper_1.clientExport
], CompanyModule, "getPublicSuppliers", null);
tslib_1.__decorate([
    helper_1.clientExport
], CompanyModule, "createTripPlanNumChange", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"])
], CompanyModule, "getTripPlanNumChange", null);
tslib_1.__decorate([
    helper_1.clientExport
], CompanyModule, "getTripPlanNumChanges", null);
CompanyModule._scheduleTask();
module.exports = CompanyModule;

//# sourceMappingURL=index.js.map
