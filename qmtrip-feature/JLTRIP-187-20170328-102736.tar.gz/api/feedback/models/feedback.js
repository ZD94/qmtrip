"use strict";
/**
 * Created by wyl on 16-1-21.
 */
var uuid = require("node-uuid");
var now = require("common/utils").now;
module.exports = function (Db, DataType) {
    return Db.define("Feedback", {
        id: { type: DataType.UUID, defaultValue: uuid.v1, primaryKey: true },
        content: { type: DataType.TEXT },
        userName: { type: DataType.STRING(50), field: "user_name" },
        companyName: { type: DataType.STRING(50), field: "company_name" },
        userId: { type: DataType.UUID, field: "user_id" },
        isAnonymity: { type: DataType.BOOLEAN, field: "is_anonymity", defaultValue: false },
        createdAt: { type: DataType.DATE, field: "created_at", defaultValue: now } //创建时间
    }, {
        tableName: "feedback",
        timestamps: false,
        schema: "feedback"
    });
};

//# sourceMappingURL=feedback.js.map
