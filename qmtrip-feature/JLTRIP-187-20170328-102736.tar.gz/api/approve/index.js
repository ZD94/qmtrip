/**
 * Created by wlh on 2016/11/17.
 */
'use strict';
const tslib_1 = require("tslib");
const helper_1 = require("../../common/api/helper");
const staff_1 = require("_types/staff/staff");
const index_1 = require("_types/index");
const oa_1 = require("libs/oa");
const types_1 = require("_types/approve/types");
const tripPlan_1 = require("_types/tripPlan/tripPlan");
const _ = require("lodash");
let Config = require('config');
var API = require("common/api");
function oaStr2Enum(str) {
    let obj = {
        'qm': types_1.EApproveChannel.QM,
        'auto': types_1.EApproveChannel.AUTO,
        'ddtalk': types_1.EApproveChannel.DING_TALK
    };
    return obj[str];
}
function oaEnum2Str(e) {
    let obj = {};
    obj[types_1.EApproveChannel.QM] = 'qm';
    obj[types_1.EApproveChannel.AUTO] = 'auto';
    obj[types_1.EApproveChannel.DING_TALK] = 'ddtalk';
    return obj[e];
}
class ApproveModule {
    static submitApprove(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let { budgetId, project, approveUser } = params;
            let submitter = yield staff_1.Staff.getCurrent();
            let company = submitter.company;
            //获取预算详情
            let budgetInfo = yield API.travelBudget.getBudgetInfo({ id: budgetId, accountId: submitter.id });
            let number = 0;
            let content = "";
            let query = budgetInfo.query;
            let destinationPlacesInfo = query.destinationPlacesInfo;
            if (query && query.originPlace) {
                let originCity = yield API.place.getCityInfo({ cityCode: query.originPlace });
                content = content + originCity.name + "-";
            }
            if (destinationPlacesInfo && _.isArray(destinationPlacesInfo) && destinationPlacesInfo.length > 0) {
                for (let i = 0; i < destinationPlacesInfo.length; i++) {
                    let segment = destinationPlacesInfo[i];
                    let destinationCity = yield API.place.getCityInfo({ cityCode: segment.destinationPlace });
                    content = content + destinationCity.name;
                }
            }
            if (budgetInfo.budgets && budgetInfo.budgets.length > 0) {
                budgetInfo.budgets.forEach(function (item) {
                    if (item.tripType != 3) {
                        number = number + 1;
                    }
                });
            }
            yield company.beforeGoTrip({ number: number });
            //冻结行程数
            let oldNum = company.tripPlanNumBalance;
            let result = yield company.frozenTripPlanNum({ accountId: submitter.id, number: number,
                remark: "提交出差申请消耗行程点数", content: content });
            let com = result.company;
            let frozenNum = result.frozenNum;
            budgetInfo.query.frozenNum = frozenNum;
            let approve = yield ApproveModule._submitApprove({
                submitter: submitter.id,
                data: budgetInfo,
                title: project,
                channel: submitter.company.oa,
                type: types_1.EApproveType.TRAVEL_BUDGET,
                approveUser: approveUser,
            });
            //行程数第一次小于10或等于0时给管理员和创建人发通知
            let newNum = com.tripPlanNumBalance;
            if (oldNum > 10 && newNum <= 10 || newNum == 0) {
                let managers = yield company.getManagers({ withOwner: true });
                let ps = managers.map((manager) => {
                    return API.notify.submitNotify({
                        accountId: manager.id,
                        key: "qm_notify_trip_plan_num_short",
                        values: {
                            number: newNum
                        }
                    });
                });
                yield Promise.all(ps);
            }
            return approve;
        });
    }
    static submitSpecialApprove(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let { query, budget, project, specialApproveRemark, approveUser } = params;
            let submitter = yield staff_1.Staff.getCurrent();
            let company = submitter.company;
            //特殊审批不记录行程数
            // await company.beforeGoTrip();
            // await company.frozenTripPlanNum({number: 1});
            let budgetInfo = {
                query: query,
                budgets: [
                    {
                        startAt: query.leaveDate,
                        backAt: query.goBackDate,
                        price: budget,
                        tripType: tripPlan_1.ETripType.SPECIAL_APPROVE,
                        reason: specialApproveRemark,
                        originPlace: null,
                        destination: null
                    }
                ]
            };
            if (typeof query.destinationPlacesInfo == 'string')
                query.destinationPlacesInfo = JSON.parse(query.destinationPlacesInfo);
            let destinationPlacesInfo = query.destinationPlacesInfo;
            //出发地
            if (query.originPlace) {
                let originPlace = (yield API.place.getCityInfo({ cityCode: query.originPlace.id || query.originPlace })) || { name: null };
                budgetInfo.budgets[0].originPlace = originPlace;
            }
            if (destinationPlacesInfo && _.isArray(destinationPlacesInfo) && destinationPlacesInfo.length > 0) {
                for (let i = 0; i < destinationPlacesInfo.length; i++) {
                    let segment = destinationPlacesInfo[i];
                    //处理startAt,backAt
                    if (i == 0) {
                        budgetInfo.budgets[0].startAt = segment.leaveDate;
                    }
                    if (i == (destinationPlacesInfo.length - 1)) {
                        budgetInfo.budgets[0].backAt = segment.goBackDate;
                    }
                    //处理目的地
                    if (i == (destinationPlacesInfo.length - 1) && segment.destinationPlace) {
                        let place = segment.destinationPlace;
                        if (typeof place != 'string') {
                            place = place['id'];
                        }
                        let arrivalInfo = (yield API.place.getCityInfo({ cityCode: place })) || { name: null };
                        budgetInfo.budgets[0].destination = arrivalInfo;
                    }
                }
            }
            return ApproveModule._submitApprove({
                submitter: submitter.id,
                data: budgetInfo,
                title: project,
                channel: submitter.company.oa,
                type: types_1.EApproveType.TRAVEL_BUDGET,
                isSpecialApprove: true,
                specialApproveRemark: specialApproveRemark,
                approveUser: approveUser,
            });
        });
    }
    static _submitApprove(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let { submitter, data, approveUser, title, channel, type, isSpecialApprove, specialApproveRemark } = params;
            let staff = yield index_1.Models.staff.get(submitter);
            let approve = index_1.Models.approve.create({
                submitter: submitter,
                data: data,
                channel: channel,
                title: title,
                type: type,
                approveUser: approveUser ? approveUser.id : null,
                isSpecialApprove: isSpecialApprove,
                specialApproveRemark: specialApproveRemark,
                companyId: staff.company.id,
            });
            approve = yield approve.save();
            //对接第三方OA
            oa_1.emitter.emit(oa_1.EVENT.NEW_TRIP_APPROVE, {
                approveNo: approve.id,
                approveUser: approveUser ? approveUser.id : null,
                submitter: submitter,
                status: types_1.EApproveStatus.WAIT_APPROVE,
                oa: oaEnum2Str(channel) || 'qm'
            });
            return approve;
        });
    }
    static reportHimOA(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let { oaName, oaUrl } = params;
            let staff = yield staff_1.Staff.getCurrent();
            try {
                let ret = yield API.notify.submitNotify({
                    email: Config.reportHimOAReceive,
                    key: 'qm_report_him_oa',
                    values: {
                        oaName: oaName,
                        oaUrl: oaUrl,
                        companyName: staff.company.name,
                        name: staff.name,
                        mobile: staff.mobile,
                    },
                });
            }
            catch (err) {
                throw err;
            }
        });
    }
}
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["budgetId"], ["approveUser", "project"])
], ApproveModule, "submitApprove", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['query', 'budget'], ['project', 'specialApproveRemark', 'approveUser'])
], ApproveModule, "submitSpecialApprove", null);
tslib_1.__decorate([
    helper_1.clientExport
], ApproveModule, "reportHimOA", null);
//监听审批单变化
oa_1.emitter.on(oa_1.EVENT.TRIP_APPROVE_UPDATE, function (result) {
    let p = (function () {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let { approveNo, submitter, outerId, status, approveUser, data, oa } = result;
            let approve = yield index_1.Models.approve.get(approveNo);
            if (approve.status == status) {
                return;
            }
            let company = yield index_1.Models.company.get(approve['companyId']);
            //OA流程已经切换,旧的处理渠道不再支持
            if (company.oa != oaStr2Enum(oa)) {
                return;
            }
            approve.status = status;
            approve.approveUser = approveUser;
            approve.approveDateTime = new Date();
            approve.outerId = outerId;
            if (data) {
                approve.data = data;
            }
            approve = yield approve.save();
            //预算审批完成
            if (approve.type == types_1.EApproveType.TRAVEL_BUDGET && approve.status == types_1.EApproveStatus.SUCCESS) {
                yield API.tripPlan.saveTripPlanByApprove({ tripApproveId: approve.id });
            }
        });
    })();
    //捕获事件中错误
    p.catch((err) => {
        console.error(err.stack);
    });
});
module.exports = ApproveModule;

//# sourceMappingURL=index.js.map
