/**
 * Created by wyl on 15-12-12.
 */
'use strict';
const tslib_1 = require("tslib");
var sequelize = require("common/model").DB;
var DBM = sequelize.models;
var _ = require('lodash');
const paginate_1 = require("common/paginate");
const language_1 = require("common/language");
const helper_1 = require("common/api/helper");
const _decorator_1 = require("../_decorator");
const staff_1 = require("_types/staff");
const travelPolicy_1 = require("_types/travelPolicy");
const _types_1 = require("_types");
const travalPolicyCols = travelPolicy_1.TravelPolicy['$fieldnames'];
const subsidyTemplateCols = travelPolicy_1.SubsidyTemplate['$fieldnames'];
class TravelPolicyModule {
    /**
     * 创建差旅标准
     * @param data
     * @returns {*}
     */
    static createTravelPolicy(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let result = yield _types_1.Models.travelPolicy.find({ where: { name: params.name, companyId: params.companyId } });
            if (result && result.length > 0) {
                throw language_1.default.ERR.TRAVEL_POLICY_NAME_REPEAT();
            }
            params.planeLevels = tryConvertToArray(params.planeLevels);
            params.trainLevels = tryConvertToArray(params.trainLevels);
            params.hotelLevels = tryConvertToArray(params.hotelLevels);
            params.abroadHotelLevels = tryConvertToArray(params.abroadHotelLevels);
            params.abroadTrainLevels = tryConvertToArray(params.abroadTrainLevels);
            params.abroadPlaneLevels = tryConvertToArray(params.abroadPlaneLevels);
            let travelp = travelPolicy_1.TravelPolicy.create(params);
            if (travelp.isDefault) {
                let defaults = yield _types_1.Models.travelPolicy.find({ where: { id: { $ne: travelp.id }, is_default: true } });
                if (defaults && defaults.length > 0) {
                    yield Promise.all(defaults.map(function (item) {
                        return tslib_1.__awaiter(this, void 0, void 0, function* () {
                            item.isDefault = false;
                            yield item.save();
                        });
                    }));
                }
            }
            travelp.company = yield _types_1.Models.company.get(params.companyId);
            return travelp.save();
        });
    }
    /**
     * 删除差旅标准
     * @param params
     * @returns {*}
     */
    static deleteTravelPolicy(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var staff = yield staff_1.Staff.getCurrent();
            var id = params.id;
            var tp_delete = yield _types_1.Models.travelPolicy.get(id);
            if (tp_delete.isDefault) {
                throw { code: -2, msg: '不允许删除默认差旅标准' };
            }
            let staffs = yield _types_1.Models.staff.find({ where: { travelPolicyId: id, staffStatus: staff_1.EStaffStatus.ON_JOB } });
            if (staffs && staffs.length > 0) {
                throw { code: -1, msg: '目前有' + staffs.length + '位员工在使用此标准请先移除' };
            }
            if (staff && tp_delete["companyId"] != staff["companyId"]) {
                throw language_1.default.ERR.PERMISSION_DENY();
            }
            var templates = yield tp_delete.getSubsidyTemplates();
            if (templates && templates.length > 0) {
                yield Promise.all(templates.map(function (item) {
                    return tslib_1.__awaiter(this, void 0, void 0, function* () {
                        yield item.destroy();
                        return true;
                    });
                }));
            }
            yield tp_delete.destroy();
            return true;
        });
    }
    static deleteTravelPolicyByTest(params) {
        return DBM.TravelPolicy.destroy({ where: { $or: [{ name: params.name }, { companyId: params.companyId }] } })
            .then(function () {
            return true;
        });
    }
    /**
     * 更新差旅标准
     * @param id
     * @param data
     * @returns {*}
     */
    static updateTravelPolicy(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var id = params.id;
            var tp = yield _types_1.Models.travelPolicy.get(id);
            params.planeLevels = tryConvertToArray(params.planeLevels);
            params.trainLevels = tryConvertToArray(params.trainLevels);
            params.hotelLevels = tryConvertToArray(params.hotelLevels);
            params.abroadHotelLevels = tryConvertToArray(params.abroadHotelLevels);
            params.abroadTrainLevels = tryConvertToArray(params.abroadTrainLevels);
            params.abroadPlaneLevels = tryConvertToArray(params.abroadPlaneLevels);
            for (var key in params) {
                tp[key] = params[key];
            }
            return tp.save();
        });
    }
    static getDefaultTravelPolicy() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let dep = yield _types_1.Models.travelPolicy.get('dc6f4e50-a9f2-11e5-a9a3-9ff0188d1c1a');
            return dep;
        });
    }
    /**
     * 根据id查询差旅标准
     * @param {String} params.id
     * @param {Boolean} params.isReturnDefault 如果不存在返回默认 default true,
     * @returns {*}
     */
    static getTravelPolicy(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let id = params.id;
            //var staff = await Staff.getCurrent();
            var tp = yield _types_1.Models.travelPolicy.get(id);
            return tp;
        });
    }
    ;
    /**
     * 得到全部差旅标准
     * @param params
     * @returns {*}
     */
    static getAllTravelPolicy(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var staff = yield staff_1.Staff.getCurrent();
            //let companyId = params.companyId;
            let options = {
                where: _.pick(params, ['name', 'planeLevel', 'planeDiscount', 'trainLevel', 'hotelLevel', 'hotelPrice', 'companyId', 'isChangeLevel', 'createdAt'])
            };
            if (params.columns) {
                options.attributes = params.columns;
            }
            if (params.order) {
                options.order = params.order || "createdAt desc";
            }
            if (staff) {
                options.where.companyId = staff["companyId"];
            }
            return _types_1.Models.travelPolicy.find(options);
        });
    }
    /**
     * 根据属性查找差旅标准
     * @param params
     * @returns {*}
     */
    static getTravelPolicies(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var staff = yield staff_1.Staff.getCurrent();
            params.order = params.order || [['createdAt', 'desc']];
            if (staff) {
                params.where.companyId = staff["companyId"]; //只允许查询该企业下的差旅标准
            }
            let paginate = yield _types_1.Models.travelPolicy.find(params);
            let ids = paginate.map(function (t) {
                return t.id;
            });
            return { ids: ids, count: paginate['total'] };
        });
    }
    /**
     * 分页查询差旅标准集合
     * @param params 查询条件 params.company_id 企业id
     * @param options options.perPage 每页条数 options.page当前页
     */
    static listAndPaginateTravelPolicy(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var options = {};
            if (params.options) {
                options = params.options;
                delete params.options;
            }
            var page, perPage, limit, offset;
            if (options.page && /^\d+$/.test(options.page)) {
                page = options.page;
            }
            else {
                page = 1;
            }
            if (options.perPage && /^\d+$/.test(options.perPage)) {
                perPage = options.perPage;
            }
            else {
                perPage = 6;
            }
            limit = perPage;
            offset = (page - 1) * perPage;
            if (!options.order) {
                options.order = [["created_at", "desc"]];
            }
            options.limit = limit;
            options.offset = offset;
            options.where = params;
            return DBM.TravelPolicy.findAndCountAll(options)
                .then(function (result) {
                return new paginate_1.Paginate(page, perPage, result.count, result.rows);
            });
        });
    }
    /*************************************补助模板begin***************************************/
    /**
     * 创建补助模板
     * @param data
     * @returns {*}
     */
    static createSubsidyTemplate(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            /*let result = await Models.subsidyTemplate.find({where: {travelPolicyId: params.travelPolicyId}});
            if(result && result.length>0){
                throw {msg: "该城市补助模板已设置"};
            }*/
            var subsidyTemplate = travelPolicy_1.SubsidyTemplate.create(params);
            return subsidyTemplate.save();
        });
    }
    /**
     * 删除补助模板
     * @param params
     * @returns {*}
     */
    static deleteSubsidyTemplate(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var id = params.id;
            var st_delete = yield _types_1.Models.subsidyTemplate.get(id);
            yield st_delete.destroy();
            return true;
        });
    }
    /**
     * 更新补助模板
     * @param id
     * @param data
     * @returns {*}
     */
    static updateSubsidyTemplate(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var id = params.id;
            //var staff = await Staff.getCurrent();
            var ah = yield _types_1.Models.subsidyTemplate.get(id);
            for (var key in params) {
                ah[key] = params[key];
            }
            return ah.save();
        });
    }
    /**
     * 根据id查询补助模板
     * @param {String} params.id
     * @param {Boolean} params.isReturnDefault 如果不存在返回默认 default true,
     * @returns {*}
     */
    static getSubsidyTemplate(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let id = params.id;
            var ah = yield _types_1.Models.subsidyTemplate.get(id);
            return ah;
        });
    }
    ;
    /**
     * 根据属性查找补助模板
     * @param params
     * @returns {*}
     */
    static getSubsidyTemplates(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            params.order = params.order || [['subsidyMoney', 'desc']];
            let paginate = yield _types_1.Models.subsidyTemplate.find(params);
            let ids = paginate.map(function (t) {
                return t.id;
            });
            return { ids: ids, count: paginate['total'] };
        });
    }
}
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["name", "planeLevels", "trainLevels", "hotelLevels", "companyId"], travalPolicyCols),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isCompanyAdminOrOwner("0.companyId") },
        { if: _decorator_1.condition.isCompanyAgency("0.companyId") }
    ])
], TravelPolicyModule, "createTravelPolicy", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"], ["companyId"]),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isTravelPolicyAdminOrOwner("0.id") },
        { if: _decorator_1.condition.isTravelPolicyAgency("0.id") }
    ])
], TravelPolicyModule, "deleteTravelPolicy", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"], travalPolicyCols),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isTravelPolicyAdminOrOwner("0.id") },
        { if: _decorator_1.condition.isTravelPolicyAgency("0.id") }
    ])
], TravelPolicyModule, "updateTravelPolicy", null);
tslib_1.__decorate([
    helper_1.clientExport
], TravelPolicyModule, "getDefaultTravelPolicy", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"], ["companyId"]),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isTravelPolicyCompany("0.id") },
        { if: _decorator_1.condition.isTravelPolicyAgency("0.id") }
    ])
], TravelPolicyModule, "getTravelPolicy", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["companyId"], ['columns', 'name', 'planeLevel', 'planeDiscount', 'trainLevel', 'hotelLevel', 'hotelPrice', 'companyId', 'isChangeLevel', 'createdAt']),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isCompanyAdminOrOwner("0.companyId") },
        { if: _decorator_1.condition.isCompanyAgency("0.companyId") }
    ])
], TravelPolicyModule, "getAllTravelPolicy", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["where.companyId"], ['attributes', 'where.name', 'where.planeLevels', 'where.planeDiscount',
        'where.trainLevels', 'where.hotelLevels', 'where.hotelPrice', 'where.companyId', 'where.isChangeLevel', 'where.createdAt']),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isCompanyAdminOrOwner("where.companyId") },
        { if: _decorator_1.condition.isCompanyAgency("where.companyId") }
    ])
], TravelPolicyModule, "getTravelPolicies", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["companyId"], ['columns', 'name', 'planeLevels', 'planeDiscount', 'trainLevels', 'hotelLevels', 'hotelPrice', 'companyId', 'isChangeLevel', 'createdAt']),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isCompanyAdminOrOwner("0.companyId") },
        { if: _decorator_1.condition.isCompanyAgency("0.companyId") }
    ])
], TravelPolicyModule, "listAndPaginateTravelPolicy", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["subsidyMoney", "name", "travelPolicyId"]),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isTravelPolicyAdminOrOwner("0.travelPolicyId") }
    ])
], TravelPolicyModule, "createSubsidyTemplate", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"])
], TravelPolicyModule, "deleteSubsidyTemplate", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"], subsidyTemplateCols),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isTravelPolicyAdminOrOwner("0.travelPolicyId") }
    ])
], TravelPolicyModule, "updateSubsidyTemplate", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"], ["travelPolicyId"])
], TravelPolicyModule, "getSubsidyTemplate", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["where.travelPolicyId"], ['attributes', 'where.name', 'where.subsudyMoney']),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isTravelPolicyCompany("0.where.travelPolicyId") }
    ])
], TravelPolicyModule, "getSubsidyTemplates", null);
function tryConvertToArray(val) {
    if (val && !_.isArray(val)) {
        return [val];
    }
    return val;
}
module.exports = TravelPolicyModule;

//# sourceMappingURL=index.js.map
