"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const _types_1 = require("_types");
const staff_1 = require("_types/staff");
const company_1 = require("_types/company");
const department_1 = require("_types/department");
const promoCode_1 = require("_types/promoCode");
const travelPolicy_1 = require("_types/travelPolicy");
const accordHotel_1 = require("_types/accordHotel");
const notice_1 = require("_types/notice");
const agency_1 = require("_types/agency");
const tripPlan_1 = require("_types/tripPlan");
const auth_1 = require("_types/auth");
const seed_1 = require("_types/seed");
const sequelize_1 = require("common/model/sequelize");
const travelbudget_1 = require("_types/travelbudget");
const ddtalk_1 = require("_types/ddtalk");
const coin_1 = require("_types/coin");
const tripDetailInfo_1 = require("_types/tripPlan/tripDetailInfo");
const index_1 = require("_types/approve/index");
const agency_operate_log_1 = require("_types/agency/agency-operate-log");
const tripFuelAddPackage_1 = require("../_types/tripPackage/tripFuelAddPackage");
const tripBasicPackage_1 = require("../_types/tripPackage/tripBasicPackage");
_types_1.initModels({
    staff: sequelize_1.createServerService(staff_1.Staff),
    credential: sequelize_1.createServerService(staff_1.Credential),
    pointChange: sequelize_1.createServerService(staff_1.PointChange),
    invitedLink: sequelize_1.createServerService(staff_1.InvitedLink),
    staffSupplierInfo: sequelize_1.createServerService(staff_1.StaffSupplierInfo),
    company: sequelize_1.createServerService(company_1.Company),
    supplier: sequelize_1.createServerService(company_1.Supplier),
    tripPlanNumChange: sequelize_1.createServerService(company_1.TripPlanNumChange),
    promoCode: sequelize_1.createServerService(promoCode_1.PromoCode),
    department: sequelize_1.createServerService(department_1.Department),
    staffDepartment: sequelize_1.createServerService(department_1.StaffDepartment),
    travelPolicy: sequelize_1.createServerService(travelPolicy_1.TravelPolicy),
    subsidyTemplate: sequelize_1.createServerService(travelPolicy_1.SubsidyTemplate),
    accordHotel: sequelize_1.createServerService(accordHotel_1.AccordHotel),
    notice: sequelize_1.createServerService(notice_1.Notice),
    noticeAccount: sequelize_1.createServerService(notice_1.NoticeAccount),
    agency: sequelize_1.createServerService(agency_1.Agency),
    agencyUser: sequelize_1.createServerService(agency_1.AgencyUser),
    tripPlan: sequelize_1.createServerService(tripPlan_1.TripPlan),
    tripDetail: sequelize_1.createServerService(tripPlan_1.TripDetail),
    tripDetailInvoice: sequelize_1.createServerService(tripPlan_1.TripDetailInvoice),
    tripDetailTraffic: sequelize_1.createServerService(tripPlan_1.TripDetailTraffic),
    tripDetailHotel: sequelize_1.createServerService(tripPlan_1.TripDetailHotel),
    tripDetailSubsidy: sequelize_1.createServerService(tripDetailInfo_1.TripDetailSubsidy),
    tripDetailSpecial: sequelize_1.createServerService(tripDetailInfo_1.TripDetailSpecial),
    tripPlanLog: sequelize_1.createServerService(tripPlan_1.TripPlanLog),
    moneyChange: sequelize_1.createServerService(company_1.MoneyChange),
    project: sequelize_1.createServerService(tripPlan_1.Project),
    tripApprove: sequelize_1.createServerService(tripPlan_1.TripApprove),
    approve: sequelize_1.createServerService(index_1.Approve),
    account: sequelize_1.createServerService(auth_1.Account),
    seed: sequelize_1.createServerService(seed_1.Seed),
    token: sequelize_1.createServerService(auth_1.Token),
    travelBudgetLog: sequelize_1.createServerService(travelbudget_1.TravelBudgetLog),
    financeCheckCode: sequelize_1.createServerService(tripPlan_1.FinanceCheckCode),
    ddtalkCorp: sequelize_1.createServerService(ddtalk_1.DDTalkCorp),
    ddtalkUser: sequelize_1.createServerService(ddtalk_1.DDTalkUser),
    ddtalkDepartment: sequelize_1.createServerService(ddtalk_1.DDTalkDepartment),
    coinAccount: sequelize_1.createServerService(coin_1.CoinAccount),
    coinAccountChange: sequelize_1.createServerService(coin_1.CoinAccountChange),
    agencyOperateLog: sequelize_1.createServerService(agency_operate_log_1.AgencyOperateLog),
    tripFuelAddPackage: sequelize_1.createServerService(tripFuelAddPackage_1.TripFuelAddPackage),
    tripBasicPackage: sequelize_1.createServerService(tripBasicPackage_1.TripBasicPackage),
});

//# sourceMappingURL=_service.js.map
