/**
 * Created by chen on 2017/3/24.
 */
'use strict';
const tslib_1 = require("tslib");
const helper_1 = require("common/api/helper");
const _types_1 = require("_types");
class TripPackageModule {
    static getBasicTripPackage(params) {
        return _types_1.Models.tripBasicPackage.get(params.id);
    }
    static getFuelAddPackage(params) {
        return _types_1.Models.tripFuelAddPackage.get(params.id);
    }
}
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"])
], TripPackageModule, "getBasicTripPackage", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"])
], TripPackageModule, "getFuelAddPackage", null);
module.exports = TripPackageModule;

//# sourceMappingURL=index.js.map
