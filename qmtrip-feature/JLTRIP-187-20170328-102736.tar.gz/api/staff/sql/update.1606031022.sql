alter table staff.staffs DROP COLUMN  IF EXISTS mobile;
alter table staff.staffs DROP COLUMN  IF EXISTS email;