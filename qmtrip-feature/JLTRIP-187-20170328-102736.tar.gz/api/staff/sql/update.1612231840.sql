alter table staff.point_changes alter column points type numeric(15,2);
alter table staff.point_changes alter column current_point type numeric(15,2);