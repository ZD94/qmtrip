alter table staff.staffs alter column total_points type numeric(15,2);
alter table staff.staffs alter column balance_points type numeric(15,2);