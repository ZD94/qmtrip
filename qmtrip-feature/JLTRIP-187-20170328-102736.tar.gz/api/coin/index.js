/**
 * Created by wlh on 2016/9/29.
 */
'use strict';
const tslib_1 = require("tslib");
const index_1 = require("_types/index");
const helper_1 = require("../../common/api/helper");
const staff_1 = require("_types/staff");
const coin_1 = require("_types/coin");
const language_1 = require("common/language");
class CoinModule {
    static companyCharge(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let { companyId, coins, remark } = params;
            if (!remark) {
                remark = '企业充值';
            }
            let company = yield index_1.Models.company.get(companyId);
            let coinAccount = company.coinAccount;
            //如果企业资金账户不存在,先创建
            if (!coinAccount) {
                coinAccount = index_1.Models.coinAccount.create({});
                coinAccount = yield coinAccount.save();
                company.coinAccount = coinAccount;
                yield company.save();
            }
            return yield coinAccount.addCoin(coins, remark);
        });
    }
    static staffPoint2Coin(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let { staffId, points } = params;
            let staff = yield index_1.Models.staff.get(staffId);
            let company = staff.company;
            let points2coinRate = company.points2coinRate || 50;
            if (staff.balancePoints < points) {
                throw language_1.default.ERR.SHORT_OF_POINT();
            }
            // let coins = Math.floor(points * points2coinRate);
            let coins = points * points2coinRate;
            if (!company.coinAccount || company.coinAccount.balance < coins) {
                throw language_1.default.ERR.COMPANY_SHORT_OF_MONEY_FUND();
            }
            // let orderNo = getOrderNo()
            //减掉企业金币
            let result = yield company.coinAccount.costCoin(coins, `员工${staff.name}(${staff.mobile})积分兑换`);
            //减掉员工积分
            staff.balancePoints = staff.balancePoints - points;
            staff = yield staff.save();
            let pc = staff_1.PointChange.create({
                currentPoints: staff.balancePoints, status: 1,
                staff: staff, company: staff.company,
                points: 0 - points, remark: `${points}积分兑换鲸币`,
                orderId: result.coinAccountChange.id
            });
            yield pc.save();
            //增加员工鲸币
            // return staff.coinAccount.addCoin(coins, `${points}积分兑换${coins}`);
            return staff.$parents["account"]["coinAccount"].addCoin(coins, `${points}积分兑换${coins}`);
        });
    }
    static staffCostCoin(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let { staffId, coins, remark } = params;
            if (!remark) {
                remark = `消费`;
            }
            let staff = yield index_1.Models.staff.get(staffId);
            let coinAccount = staff.coinAccount;
            if (!coinAccount || coinAccount.balance < coins) {
                throw new Error('账户余额不足');
            }
            return yield coinAccount.costCoin(coins, remark);
        });
    }
    static createCoinAccount(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var ca = coin_1.CoinAccount.create(params);
            return ca.save();
        });
    }
    static getCoinAccount(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            return index_1.Models.coinAccount.get(params.id);
        });
    }
    static getCoinAccountChange(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            return index_1.Models.coinAccountChange.get(params.id);
        });
    }
    /**
     * 查找积分变动记录
     * @param params
     * @returns {*}
     */
    static getCoinAccountChanges(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            params.order = params.order || [['createdAt', 'desc']];
            let paginate = yield index_1.Models.coinAccountChange.find(params);
            let ids = paginate.map(function (t) {
                return t.id;
            });
            return { ids: ids, count: paginate['total'] };
        });
    }
}
tslib_1.__decorate([
    helper_1.requireParams(["companyId", "coins"], ['remark'])
], CoinModule, "companyCharge", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['staffId', "points"])
], CoinModule, "staffPoint2Coin", null);
tslib_1.__decorate([
    helper_1.requireParams(["staffId", "coins"], ["remark"])
], CoinModule, "staffCostCoin", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"])
], CoinModule, "getCoinAccount", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"])
], CoinModule, "getCoinAccountChange", null);
tslib_1.__decorate([
    helper_1.clientExport
], CoinModule, "getCoinAccountChanges", null);
module.exports = CoinModule;

//# sourceMappingURL=index.js.map
