alter table coin.coin_accounts alter column income type numeric(15,2);
alter table coin.coin_accounts alter column consume type numeric(15,2);
alter table coin.coin_accounts alter column locks type numeric(15,2);