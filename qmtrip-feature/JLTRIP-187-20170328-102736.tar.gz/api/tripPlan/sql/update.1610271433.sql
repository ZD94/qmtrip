SELECT trip_plan.handle_old_trip_detail_161027();
DROP FUNCTION IF EXISTS trip_plan.handle_old_trip_detail_161027();