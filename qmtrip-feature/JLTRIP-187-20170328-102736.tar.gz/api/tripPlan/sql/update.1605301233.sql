ALTER TABLE trip_plan.trip_plans add COLUMN audit_status INTEGER;
ALTER TABLE trip_plan.trip_plans add COLUMN audit_user UUID;
