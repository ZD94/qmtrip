alter table trip_plan.trip_plans add is_final_budget BOOLEAN;
alter table trip_plan.trip_plans add final_budget_create_at timestamp;