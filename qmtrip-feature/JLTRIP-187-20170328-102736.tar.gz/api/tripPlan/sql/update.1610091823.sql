alter table trip_plan.trip_approves add cancel_remark text default '';
alter table trip_plan.trip_plans add cancel_remark text default '';