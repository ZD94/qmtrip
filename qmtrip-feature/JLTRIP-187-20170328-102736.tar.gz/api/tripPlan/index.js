/**
 * Created by yumiao on 15-12-10.
 */
"use strict";
const tslib_1 = require("tslib");
let sequelize = require("common/model").DB;
let uuid = require("node-uuid");
const language_1 = require("common/language");
let API = require('common/api');
let Logger = require('common/logger');
let logger = new Logger("tripPlan");
let config = require("../../config");
let moment = require("moment");
let scheduler = require('common/scheduler');
const _ = require("lodash");
const helper_1 = require("common/api/helper");
const tripPlan_1 = require("_types/tripPlan");
const _types_1 = require("_types");
const staff_1 = require("_types/staff");
const _decorator_1 = require("api/_decorator");
const model_1 = require("common/model");
const agency_1 = require("_types/agency");
const spendReport_1 = require("./spendReport");
const notice_1 = require("_types/notice/notice");
const travelPolicy_1 = require("_types/travelPolicy");
class TripPlanModule {
    /**
     * 获取出差计划中发送邮件的模板数据详情
     * @param tripPlan
     * @returns {{go: string, back: string, hotel: string}}
     */
    static getPlanEmailDetails(tripPlan) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let go = '', back = '', hotelStr = '', subsidyStr = '', specialStr = '';
            let sumSubsidy = 0;
            let tripDetails = yield _types_1.Models.tripDetail.find({
                where: { tripPlanId: tripPlan.id },
                order: [['created_at', 'asc']]
            });
            let ps = tripDetails.map((tripDetail) => tslib_1.__awaiter(this, void 0, void 0, function* () {
                switch (tripDetail.type) {
                    case tripPlan_1.ETripType.OUT_TRIP:
                        let g = tripDetail;
                        var deptCity = yield API.place.getCityInfo({ cityCode: g.deptCity });
                        var arrivalCity = yield API.place.getCityInfo({ cityCode: g.arrivalCity });
                        go += moment(g.deptDateTime).format('YYYY-MM-DD') + ', ' + deptCity.name + ' 到 ' + arrivalCity.name;
                        // if (g.latestArriveTime)
                        //     go += ', 最晚' + moment(g.latestArriveTime).format('HH:mm') + '到达';
                        go += ', 动态预算￥' + g.budget + '<br>';
                        break;
                    case tripPlan_1.ETripType.BACK_TRIP:
                        let b = tripDetail;
                        var deptCity = yield API.place.getCityInfo({ cityCode: b.deptCity });
                        var arrivalCity = yield API.place.getCityInfo({ cityCode: b.arrivalCity });
                        back += moment(b.deptDateTime).format('YYYY-MM-DD') + ', ' + deptCity.name + ' 到 ' + arrivalCity.name;
                        // if (b.latestArriveTime)
                        //     back += ', 最晚' + moment(b.latestArriveTime).format('HH:mm') + '到达';
                        back += ', 动态预算￥' + b.budget + '<br>';
                        break;
                    case tripPlan_1.ETripType.HOTEL:
                        let h = tripDetail;
                        var city = yield API.place.getCityInfo({ cityCode: h.city });
                        hotelStr += moment(h.checkInDate).format('YYYY-MM-DD') + ' 至 ' + moment(h.checkOutDate).format('YYYY-MM-DD') +
                            ', ' + city.name + ',';
                        if (h.placeName) {
                            hotelStr += h.placeName + ',';
                        }
                        hotelStr += '动态预算￥' + h.budget + '<br>';
                        break;
                    case tripPlan_1.ETripType.SUBSIDY:
                        let s = tripDetail;
                        sumSubsidy += s.budget;
                        break;
                    case tripPlan_1.ETripType.SPECIAL_APPROVE:
                        let specialBudget = tripDetail;
                        specialStr += '￥' + specialBudget.budget;
                        break;
                    default:
                        throw new Error('not support tripdetail Type');
                }
            }));
            yield (Promise.all(ps));
            subsidyStr = `￥${sumSubsidy}`;
            return { go: go, back: back, hotel: hotelStr, subsidy: subsidyStr, special: specialStr };
        });
    }
    static getEmailInfoFromDetails(details) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let goStr = '', backStr = '', hotelStr = '', subsidyStr = '', specialStr = '';
            let sumSubsidy = 0;
            let ps = details.map((d) => tslib_1.__awaiter(this, void 0, void 0, function* () {
                switch (d.type) {
                    case tripPlan_1.ETripType.OUT_TRIP:
                        let d1 = d;
                        var deptCity = yield API.place.getCityInfo({ cityCode: d1.deptCity });
                        var arrivalCity = yield API.place.getCityInfo({ cityCode: d1.arrivalCity });
                        goStr += `${moment(d1.deptDateTime).format('YYYY-MM-DD')}, ${deptCity.name} 到 ${arrivalCity.name}`;
                        // if (d.latestArriveTime)
                        //     goStr += `, 最晚${moment(d.latestArriveTime).format('HH:mm')}到达`;
                        goStr += `, 动态预算￥${d1.budget}<br>`;
                        break;
                    case tripPlan_1.ETripType.BACK_TRIP:
                        let d2 = d;
                        var deptCity = yield API.place.getCityInfo({ cityCode: d2.deptCity });
                        var arrivalCity = yield API.place.getCityInfo({ cityCode: d2.arrivalCity });
                        backStr += `${moment(d2.deptDateTime).format('YYYY-MM-DD')}, ${deptCity.name} 到 ${arrivalCity.name}`;
                        // if (d.latestArriveTime)
                        //     backStr += `, 最晚${moment(d.latestArriveTime).format('HH:mm')}到达`;
                        backStr += `, 动态预算￥${d2.budget}<br>`;
                        break;
                    case tripPlan_1.ETripType.HOTEL:
                        let d3 = d;
                        var city = yield API.place.getCityInfo({ cityCode: d3.city });
                        hotelStr += `${moment(d3.checkInDate).format('YYYY-MM-DD')} 至 ${moment(d3.checkOutDate).format('YYYY-MM-DD')}, ${city.name}`;
                        if (d3.placeName) {
                            hotelStr += `, ${d3.placeName}`;
                        }
                        hotelStr += `, 动态预算￥${d3.budget}<br>`;
                        break;
                    case tripPlan_1.ETripType.SUBSIDY:
                        let d4 = d;
                        sumSubsidy += d4.budget;
                        break;
                    case tripPlan_1.ETripType.SPECIAL_APPROVE:
                        let d5 = d;
                        specialStr += `￥${d5.budget}`;
                        break;
                    default:
                        throw new Error('not support tripdetail Type');
                }
            }));
            yield Promise.all(ps);
            subsidyStr = `￥${sumSubsidy}`;
            return { go: goStr, back: backStr, hotel: hotelStr, subsidy: subsidyStr, special: specialStr };
        });
    }
    /**
     * 获取计划单/预算单信息
     * @param params
     * @returns {*}
     */
    static getTripPlan(params) {
        return _types_1.Models.tripPlan.get(params.id);
    }
    /**
     * 更新计划单/预算单信息
     * @param params
     * @returns {*}
     */
    static updateTripPlan(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let tripPlan = yield _types_1.Models.tripPlan.get(params.id);
            for (let key in params) {
                tripPlan[key] = params[key];
            }
            return tripPlan.save();
        });
    }
    /**
     * 获取差旅计划单/预算单列表
     * @param params
     * @returns {*}
     */
    static listTripPlans(options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            options.order = options.order || [['start_at', 'desc'], ['created_at', 'desc']];
            let paginate = yield _types_1.Models.tripPlan.find(options);
            return { ids: paginate.map((plan) => { return plan.id; }), count: paginate["total"] };
        });
    }
    /**
     * 删除差旅计划单/预算单;用户自己可以删除自己的计划单
     * @param params
     * @returns {*}
     */
    static deleteTripPlan(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let tripPlan = yield _types_1.Models.tripPlan.get(params.id);
            let tripDetails = yield tripPlan.getTripDetails({ where: {} });
            yield tripPlan.destroy();
            yield Promise.all(tripDetails.map((detail) => detail.destroy()));
            return true;
        });
    }
    /**
     * 保存消费记录详情
     * @param params
     * @returns {*}
     */
    static saveTripDetail(params) {
        return _types_1.Models.tripDetail.create(params).save();
    }
    static getTripDetail(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            return _types_1.Models.tripDetail.get(params.id, { notRetChild: true });
        });
    }
    static getOddBudget(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var tripPlan = yield _types_1.Models.tripPlan.get(params.id);
            var oddBudget = tripPlan.budget;
            var details = yield _types_1.Models.tripDetail.find({
                where: { tripPlanId: tripPlan.id },
                order: [['created_at', 'asc']]
            });
            details.forEach(function (item, i) {
                oddBudget = oddBudget - item.expenditure;
            });
            return oddBudget;
        });
    }
    static getTripDetailTraffic(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            return _types_1.Models.tripDetailTraffic.get(params.id);
        });
    }
    static getTripDetailHotel(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            return _types_1.Models.tripDetailHotel.get(params.id);
        });
    }
    static getTripDetailSubsidy(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            return _types_1.Models.tripDetailSubsidy.get(params.id);
        });
    }
    static getTripDetailSpecial(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            return _types_1.Models.tripDetailSpecial.get(params.id);
        });
    }
    /**
     * 更新消费详情
     * @param params
     */
    static updateTripDetail(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let tripDetail = yield _types_1.Models.tripDetail.get(params.id);
            for (let key in params) {
                tripDetail[key] = params[key];
            }
            return tripDetail.save();
        });
    }
    /**
     * 根据出差记录id获取出差详情(包括已删除的)
     * @param params
     * @returns {Promise<string[]>}
     */
    static getTripDetails(options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let details = yield _types_1.Models.tripDetail.find(options);
            let ids = details.map(function (d) {
                return d.id;
            });
            return { ids: ids, count: details['total'] };
        });
    }
    /**
     * 删除差旅消费明细
     * @param params
     * @returns {*}
     */
    static deleteTripDetail(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let tripDetail = yield _types_1.Models.tripDetail.get(params.id);
            yield tripDetail.destroy();
            return true;
        });
    }
    /* 提交计划单
     * @param params
     * @returns {*}
     */
    static commitTripPlan(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let tripPlan = yield _types_1.Models.tripPlan.get(params.id);
            if (tripPlan.status != tripPlan_1.EPlanStatus.WAIT_COMMIT) {
                throw { code: -2, msg: "该出差计划不能提交，请检查状态" };
            }
            let tripDetails = yield tripPlan.getTripDetails({ where: {} });
            if (tripDetails && tripDetails.length > 0) {
                let tripDetailPromise = tripDetails.map(function (detail) {
                    return tslib_1.__awaiter(this, void 0, void 0, function* () {
                        if (detail.type == tripPlan_1.ETripType.SUBSIDY) {
                            return detail;
                        }
                        return tryUpdateTripDetailStatus(detail, tripPlan_1.EPlanStatus.AUDITING);
                    });
                });
                yield (Promise.all(tripDetailPromise));
            }
            //记录日志
            let staff = yield staff_1.Staff.getCurrent();
            let log = _types_1.Models.tripPlanLog.create({ tripPlanId: tripPlan.id, userId: staff.id, remark: `提交票据` });
            yield log.save();
            //更改状态
            tripPlan.isCommit = true;
            tripPlan = yield tryUpdateTripPlanStatus(tripPlan, tripPlan_1.EPlanStatus.AUDITING);
            yield TripPlanModule.notifyDesignatedAcount();
            let default_agency = config.default_agency;
            if (default_agency && default_agency.manager_email) {
                let auditEmail = default_agency.manager_email;
                let accounts = yield _types_1.Models.account.find({ where: { email: auditEmail } });
                if (!accounts || accounts.length <= 0) {
                    return true;
                }
                let user = yield _types_1.Models.agencyUser.get(accounts[0].id);
                if (!user) {
                    user = yield _types_1.Models.staff.get(accounts[0].id);
                }
                let staff = tripPlan.account;
                if (!staff) {
                    staff = yield _types_1.Models.staff.get(tripPlan['accountId']);
                }
                let company = yield tripPlan.getCompany();
                let auditUrl = `${config.host}/agency.html#/travelRecord/TravelDetail?orderId==${tripPlan.id}`;
                let appMessageUrl = `#/travelRecord/TravelDetail?orderId==${tripPlan.id}`;
                let { go, back, hotel, subsidy } = yield TripPlanModule.getPlanEmailDetails(tripPlan);
                let openId = yield API.auth.getOpenIdByAccount({ accountId: user.id });
                let auditValues = { username: user.name, time: tripPlan.createdAt, auditUserName: user.name, companyName: company.name, staffName: staff.name, projectName: tripPlan.title, goTrafficBudget: go,
                    backTrafficBudget: back, hotelBudget: hotel, otherBudget: subsidy, totalBudget: tripPlan.budget, appMessageUrl: appMessageUrl, url: auditUrl, detailUrl: auditUrl,
                    approveUser: user.name, tripPlanNo: tripPlan.planNo,
                    content: `企业 ${company.name} 员工 ${staff.name}${moment(tripPlan.startAt).format('YYYY-MM-DD')}到${tripPlan.arrivalCity}的出差计划票据已提交，预算：￥${tripPlan.budget}，等待您审核！`,
                    createdAt: moment(new Date()).format('YYYY-MM-DD HH:mm:ss'),
                };
                try {
                    yield API.notify.submitNotify({
                        key: 'qm_notify_agency_budget',
                        values: auditValues,
                        accountId: default_agency.id
                    });
                }
                catch (err) {
                    console.error(err);
                }
            }
            return true;
        });
    }
    /**
     * 审核出差票据
     *
     * @param params
     */
    static auditPlanInvoice(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            const SAVED2SCORE = config.score_ratio;
            let { id, expenditure, reason, auditResult } = params;
            let tripDetail = yield _types_1.Models.tripDetail.get(params.id);
            if ((tripDetail.status != tripPlan_1.EPlanStatus.AUDITING) && (tripDetail.status != tripPlan_1.EPlanStatus.AUDIT_NOT_PASS)) {
                throw language_1.default.ERR.TRIP_PLAN_STATUS_ERR();
            }
            let audit = params.auditResult;
            let tripPlan = yield _types_1.Models.tripPlan.get(tripDetail.tripPlanId);
            let templateValue = {
                invoiceDetail: '无',
                projectName: tripPlan.title,
                totalBudget: '￥' + tripPlan.budget,
                time: moment(tripPlan.startAt).format('YYYY-MM-DD')
            };
            let templateName = '';
            let isNotify = false;
            let savedMoney = 0;
            let logResult = '';
            if (audit == tripPlan_1.EAuditStatus.INVOICE_PASS) {
                logResult = '通过';
                tripDetail.status = tripPlan_1.EPlanStatus.COMPLETE;
                tripDetail.expenditure = expenditure;
                let query = { where: { id: { $ne: tripDetail.id }, status: [tripPlan_1.EPlanStatus.AUDITING, tripPlan_1.EPlanStatus.AUDIT_NOT_PASS] } };
                let noAuditDetails = yield tripPlan.getTripDetails(query); //获取所有未经过审核的票据
                if (!noAuditDetails || noAuditDetails.length == 0) {
                    isNotify = true;
                    let details = yield tripPlan.getTripDetails({ where: {} });
                    let expenditure = 0;
                    details.forEach((detail) => {
                        expenditure += Number(detail.expenditure);
                    });
                    tripPlan.expenditure = expenditure;
                    tripPlan.status = tripPlan_1.EPlanStatus.COMPLETE;
                    tripPlan.auditStatus = tripPlan_1.EAuditStatus.INVOICE_PASS;
                    savedMoney = (tripPlan.budget - tripPlan.expenditure);
                    savedMoney = savedMoney > 0 ? savedMoney : 0;
                    tripPlan.score = parseInt((savedMoney * SAVED2SCORE).toString());
                }
                templateValue.consume = '￥' + (tripDetail.expenditure || 0);
                templateName = 'qm_notify_invoice_one_pass';
                let detailSavedM = tripDetail.budget - tripDetail.expenditure;
                detailSavedM = detailSavedM > 0 ? detailSavedM : 0;
                if (tripPlan.isSpecialApprove) {
                    templateValue.invoiceDetail += '，实际花费：' + tripDetail.expenditure + '元';
                }
                else {
                    templateValue.invoiceDetail += '，实际花费：' + tripDetail.expenditure + '元，节省：' + detailSavedM + '元';
                }
            }
            else if (audit == tripPlan_1.EAuditStatus.INVOICE_NOT_PASS) {
                logResult = '未通过';
                isNotify = true;
                tripDetail.auditRemark = reason;
                tripDetail.status = tripPlan_1.EPlanStatus.AUDIT_NOT_PASS;
                tripPlan.status = tripPlan_1.EPlanStatus.AUDIT_NOT_PASS;
                tripPlan.auditStatus = tripPlan_1.EAuditStatus.INVOICE_NOT_PASS;
                templateValue.reason = reason;
                templateName = 'qm_notify_invoice_not_pass';
            }
            else {
                throw language_1.default.ERR.PERMISSION_DENY(); //代理商只能审核票据权限
            }
            //保存更改记录
            yield Promise.all([tripPlan.save(), tripDetail.save()]);
            /*******************************************发送通知消息**********************************************/
            let staff = yield _types_1.Models.staff.get(tripPlan['accountId']);
            switch (tripDetail.type) {
                case tripPlan_1.ETripType.OUT_TRIP:
                    let d1 = tripDetail;
                    var deptCity = yield API.place.getCityInfo({ cityCode: d1.deptCity });
                    var arrivalCity = yield API.place.getCityInfo({ cityCode: d1.arrivalCity });
                    templateValue.tripType = '去程';
                    templateValue.invoiceDetail = `${moment(d1.deptDateTime).format('YYYY-MM-DD')} 由 ${deptCity.name} 到 ${arrivalCity.name}， 去程发票， 预算：${d1.budget}元`;
                    break;
                case tripPlan_1.ETripType.BACK_TRIP:
                    let d2 = tripDetail;
                    var deptCity = yield API.place.getCityInfo({ cityCode: d2.deptCity });
                    var arrivalCity = yield API.place.getCityInfo({ cityCode: d2.arrivalCity });
                    templateValue.tripType = '回程';
                    templateValue.invoiceDetail = `${moment(d2.deptDateTime).format('YYYY-MM-DD')} 由 ${deptCity.name} 到 ${arrivalCity.name}， 回程发票， 预算：${d2.budget}元`;
                    break;
                case tripPlan_1.ETripType.HOTEL:
                    let d3 = tripDetail;
                    var city = yield API.place.getCityInfo({ cityCode: d3.city });
                    templateValue.tripType = '酒店';
                    templateValue.invoiceDetail = `${moment(d3.checkInDate).format('YYYY.MM.DD')} - ${moment(d3.checkOutDate).format('YYYY.MM.DD')}， ${city.name}`;
                    if (d3.placeName) {
                        templateValue.invoiceDetail += d3.placeName;
                    }
                    templateValue.invoiceDetail += `，酒店发票，预算：${d3.budget}元`;
                    break;
                case tripPlan_1.ETripType.SUBSIDY:
                    let d4 = tripDetail;
                    templateValue.tripType = '补助';
                    templateValue.invoiceDetail = `补助发票，预算：${d4.budget}元`;
                    break;
                case tripPlan_1.ETripType.SPECIAL_APPROVE:
                    let d5 = tripDetail;
                    templateValue.tripType = '特殊审批';
                    templateValue.invoiceDetail = `特殊审批发票,预算 ${d5.budget}元`;
                    break;
                default:
                    templateValue.tripType = '';
                    break;
            }
            if (isNotify) {
                if (tripPlan.status == tripPlan_1.EPlanStatus.COMPLETE) {
                    if (tripPlan.isSpecialApprove) {
                        templateValue.invoiceDetail = `${moment(tripPlan.startAt).format('YYYY-MM-DD')}到${tripPlan.arrivalCity}的出差票据，预算：${tripPlan.budget}元，实际花费：${tripPlan.expenditure}元`;
                    }
                    else {
                        templateValue.invoiceDetail = `${moment(tripPlan.startAt).format('YYYY-MM-DD')}到${tripPlan.arrivalCity}的出差票据，预算：${tripPlan.budget}元，实际花费：${tripPlan.expenditure}元，节省：${savedMoney}元`;
                    }
                }
                let { go, back, hotel, subsidy } = yield TripPlanModule.getPlanEmailDetails(tripPlan);
                let self_url = `${config.host}/index.html#/trip/list-detail?tripid=${tripPlan.id}`;
                let appMessageUrl = `#/trip/list-detail?tripid=${tripPlan.id}`;
                templateValue.ticket = templateValue.tripType;
                templateValue.username = staff.name;
                templateValue.goTrafficBudget = go;
                templateValue.backTrafficBudget = back;
                templateValue.hotelBudget = hotel;
                templateValue.otherBudget = subsidy;
                templateValue.detailUrl = self_url;
                templateValue.url = self_url;
                templateValue.appMessageUrl = appMessageUrl;
                templateValue.auditUser = '鲸力商旅';
                templateValue.auditTime = moment(new Date()).format('YYYY-MM-DD HH:mm:ss');
                let openId = yield API.auth.getOpenIdByAccount({ accountId: staff.id });
                try {
                    yield API.notify.submitNotify({ key: templateName, values: templateValue, accountId: staff.id });
                }
                catch (err) {
                    console.error(`发送通知失败:`, err);
                }
                try {
                    yield API.ddtalk.sendLinkMsg({ accountId: staff.id, text: '票据已审批通过', url: self_url });
                }
                catch (err) {
                    console.error(`发送钉钉通知失败`, err);
                }
            }
            let user = yield agency_1.AgencyUser.getCurrent();
            let log = _types_1.Models.tripPlanLog.create({ tripPlanId: tripPlan.id, tripDetailId: tripDetail.id, userId: user.id, remark: `${templateValue.tripType}票据审核${logResult}` });
            log.save();
            //如果出差已经完成,并且有节省反积分,并且非特别审批，增加员工积分
            if (tripPlan.status == tripPlan_1.EPlanStatus.COMPLETE && tripPlan.score > 0 && !tripPlan.isSpecialApprove) {
                let pc = _types_1.Models.pointChange.create({
                    currentPoints: staff.balancePoints, status: 1,
                    staff: staff, company: staff.company,
                    points: tripPlan.score, remark: `节省反积分${tripPlan.score}`,
                    orderId: tripPlan.id
                });
                yield pc.save();
                try {
                    if (!staff.totalPoints) {
                        staff.totalPoints = 0;
                    }
                    if (!tripPlan.score) {
                        tripPlan.score = 0;
                    }
                    if (!staff.balancePoints) {
                        staff.balancePoints = 0;
                    }
                    if (typeof staff.totalPoints == 'string') {
                        staff.totalPoints = Number(staff.totalPoints);
                    }
                    if (typeof tripPlan.score == 'string') {
                        tripPlan.score = Number(tripPlan.score);
                    }
                    if (typeof staff.balancePoints == 'string') {
                        staff.balancePoints = Number(staff.balancePoints);
                    }
                    staff.totalPoints = staff.totalPoints + tripPlan.score;
                    staff.balancePoints = staff.balancePoints + tripPlan.score;
                    let log = _types_1.Models.tripPlanLog.create({ tripPlanId: tripPlan.id, userId: user.id, remark: `增加员工${tripPlan.score}积分` });
                    console.info("查看sql================");
                    yield Promise.all([staff.save(), log.save()]);
                }
                catch (err) {
                    //如果保存出错,删除日志记录
                    yield pc.destroy();
                }
            }
            return true;
        });
    }
    static createProject(params) {
        return tripPlan_1.Project.create(params).save();
    }
    static getProjectById(params) {
        return _types_1.Models.project.get(params.id);
    }
    static getProjectList(options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            options.order = options.order || [['weight', 'desc'], ['created_at', 'desc']];
            let projects = yield _types_1.Models.project.find(options);
            return { ids: projects.map((p) => { return p.id; }), count: projects['total'] };
        });
    }
    static deleteProject(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let project = yield _types_1.Models.project.get(params.id);
            return yield project.destroy();
        });
    }
    /**
     * @method saveTripPlanLog
     * 保存出差计划改动日志
     * @type {saveTripPlanLog}
     */
    static saveTripPlanLog(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let staff = yield staff_1.Staff.getCurrent();
            params.userId = staff.id;
            return tripPlan_1.TripPlanLog.create(params).save();
        });
    }
    /**
     * @method getTripPlanLog
     * @param params
     * @returns {any}
     */
    static getTripPlanLog(params) {
        return _types_1.Models.tripPlanLog.get(params.id);
    }
    /**
     * @method updateTripPlanLog
     * @param param
     */
    static updateTripPlanLog(param) {
        throw { code: -1, msg: '不能更新日志' };
    }
    static getTripPlanLogs(options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let paginate = yield _types_1.Models.tripPlanLog.find(options);
            return { ids: paginate.map((plan) => { return plan.id; }), count: paginate["total"] };
        });
    }
    /**
     * 撤销tripPlan
     * @param params
     * @returns {boolean}
     */
    static cancelTripPlan(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let tripPlan = yield _types_1.Models.tripPlan.get(params.id);
            if (tripPlan.status != tripPlan_1.EPlanStatus.NO_BUDGET && tripPlan.status != tripPlan_1.EPlanStatus.WAIT_UPLOAD) {
                throw { code: -2, msg: "出差记录状态不正确！" };
            }
            let tripDetails = yield tripPlan.getTripDetails({});
            if (tripDetails && tripDetails.length > 0) {
                yield Promise.all(tripDetails.map((d) => {
                    d.status = tripPlan_1.EPlanStatus.CANCEL;
                    return d.save();
                }));
            }
            tripPlan.status = tripPlan_1.EPlanStatus.CANCEL;
            tripPlan.cancelRemark = params.remark || "";
            let staff = yield staff_1.Staff.getCurrent();
            let log = _types_1.Models.tripPlanLog.create({ tripPlanId: tripPlan.id, userId: staff.id, remark: `撤销行程` });
            yield Promise.all([tripPlan.save(), log.save()]);
            yield tripPlan.save();
            return true;
        });
    }
    //
    /********************************************统计相关API***********************************************/
    static statisticTripPlanOfMonth(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let staff = yield staff_1.Staff.getCurrent();
            let companyId = staff.company.id;
            let month = params.month;
            let startTime = month + '-01';
            let endTime = moment(startTime).add(1, 'months').format('YYYY-MM-DD');
            let where_sql = 'from trip_plan.trip_plans where company_id=\''
                + companyId + '\' and status!=(' + tripPlan_1.EPlanStatus.CANCEL + ')  and status!=(' + tripPlan_1.EPlanStatus.NO_BUDGET + ') and start_at>=\''
                + startTime + '\' and start_at<\'' + endTime + '\'';
            let complete_sql = 'from trip_plan.trip_plans where company_id=\''
                + companyId + '\' and status=' + tripPlan_1.EPlanStatus.COMPLETE + ' and start_at>=\''
                + startTime + '\' and start_at<\'' + endTime + '\'';
            let staff_num_sql = 'select count(1) as \"staffNum\" from (select account_id ' + where_sql + ') as Project;';
            let project_num_sql = 'select count(1) as \"projectNum\" from (select distinct project_id ' + where_sql + ') as Project;';
            let budget_sql = 'select sum(budget) as \"dynamicBudget\" ' + complete_sql;
            let saved_sql = 'select sum(budget-expenditure) as \"savedMoney\" ' + complete_sql;
            let expenditure_sql = 'select sum(expenditure) as expenditure ' + complete_sql;
            let staff_num_sql_ret = yield sequelize.query(staff_num_sql);
            let project_num_sql_ret = yield sequelize.query(project_num_sql);
            let budget_sql_ret = yield sequelize.query(budget_sql);
            let saved_sql_ret = yield sequelize.query(saved_sql);
            let expenditure_sql_ret = yield sequelize.query(expenditure_sql);
            return {
                month: month,
                staffNum: Number(staff_num_sql_ret[0][0].staffNum || 0),
                projectNum: Number(project_num_sql_ret[0][0].projectNum || 0),
                dynamicBudget: budget_sql_ret[0][0].dynamicBudget || 0,
                savedMoney: saved_sql_ret[0][0].savedMoney || 0,
                expenditure: expenditure_sql_ret[0][0].expenditure || 0
            };
        });
    }
    static statisticTripBudget(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let staff = yield staff_1.Staff.getCurrent();
            let companyId = staff.company.id;
            let formatStr = 'YYYY-MM-DD HH:mm:ss';
            let selectSql = `select count(id) as "tripNum", sum(budget) as budget, sum(expenditure) as expenditure, sum(budget-expenditure) as "savedMoney" from`;
            let completeSql = `trip_plan.trip_plans where deleted_at is null and company_id='${companyId}'`;
            if (params.startTime) {
                let startTime = moment(params.startTime).format(formatStr);
                completeSql += ` and start_at>='${startTime}'`;
            }
            if (params.endTime) {
                let endTime = moment(params.endTime).format(formatStr);
                completeSql += ` and start_at<='${endTime}'`;
            }
            if (params.isStaff) {
                completeSql += ` and account_id='${staff.id}'`;
            }
            let planSql = `${completeSql}  and status in (${tripPlan_1.EPlanStatus.WAIT_UPLOAD}, ${tripPlan_1.EPlanStatus.WAIT_COMMIT}, ${tripPlan_1.EPlanStatus.AUDITING}, ${tripPlan_1.EPlanStatus.AUDIT_NOT_PASS}, ${tripPlan_1.EPlanStatus.COMPLETE})`;
            completeSql += ` and status=${tripPlan_1.EPlanStatus.COMPLETE}`;
            let savedMoneyCompleteSql = completeSql + ' and is_special_approve = false';
            let savedMoneyComplete = `${selectSql} ${savedMoneyCompleteSql};`;
            let complete = `${selectSql} ${completeSql};`;
            let plan = `${selectSql} ${planSql};`;
            let savedMoneyCompleteInfo = yield sequelize.query(savedMoneyComplete);
            let completeInfo = yield sequelize.query(complete);
            let planInfo = yield sequelize.query(plan);
            let ret = {
                planTripNum: 0,
                completeTripNum: 0,
                planBudget: 0,
                completeBudget: 0,
                expenditure: 0,
                actualExpenditure: 0,
                savedMoney: 0 //节省
            };
            if (completeInfo && completeInfo.length > 0 && completeInfo[0].length > 0) {
                let c = completeInfo[0][0];
                ret.completeTripNum = Number(c.tripNum);
                ret.expenditure = Number(c.expenditure);
            }
            if (savedMoneyCompleteInfo && savedMoneyCompleteInfo.length > 0 && savedMoneyCompleteInfo[0].length > 0) {
                let c = savedMoneyCompleteInfo[0][0];
                ret.completeBudget = Number(c.budget);
                ret.savedMoney = Number(c.savedMoney);
                ret.actualExpenditure = Number(c.expenditure);
            }
            if (planInfo && planInfo.length > 0 && planInfo[0].length > 0) {
                let p = planInfo[0][0];
                ret.planTripNum = Number(p.tripNum);
                ret.planBudget = Number(p.budget);
            }
            return ret;
        });
    }
    /**
     * 按员工、项目、部门分类统计预算信息
     * @param params
     * @returns {{}}
     */
    static statisticBudgetsInfo(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let staff = yield staff_1.Staff.getCurrent();
            let company = staff.company;
            let completeSql = `from trip_plan.trip_plans where deleted_at is null and company_id='${company.id}' and status=${tripPlan_1.EPlanStatus.COMPLETE} and start_at>'${params.startTime}' and start_at<'${params.endTime}'`;
            let savedMoneyCompleteSql = '';
            let planSql = `from trip_plan.trip_plans where deleted_at is null and company_id='${company.id}' and status in (${tripPlan_1.EPlanStatus.WAIT_UPLOAD},${tripPlan_1.EPlanStatus.WAIT_COMMIT}, ${tripPlan_1.EPlanStatus.AUDIT_NOT_PASS}, ${tripPlan_1.EPlanStatus.AUDITING}, ${tripPlan_1.EPlanStatus.COMPLETE}) and start_at>'${params.startTime}' and start_at<'${params.endTime}'`;
            let type = params.type;
            let selectKey = '', modelName = '';
            if (type == 'S' || type == 'P') {
                selectKey = type == 'S' ? 'account_id' : 'project_id';
                modelName = type == 'S' ? 'staff' : 'project';
                if (params.keyWord) {
                    let pagers = yield _types_1.Models[modelName].find({ where: { name: { $like: `%${params.keyWord}%` }, companyId: company.id }, order: [['created_at', 'desc']] });
                    let objs = [];
                    objs.push.apply(objs, pagers);
                    while (pagers.hasNextPage()) {
                        let nextPager = yield pagers.nextPage();
                        objs.push.apply(objs, nextPager);
                        // pagers = nextPager;
                    }
                    let selectStr = '';
                    objs.map((s) => {
                        if (s && s.id) {
                            selectStr += selectStr ? `,'${s.id}'` : `'${s.id}'`;
                        }
                    });
                    if (!selectStr || selectStr == '') {
                        selectStr = `'${uuid.v1()}'`;
                    }
                    completeSql += ` and ${selectKey} in (${selectStr})`;
                    planSql += ` and ${selectKey} in (${selectStr})`;
                }
                savedMoneyCompleteSql = completeSql + ' and is_special_approve = false';
                completeSql += ` group by ${selectKey};`;
                savedMoneyCompleteSql += ` group by ${selectKey};`;
                planSql += ` group by ${selectKey};`;
            }
            let selectSql = `select ${selectKey}, count(1) as "tripNum", sum(budget) as budget, sum(expenditure) as expenditure`;
            let savedMoneySelectSql = `select ${selectKey}, sum(budget-expenditure) as "savedMoney"`;
            let complete = `${selectSql} ${completeSql}`;
            let savedMoneyComplete = `${savedMoneySelectSql} ${savedMoneyCompleteSql}`;
            let plan = `${selectSql} ${planSql}`;
            if (type == 'D') {
                selectKey = 'departmentId';
                completeSql = `from department.departments as d, staff.staffs as s, trip_plan.trip_plans as p where d.deleted_at is null and s.deleted_at is null and p.deleted_at is null and p.company_id='${company.id}' and d.id=s.department_id and p.account_id=s.id and p.start_at>'${params.startTime}' and p.start_at<'${params.endTime}'`;
                savedMoneyCompleteSql = '';
                planSql = `${completeSql} and p.status in (${tripPlan_1.EPlanStatus.WAIT_UPLOAD},${tripPlan_1.EPlanStatus.WAIT_COMMIT}, ${tripPlan_1.EPlanStatus.AUDIT_NOT_PASS}, ${tripPlan_1.EPlanStatus.AUDITING}, ${tripPlan_1.EPlanStatus.COMPLETE})`;
                completeSql += ` and p.status=${tripPlan_1.EPlanStatus.COMPLETE}`;
                if (params.keyWord) {
                    let pagers = yield _types_1.Models.department.find({ where: { name: { $like: `%${params.keyWord}%` }, companyId: company.id }, order: [['created_at', 'desc']] });
                    let depts = [];
                    depts.push.apply(depts, pagers);
                    while (pagers.hasNextPage()) {
                        let nextPager = yield pagers.nextPage();
                        depts.push.apply(depts, nextPager);
                        // pagers = nextPager;
                    }
                    let deptStr = '';
                    depts.map((s) => {
                        if (s && s.id) {
                            deptStr += deptStr ? `,'${s.id}'` : `'${s.id}'`;
                        }
                    });
                    if (!deptStr || deptStr == '') {
                        deptStr = `'${uuid.v1()}'`;
                    }
                    completeSql += ` and d.id in (${deptStr})`;
                    planSql += ` and d.id in (${deptStr})`;
                }
                savedMoneyCompleteSql = completeSql + ' and is_special_approve = false';
                selectSql = `select d.id as "departmentId", count(p.id) as "tripNum",sum(p.budget) as budget, sum(p.expenditure) as expenditure, sum(p.budget-p.expenditure) as "savedMoney"`;
                savedMoneySelectSql = `select d.id as "departmentId", sum(p.budget-p.expenditure) as "savedMoney"`;
                complete = `${selectSql} ${completeSql} group by d.id;`;
                savedMoneyComplete = `${savedMoneySelectSql} ${savedMoneyCompleteSql} group by d.id;`;
                plan = `${selectSql} ${planSql} group by d.id;`;
            }
            let completeInfo = yield sequelize.query(complete);
            let savedMoneyCompleteInfo = yield sequelize.query(savedMoneyComplete);
            let planInfo = yield sequelize.query(plan);
            let result = {};
            if (completeInfo && completeInfo.length > 0 && completeInfo[0].length > 0) {
                completeInfo[0].map((ret) => {
                    result[ret[selectKey]] = {
                        typeKey: ret[selectKey],
                        completeTripNum: Number(ret.tripNum),
                        completeBudget: Number(ret.budget),
                        expenditure: Number(ret.expenditure),
                    };
                });
            }
            if (savedMoneyCompleteInfo && savedMoneyCompleteInfo.length > 0 && savedMoneyCompleteInfo[0].length > 0) {
                savedMoneyCompleteInfo[0].map((ret) => {
                    let key = ret[selectKey];
                    if (!result[key]) {
                        result[key] = {};
                    }
                    result[key].savedMoney = Number(ret.savedMoney);
                });
            }
            if (planInfo && planInfo.length > 0 && planInfo[0].length > 0) {
                planInfo[0].map((ret) => {
                    let key = ret[selectKey];
                    if (!result[key]) {
                        result[key] = {};
                    }
                    result[key].typeKey = ret[selectKey];
                    result[key].planTripNum = Number(ret.tripNum);
                    result[key].planBudget = Number(ret.budget);
                    if (!result[key].expenditure) {
                        result[key].expenditure = 0;
                    }
                });
            }
            result = _.orderBy(_.values(result), ['expenditure'], ['desc']);
            return result;
        });
    }
    /**
     * @method saveTripPlan
     * 生成出差计划单
     * @param params
     * @returns {Promise<TripPlan>}
     */
    static saveTripPlanByApprove(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let formatStr = 'YYYY-MM-DD';
            let approve = yield _types_1.Models.approve.get(params.tripApproveId);
            let account = yield _types_1.Models.staff.get(approve.submitter);
            let approveUser = yield _types_1.Models.staff.get(approve.approveUser);
            let currentUser = yield staff_1.Staff.getCurrent();
            let company = approve.approveUser ? approveUser.company : currentUser.company;
            if (typeof approve.data == 'string')
                approve.data = JSON.parse(approve.data);
            let query = approve.data.query; //查询条件
            if (typeof query == 'string')
                query = JSON.parse(query);
            if (typeof query.destinationPlacesInfo == 'string')
                query.destinationPlacesInfo = JSON.parse(query.destinationPlacesInfo);
            let destinationPlacesInfo = query.destinationPlacesInfo;
            let budgets = approve.data.budgets;
            if (typeof budgets == 'string')
                budgets = JSON.parse(budgets);
            let tripPlan = tripPlan_1.TripPlan.create({ id: approve.id });
            let projectIds = []; //事由名称
            let arrivalCityCodes = []; //目的地代码
            let project;
            if (query.originPlace) {
                let deptInfo = (yield API.place.getCityInfo({ cityCode: query.originPlace.id || query.originPlace })) || { name: null };
                tripPlan.deptCityCode = deptInfo.id;
                tripPlan.deptCity = deptInfo.name;
            }
            tripPlan.isRoundTrip = query.isRoundTrip;
            if (destinationPlacesInfo && _.isArray(destinationPlacesInfo) && destinationPlacesInfo.length > 0) {
                for (let i = 0; i < destinationPlacesInfo.length; i++) {
                    let segment = destinationPlacesInfo[i];
                    //处理出差事由放入projectIds 原project存放第一程出差事由
                    if (segment.reason) {
                        let projectItem = yield TripPlanModule.getProjectByName({ companyId: company.id, name: segment.reason,
                            userId: account.id, isCreate: true });
                        if (i == 0) {
                            project = projectItem;
                        }
                        if (projectIds.indexOf(projectItem.id) == -1) {
                            projectIds.push(projectItem.id);
                        }
                    }
                    //处理目的地 放入arrivalCityCodes 原目的地信息存放第一程目的地信息
                    if (segment.destinationPlace) {
                        let place = segment.destinationPlace;
                        if (typeof place != 'string') {
                            place = place['id'];
                        }
                        let arrivalInfo = (yield API.place.getCityInfo({ cityCode: place })) || { name: null };
                        arrivalCityCodes.push(arrivalInfo.id);
                        if (i == (destinationPlacesInfo.length - 1)) {
                            tripPlan.arrivalCityCode = arrivalInfo.id;
                            tripPlan.arrivalCity = arrivalInfo.name;
                        }
                    }
                    //处理其他数据
                    if (i == 0) {
                        tripPlan.startAt = segment.leaveDate;
                        //处理原始数据 用第一程数据
                        tripPlan.isNeedTraffic = segment.isNeedTraffic;
                        tripPlan.isNeedHotel = segment.isNeedHotel;
                    }
                    if (i == (destinationPlacesInfo.length - 1)) {
                        tripPlan.backAt = segment.goBackDate;
                    }
                }
            }
            tripPlan.projectIds = JSON.stringify(projectIds);
            tripPlan.arrivalCityCodes = JSON.stringify(arrivalCityCodes);
            tripPlan['companyId'] = account.company.id;
            tripPlan.auditUser = tryObjId(approveUser);
            tripPlan.project = project;
            tripPlan.title = approve.title; //project名称
            tripPlan.account = account;
            tripPlan.status = tripPlan_1.EPlanStatus.WAIT_UPLOAD;
            tripPlan.planNo = yield API.seeds.getSeedNo('TripPlanNo'); //获取出差计划单号
            tripPlan.query = query;
            tripPlan.isSpecialApprove = approve.isSpecialApprove;
            tripPlan.specialApproveRemark = approve.specialApproveRemark;
            //计算总预算
            let totalBudget = budgets
                .map((item) => {
                return Number(item.price) || 0;
            })
                .reduce((total, cur) => {
                return total + cur;
            }, 0);
            tripPlan.budget = totalBudget;
            let log = tripPlan_1.TripPlanLog.create({ tripPlanId: tripPlan.id, userId: tryObjId(approveUser), remark: `出差审批通过，生成出差记录` });
            yield Promise.all([tripPlan.save(), log.save()]);
            let tripDetails = [];
            tripDetails = budgets.map(function (budget) {
                let tripType = budget.tripType;
                let price = Number(budget.price);
                let detail;
                let data = {};
                if (budget.originPlace) {
                    if (typeof budget.originPlace == 'string')
                        budget.originPlace = JSON.parse(budget.originPlace);
                }
                if (budget.destination) {
                    if (typeof budget.destination == 'string')
                        budget.destination = JSON.parse(budget.destination);
                }
                switch (tripType) {
                    case tripPlan_1.ETripType.OUT_TRIP:
                        data.deptCity = budget.originPlace ? budget.originPlace.id : "";
                        data.arrivalCity = budget.destination.id;
                        data.deptDateTime = budget.departDateTime;
                        data.arrivalDateTime = budget.arrivalDateTime;
                        data.leaveDate = budget.leaveDate;
                        data.cabin = budget.cabinClass;
                        data.invoiceType = budget.type;
                        detail = _types_1.Models.tripDetailTraffic.create(data);
                        tripPlan.isNeedTraffic = true;
                        break;
                    case tripPlan_1.ETripType.BACK_TRIP:
                        data.deptCity = budget.originPlace ? budget.originPlace.id : "";
                        data.arrivalCity = budget.destination.id;
                        data.deptDateTime = budget.departDateTime;
                        data.arrivalDateTime = null;
                        data.leaveDate = budget.leaveDate;
                        data.cabin = budget.cabinClass;
                        data.invoiceType = budget.type;
                        detail = _types_1.Models.tripDetailTraffic.create(data);
                        tripPlan.isNeedTraffic = true;
                        break;
                    case tripPlan_1.ETripType.HOTEL:
                        data.city = budget.cityName;
                        data.placeName = budget.hotelName;
                        data.name = budget.name;
                        data.position = budget.hotelName;
                        data.checkInDate = budget.checkInDate;
                        data.checkOutDate = budget.checkOutDate;
                        detail = _types_1.Models.tripDetailHotel.create(data);
                        tripPlan.isNeedHotel = true;
                        break;
                    case tripPlan_1.ETripType.SUBSIDY:
                        data.hasFirstDaySubsidy = budget.hasFirstDaySubsidy;
                        data.hasLastDaySubsidy = budget.hasLastDaySubsidy;
                        data.template = budget.template.id;
                        data.subsidyMoney = budget.price; //此字段做什么
                        data.startDateTime = budget.fromDate;
                        data.endDateTime = budget.endDate;
                        detail = _types_1.Models.tripDetailSubsidy.create(data);
                        detail.expenditure = price; //此字段与budget字段有什么区别
                        detail.status = tripPlan_1.EPlanStatus.COMPLETE;
                        break;
                    case tripPlan_1.ETripType.SPECIAL_APPROVE:
                        data.deptCity = budget.originPlace ? budget.originPlace.id : "";
                        data.arrivalCity = budget.destination.id;
                        data.deptDateTime = budget.startAt;
                        data.arrivalDateTime = budget.backAt;
                        detail = _types_1.Models.tripDetailSpecial.create(data);
                        break;
                    default:
                        throw new Error("not support tripDetail type!");
                }
                detail.type = tripType;
                detail.budget = price;
                detail.accountId = account.id;
                detail.status = tripPlan_1.EPlanStatus.WAIT_UPLOAD;
                detail.tripPlanId = tripPlan.id;
                return detail;
            });
            if (tripDetails && tripDetails.length > 0) {
                let ps = tripDetails.map((d) => {
                    return d.save();
                });
                yield Promise.all(ps);
            }
            let data = yield TripPlanModule.getPlanEmailDetails(tripPlan);
            let { go, back, hotel, subsidy } = data;
            let self_url = config.host + '/index.html#/trip/list-detail?tripid=' + approve.id;
            let appMessageUrl = '#/trip/list-detail?tripid=' + approve.id;
            try {
                self_url = yield API.wechat.shorturl({ longurl: self_url });
            }
            catch (err) {
                console.error(err);
            }
            let self_values = {
                noticeType: notice_1.ENoticeType.TRIP_APPROVE_NOTICE,
                username: account.name,
                planNo: tripPlan.planNo,
                approveTime: moment(new Date()).format('YYYY-MM-DD HH:mm:ss'),
                approveUser: approveUser ? approveUser.name : "",
                projectName: tripPlan.title,
                goTrafficBudget: go,
                backTrafficBudget: back,
                hotelBudget: hotel,
                otherBudget: subsidy,
                totalBudget: '￥' + tripPlan.budget,
                url: self_url,
                detailUrl: self_url,
                appMessageUrl: appMessageUrl,
                time: moment(tripPlan.startAt).format('YYYY-MM-DD'),
                destination: tripPlan.arrivalCity,
                staffName: account.name,
                startTime: moment(tripPlan.startAt).format('YYYY-MM-DD'),
                arrivalCity: tripPlan.arrivalCity,
                budget: tripPlan.budget,
                tripPlanNo: tripPlan.planNo,
                approveResult: tripPlan_1.EApproveResult2Text[tripPlan_1.EApproveResult.PASS],
                reason: '',
                emailReason: '',
                startAt: moment(tripPlan.startAt).format('MM.DD'),
                backAt: moment(tripPlan.backAt).format('MM.DD'),
                deptCity: tripPlan.deptCity,
            };
            try {
                yield API.tripApprove.sendApprovePassNoticeToCompany({ approveId: approve.id });
            }
            catch (err) {
                console.error(err);
            }
            let tplName = 'qm_notify_approve_pass';
            try {
                yield API.notify.submitNotify({ accountId: account.id, key: tplName, values: self_values });
            }
            catch (err) {
                console.error(err);
            }
            try {
                yield API.ddtalk.sendLinkMsg({ accountId: account.id, text: '您的预算已审批完成', url: self_url });
            }
            catch (err) {
                console.error(err);
            }
            return tripPlan;
        });
    }
    static tripPlanSaveRank(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let staff = yield staff_1.Staff.getCurrent();
            let companyId = staff.company.id;
            let limit = params.limit || 10;
            if (!limit || !/^\d+$/.test(limit) || limit > 100) {
                limit = 10;
            }
            let sql = `select account_id, sum(budget) - sum(expenditure) as save from trip_plan.trip_plans 
        where deleted_at is null and status = ${tripPlan_1.EPlanStatus.COMPLETE} AND company_id = '${companyId}' and is_special_approve = false `;
            if (params.staffId)
                sql += ` and account_id = '${params.staffId}'`;
            if (params.startTime)
                sql += ` and start_at > '${params.startTime}'`;
            if (params.endTime)
                sql += ` and start_at < '${params.endTime}'`;
            sql += ` group by account_id order by save desc limit ${limit};`;
            let ranks = yield sequelize.query(sql)
                .then(function (result) {
                return result[0];
            });
            ranks = yield Promise.all(ranks.map((v) => {
                return _types_1.Models.staff.get(v.account_id)
                    .then(function (staff) {
                    return { staff: staff, save: v.save };
                });
            }));
            return ranks;
        });
    }
    static getTripPlanSave(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let staff = yield _types_1.Models.staff.get(params.accountId);
            let accountId = params.accountId;
            let companyId = staff.company.id;
            let sql = `select sum(budget) - sum(expenditure) as save from trip_plan.trip_plans where deleted_at is null and status = ${tripPlan_1.EPlanStatus.COMPLETE} AND company_id = '${companyId}' AND account_id =  '${accountId}' `;
            let ranks = yield sequelize.query(sql)
                .then(function (result) {
                return result[0];
            });
            return ranks[0].save;
        });
    }
    static makeFinalBudget(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let accountId = model_1.getSession()["accountId"];
            let tripPlanId = params.tripPlanId;
            if (!accountId) {
                throw language_1.default.ERR.PERMISSION_DENY();
            }
            if (!tripPlanId) {
                throw language_1.default.ERR.PERMISSION_DENY();
            }
            let tripPlan = yield _types_1.Models.tripPlan.get(tripPlanId);
            if (tripPlan.auditUser != accountId) {
                throw language_1.default.ERR.PERMISSION_DENY();
            }
            //取出查询参数,重新计算预算
            let isRoundTrip = true;
            let query = tripPlan.query;
            if (!query) {
                let { deptCityCode, arrivalCityCode, startAt, backAt, isNeedTraffic, isNeedHotel } = tripPlan;
                query = {
                    originPlace: deptCityCode,
                    destinationPlace: arrivalCityCode,
                    leaveDate: moment(startAt['value']).format("YYYY-MM-DD"),
                    goBackDate: moment(backAt['value']).format("YYYY-MM-DD"),
                    isNeedTraffic: isNeedTraffic,
                    isNeedHotel: isNeedHotel,
                    isRoundTrip: isRoundTrip
                };
            }
            if (typeof query == 'string') {
                query = JSON.parse(query);
            }
            let budgetId = yield API.client.travelBudget.getTravelPolicyBudget(query);
            let budgetResult = yield API.client.travelBudget.getBudgetInfo({ id: budgetId });
            let budgets = budgetResult.budgets;
            //计算总预算
            let totalBudget = 0;
            budgets.forEach((item) => {
                if (Number(item.price) <= 0) {
                    totalBudget = -1;
                    return;
                }
                totalBudget += Number(item.price);
            });
            tripPlan.originalBudget = tripPlan.budget;
            tripPlan.budget = totalBudget;
            tripPlan.isFinalBudget = true;
            tripPlan.finalBudgetCreateAt = budgetResult.createAt;
            yield tripPlan.save();
            return true;
        });
    }
    static makeSpendReport(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var money2hanzi = require("money2hanzi");
            let staff = yield staff_1.Staff.getCurrent();
            let { tripPlanId } = params;
            let tripPlan = yield _types_1.Models.tripPlan.get(tripPlanId);
            if (tripPlan.account.id != staff.id) {
                throw language_1.default.ERR.PERMISSION_DENY();
            }
            if (!tripPlan || tripPlan.status != tripPlan_1.EPlanStatus.COMPLETE) {
                throw language_1.default.ERR.TRIP_PLAN_STATUS_ERR();
            }
            if (!staff.email) {
                throw language_1.default.ERR.EMAIL_EMPTY();
            }
            let title = moment(tripPlan.startAt).format('MM.DD') + '-' + moment(tripPlan.backAt).format("MM.DD") + tripPlan.deptCity + "到" + tripPlan.arrivalCity + '报销单';
            let tripDetails = yield _types_1.Models.tripDetail.find({
                where: { tripPlanId: tripPlanId },
                order: [["created_at", "asc"]]
            });
            // let tripDetails = await tripPlan.getTripDetails({where: {}, order: [["created_at", "asc"]]});
            let tripApprove = yield _types_1.Models.tripApprove.get(tripPlanId);
            let approveUsers = (tripApprove && tripApprove.approvedUsers ? tripApprove.approvedUsers : '').split(/,/g)
                .filter((v) => {
                return !!v;
            }).map((userId) => tslib_1.__awaiter(this, void 0, void 0, function* () {
                if (userId) {
                    let staff = yield _types_1.Models.staff.get(userId);
                    return staff.name;
                }
                return '';
            }));
            approveUsers = yield Promise.all(approveUsers);
            let _tripDetails = tripDetails.map((v) => tslib_1.__awaiter(this, void 0, void 0, function* () {
                let tripDetailInvoices = yield _types_1.Models.tripDetailInvoice.find({ where: { tripDetailId: v.id, payType: { $ne: tripPlan_1.EPayType.COMPANY_PAY } } });
                if (v.type == tripPlan_1.ETripType.OUT_TRIP || v.type == tripPlan_1.ETripType.BACK_TRIP) {
                    let v1 = v;
                    let trafficType;
                    let trafficInfo;
                    let type;
                    type = '交通';
                    trafficType = v1.type == tripPlan_1.ETripType.OUT_TRIP ? 'GO' : 'BACK';
                    trafficInfo = v1.invoiceType == tripPlan_1.EInvoiceType.TRAIN ? '火车' : '飞机';
                    trafficInfo += v1.invoiceType == tripPlan_1.EInvoiceType.PLANE ? travelPolicy_1.MPlaneLevel[v1.cabin] : travelPolicy_1.MTrainLevel[v1.cabin];
                    let deptCity = yield API.place.getCityInfo({ cityCode: v1.deptCity });
                    let arrivalCity = yield API.place.getCityInfo({ cityCode: v1.arrivalCity });
                    return {
                        type: type,
                        date: moment(v1.deptDateTime).format('YYYY.MM.DD'),
                        invoiceInfo: `${type}费`,
                        quantity: tripDetailInvoices.length,
                        money: v1.personalExpenditure,
                        departCity: deptCity.name,
                        arrivalCity: arrivalCity.name,
                        remark: `${deptCity.name}-${arrivalCity.name}`,
                        trafficType: `${trafficType}`,
                        trafficInfo: `${trafficInfo}`
                    };
                }
                if (v.type == tripPlan_1.ETripType.HOTEL) {
                    let v1 = v;
                    let city = yield API.place.getCityInfo({ cityCode: v1.city });
                    return {
                        "type": "住宿",
                        "date": moment(v1.checkInDate).format('YYYY.MM.DD'),
                        "invoiceInfo": "住宿费",
                        "quantity": tripDetailInvoices.length,
                        "money": v1.personalExpenditure,
                        "remark": `${moment(v1.checkInDate).format('YYYY.MM.DD')}-${moment(v1.checkOutDate).format('YYYY.MM.DD')} ${city.name} 共${moment(v1.checkOutDate).diff(v1.checkInDate, 'days')}日`,
                        "duration": `${moment(v1.checkOutDate).diff(v1.checkInDate, 'days')}`
                    };
                }
                if (v.type == tripPlan_1.ETripType.SUBSIDY) {
                    let v1 = v;
                    return {
                        "type": '补助',
                        "date": moment(v1.startDateTime).format('YYYY.MM.DD'),
                        "invoiceInfo": "补助费",
                        quantity: 0,
                        money: v1.personalExpenditure,
                        remark: '补助费'
                    };
                }
                if (v.type == tripPlan_1.ETripType.SPECIAL_APPROVE) {
                    let v1 = v;
                    return {
                        "type": '出差费用',
                        "date": moment(v1.deptDateTime).format('YYYY.MM.DD'),
                        "invoiceInfo": "出差费",
                        quantity: tripDetailInvoices.length,
                        money: v1.personalExpenditure,
                        remark: '特别审批出差费用'
                    };
                }
            }));
            let financeCheckCode = _types_1.Models.financeCheckCode.create({ tripPlanId: tripPlanId, isValid: true });
            financeCheckCode = yield financeCheckCode.save();
            let roundLine = `${tripPlan.deptCity}-${tripPlan.arrivalCity}${tripPlan.isRoundTrip ? '-' + tripPlan.deptCity : ''}`;
            _tripDetails = yield Promise.all(_tripDetails);
            _tripDetails = _tripDetails.filter((v) => {
                return v['money'] > 0;
            });
            var invoiceQuantity = _tripDetails
                .map((v) => {
                return v['quantity'] || 0;
            })
                .reduce(function (previousValue, currentValue) {
                return previousValue + currentValue;
            });
            //计算用户总花费
            let _personalExpenditure = _tripDetails
                .map((v) => {
                return v['money'];
            })
                .reduce((prev, cur) => {
                return Number(prev) + Number(cur);
            });
            let content = [
                `出差人:${staff.name}`,
                `出差日期:${moment(tripPlan.startAt).format('YYYY.MM.DD')}-${moment(tripPlan.backAt).format('YYYY.MM.DD')}`,
                `出差路线: ${roundLine}`,
                `出差预算:${tripPlan.budget}`,
                `实际支出:${_personalExpenditure}个人支付, ${(Number(tripPlan.expenditure) - _personalExpenditure).toFixed(2)}公司支付`,
                `出差记录编号:${tripPlan.planNo}`,
                `校验地址: ${config.host}#/finance/trip-detail?id=${tripPlan.id}&code=${financeCheckCode.code}`
            ];
            let qrcodeCxt = yield API.qrcode.makeQrcode({ content: content.join('\n\r') });
            let departmentsStr = yield staff.getDepartmentsStr();
            var data = {
                "submitter": staff.name,
                "department": departmentsStr,
                "budgetMoney": tripPlan.budget || 0,
                "totalMoney": _personalExpenditure || 0,
                "totalMoneyHZ": money2hanzi.toHanzi(_personalExpenditure),
                "invoiceQuantity": invoiceQuantity,
                "createAt": moment().format('YYYY年MM月DD日HH:mm'),
                "departDate": moment(tripPlan.startAt).format('YYYY.MM.DD'),
                "backDate": moment(tripPlan.backAt).format('YYYY.MM.DD'),
                "reason": tripPlan.project.name,
                "approveUsers": approveUsers,
                "qrcode": `data:image/png;base64,${qrcodeCxt}`,
                "invoices": _tripDetails,
                "roundLine": roundLine,
            };
            let buf = yield spendReport_1.makeSpendReport(data);
            try {
                yield API.notify.submitNotify({
                    key: 'qm_spend_report',
                    accountId: staff.id,
                    values: {
                        title: title,
                        attachments: [{
                                filename: title + '.pdf',
                                content: buf.toString("base64"),
                                encoding: 'base64'
                            }]
                    },
                });
            }
            catch (err) {
                console.error(err.stack);
            }
            return true;
        });
    }
    static getTripDetailInvoices(options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!options || !options.where)
                throw new Error('查询条件不能为空');
            let where = options.where;
            if (!where.tripDetailId)
                throw new Error('查询条件错误');
            let qs = {
                where: { tripDetailId: options.where.tripDetailId },
            };
            if (options.limit)
                qs.limit = options.limit;
            if (options.order) {
                qs.order = options.order;
            }
            else {
                qs.order = [['created_at', 'asc']];
            }
            let invoices = yield _types_1.Models.tripDetailInvoice.find(qs);
            let ids = invoices.map((v) => {
                return v.id;
            });
            return { ids: ids, count: invoices.length };
        });
    }
    static getTripDetailInvoice(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            return _types_1.Models.tripDetailInvoice.get(params.id);
        });
    }
    static saveTripDetailInvoice(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let tripDetailInvoice = _types_1.Models.tripDetailInvoice.create(params);
            tripDetailInvoice = yield tripDetailInvoice.save();
            let tripDetail = yield _types_1.Models.tripDetail.get(tripDetailInvoice.tripDetailId);
            if (!tripDetail.expenditure) {
                tripDetail.expenditure = 0;
            }
            yield updateTripDetailExpenditure(tripDetail);
            yield tryUpdateTripDetailStatus(tripDetail, tripPlan_1.EPlanStatus.WAIT_COMMIT);
            return tripDetailInvoice;
        });
    }
    static notifyDesignatedAcount() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let staff = yield staff_1.Staff.getCurrent();
            let companyName = staff.company.name;
            let staffName = staff.name;
            try {
                yield API.notify.notifyDesignatedAccount({
                    mobile: "13810529805",
                    email: "notice@jingli365.com",
                    key: "qm_notify_invoice_audit_request",
                    values: {
                        company: companyName,
                        staffName: staff.name
                    }
                });
            }
            catch (err) {
                logger.info(err);
            }
        });
    }
    static relateOrders(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let result = { success: [], failed: [] };
            let currentStaff = yield staff_1.Staff.getCurrent();
            let orders = yield currentStaff.getOrders({ supplierId: params.supplierId });
            let Morders = {};
            orders.forEach(function (o) {
                return tslib_1.__awaiter(this, void 0, void 0, function* () {
                    Morders[o.id] = o;
                });
            });
            let orderIds = params.orderIds;
            let ps = orderIds.map(function (id) {
                return tslib_1.__awaiter(this, void 0, void 0, function* () {
                    let o = Morders[id];
                    let detailInvoice = yield _types_1.Models.tripDetailInvoice.find({ where: { orderId: id, accountId: currentStaff.id, sourceType: tripPlan_1.ESourceType.RELATE_ORDER } });
                    if (detailInvoice && detailInvoice.length > 0) {
                        result.failed.push({ desc: o.desc, remark: '该订单已被关联过' });
                        return o.id;
                        // throw L.ERR.ORDER_HAS_RELATED();
                    }
                    if (o.persons.indexOf(currentStaff.name) < 0) {
                        result.failed.push({ desc: o.desc, remark: '只能关联自己的订单' });
                        return o.id;
                        // throw L.ERR.ORDER_NOT_YOURS();
                    }
                    let invoice = {};
                    invoice.accountId = currentStaff.id;
                    invoice.orderId = o.id;
                    invoice.sourceType = tripPlan_1.ESourceType.RELATE_ORDER;
                    invoice.tripDetailId = params.detailId;
                    invoice.invoiceDateTime = o.date;
                    invoice.totalMoney = o.price;
                    invoice.payType = o.parType;
                    invoice.remark = o.desc;
                    invoice.type = o.orderType;
                    invoice.status = tripPlan_1.EInvoiceStatus.AUDIT_PASS;
                    invoice.supplierId = params.supplierId;
                    let iv = yield TripPlanModule.saveTripDetailInvoice(invoice);
                    result.success.push({ desc: o.desc, remark: '关联成功' });
                    return o.id;
                });
            });
            yield Promise.all(ps);
            return result;
        });
    }
    static updateTripDetailInvoice(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let { id, totalMoney } = params;
            let oldMoney = 0;
            let newMoney = 0;
            if (totalMoney) {
                newMoney = Number(totalMoney);
            }
            if (newMoney < 0) {
                throw language_1.default.ERR.MONEY_FORMAT_ERROR();
            }
            let tripDetailInvoice = yield _types_1.Models.tripDetailInvoice.get(id);
            if (tripDetailInvoice.totalMoney) {
                oldMoney = tripDetailInvoice.totalMoney;
            }
            for (let key in params) {
                tripDetailInvoice[key] = params[key];
            }
            tripDetailInvoice = yield tripDetailInvoice.save();
            let tripDetail = yield _types_1.Models.tripDetail.get(tripDetailInvoice.tripDetailId);
            yield updateTripDetailExpenditure(tripDetail);
            yield tryUpdateTripDetailStatus(tripDetail, tripPlan_1.EPlanStatus.WAIT_COMMIT);
            return tripDetailInvoice;
        });
    }
    static deleteTripDetailInvoice(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let { id } = params;
            let tripDetailInvoice = yield _types_1.Models.tripDetailInvoice.get(id);
            let tripDetailId = tripDetailInvoice.tripDetailId;
            yield tripDetailInvoice.destroy();
            let tripDetail = yield _types_1.Models.tripDetail.get(tripDetailId);
            yield updateTripDetailExpenditure(tripDetail);
            let invoices = yield tripDetail.getInvoices();
            if (invoices && invoices.length) {
                yield tryUpdateTripDetailStatus(tripDetail, tripPlan_1.EPlanStatus.WAIT_COMMIT);
            }
            else {
                yield tryUpdateTripDetailStatus(tripDetail, tripPlan_1.EPlanStatus.WAIT_UPLOAD);
            }
            return true;
        });
    }
    static _scheduleTask() {
        let taskId = "authApproveTrainPlan";
        logger.info('run task ' + taskId);
        scheduler('*/5 * * * *', taskId, function () {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let tripApproves = yield _types_1.Models.tripApprove.find({ where: { autoApproveTime: { $lte: new Date() }, status: tripPlan_1.QMEApproveStatus.WAIT_APPROVE }, limit: 10, order: 'auto_approve_time' });
                tripApproves.map((approve) => tslib_1.__awaiter(this, void 0, void 0, function* () {
                    let approveCompany = yield approve.getCompany();
                    let number = 0;
                    if (approve.isSpecialApprove) {
                        number = number + 1;
                    }
                    if (approve.isNeedHotel) {
                        number = number + 1;
                    }
                    if (approve.isNeedTraffic) {
                        number = number + 1;
                    }
                    if (approve.isRoundTrip) {
                        number = number + 1;
                    }
                    yield approveCompany.beforeApproveTrip({ number: number });
                    approve.status = tripPlan_1.QMEApproveStatus.PASS;
                    approve = yield approve.save();
                    let content = approve.deptCity + "-" + approve.arrivalCity;
                    let frozenNum = JSON.parse(approve.query).frozenNum;
                    if (approve.createdAt.getMonth() == new Date().getMonth() && !approve.isSpecialApprove) {
                        yield approveCompany.approvePassReduceTripPlanNum({ accountId: approve.account.id, tripPlanId: approve.id,
                            remark: "自动审批通过消耗行程点数", content: content, isShowToUser: false, frozenNum: frozenNum });
                    }
                    else {
                        yield approveCompany.approvePassReduceBeforeNum({ accountId: approve.account.id, tripPlanId: approve.id,
                            remark: "自动审批通过上月申请消耗行程点数", content: content, isShowToUser: false, frozenNum: frozenNum });
                    }
                    if (approve.approveUser && approve.approveUser.id && /^\w{8}-\w{4}-\w{4}-\w{4}-\w{12}$/.test(approve.approveUser.id)) {
                        let log = _types_1.Models.tripPlanLog.create({ tripPlanId: approve.id, userId: approve.approveUser.id, approveStatus: tripPlan_1.EApproveResult.AUTO_APPROVE, remark: '自动通过' });
                        yield log.save();
                    }
                    yield TripPlanModule.saveTripPlanByApprove({ tripApproveId: approve.id });
                }));
            });
        });
    }
    static getProjectByName(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let projects = yield _types_1.Models.project.find({ where: { name: params.name } });
            if (projects && projects.length > 0) {
                let project = projects[0];
                project.weight += 1;
                yield project.save();
                return project;
            }
            else if (params.isCreate === true) {
                let p = { name: params.name, createUser: params.userId, code: '', companyId: params.companyId };
                return _types_1.Models.project.create(p).save();
            }
        });
    }
}
TripPlanModule.__initHttpApp = require('./invoice');
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id']),
    _decorator_1.modelNotNull('tripPlan'),
    _decorator_1.conditionDecorator([{ if: _decorator_1.condition.canGetTripPlan('0.id') }])
], TripPlanModule, "getTripPlan", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id'], ['isNeedTraffic', 'isNeedHotel', 'title', 'description', 'status', 'deptCity',
        'deptCityCode', 'arrivalCity', 'arrivalCityCode', 'startAt', 'backAt', 'remark']),
    _decorator_1.modelNotNull('tripPlan'),
    _decorator_1.conditionDecorator([{ if: _decorator_1.condition.isMyTripPlan('0.id') }])
], TripPlanModule, "updateTripPlan", null);
tslib_1.__decorate([
    helper_1.clientExport
], TripPlanModule, "listTripPlans", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id']),
    _decorator_1.modelNotNull('tripPlan'),
    _decorator_1.conditionDecorator([{ if: _decorator_1.condition.isMyTripPlan('0.id') }])
], TripPlanModule, "deleteTripPlan", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['tripPlanId', 'type', 'startTime', 'invoiceType', 'budget'])
], TripPlanModule, "saveTripDetail", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id']),
    _decorator_1.modelNotNull('tripDetail')
], TripPlanModule, "getTripDetail", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id'])
], TripPlanModule, "getOddBudget", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id'])
], TripPlanModule, "getTripDetailTraffic", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"])
], TripPlanModule, "getTripDetailHotel", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"])
], TripPlanModule, "getTripDetailSubsidy", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"])
], TripPlanModule, "getTripDetailSpecial", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id'], tripPlan_1.TripDetail['$fieldnames']),
    _decorator_1.modelNotNull('tripDetail')
], TripPlanModule, "updateTripDetail", null);
tslib_1.__decorate([
    helper_1.requireParams(['where.tripPlanId'], ['where.type', 'where.status', 'where.id']),
    helper_1.clientExport
], TripPlanModule, "getTripDetails", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id']),
    _decorator_1.modelNotNull('tripDetail')
], TripPlanModule, "deleteTripDetail", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id']),
    _decorator_1.modelNotNull('tripPlan'),
    _decorator_1.conditionDecorator([{ if: _decorator_1.condition.isMyTripPlan('0.id') }])
], TripPlanModule, "commitTripPlan", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id', 'auditResult'], ["reason", "expenditure"]),
    _decorator_1.modelNotNull('tripDetail')
], TripPlanModule, "auditPlanInvoice", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['name', 'createUser', 'company_id'], ['code'])
], TripPlanModule, "createProject", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id']),
    _decorator_1.modelNotNull('project')
], TripPlanModule, "getProjectById", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['where.companyId'], ['where.name'])
], TripPlanModule, "getProjectList", null);
tslib_1.__decorate([
    helper_1.requireParams(['id']),
    _decorator_1.modelNotNull('project')
], TripPlanModule, "deleteProject", null);
tslib_1.__decorate([
    helper_1.requireParams(['tripPlanId', 'remark'], ['tripDetailId'])
], TripPlanModule, "saveTripPlanLog", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id']),
    _decorator_1.modelNotNull('tripPlanLog')
], TripPlanModule, "getTripPlanLog", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['where.tripPlanId'], ['where.tripDetailId'])
], TripPlanModule, "getTripPlanLogs", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id'], ['remark'])
], TripPlanModule, "cancelTripPlan", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['companyId', 'month'])
], TripPlanModule, "statisticTripPlanOfMonth", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams([], ['startTime', 'endTime', 'isStaff'])
], TripPlanModule, "statisticTripBudget", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['startTime', 'endTime', 'type'], ['keyWord'])
], TripPlanModule, "statisticBudgetsInfo", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['tripApproveId'])
], TripPlanModule, "saveTripPlanByApprove", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams([], ['limit', 'staffId', 'startTime', 'endTime'])
], TripPlanModule, "tripPlanSaveRank", null);
tslib_1.__decorate([
    helper_1.clientExport
], TripPlanModule, "getTripPlanSave", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["tripPlanId"])
], TripPlanModule, "makeFinalBudget", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["tripPlanId"])
], TripPlanModule, "makeSpendReport", null);
tslib_1.__decorate([
    helper_1.clientExport
], TripPlanModule, "getTripDetailInvoices", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id'])
], TripPlanModule, "getTripDetailInvoice", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['tripDetailId', 'totalMoney', 'payType', 'invoiceDateTime', 'type', 'remark'], ['id', 'pictureFileId', 'accountId', 'orderId', 'sourceType', 'status', 'supplierId'])
], TripPlanModule, "saveTripDetailInvoice", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['detailId', 'orderIds', 'supplierId'])
], TripPlanModule, "relateOrders", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"], ['totalMoney', 'payType', 'invoiceDateTime', 'type', 'remark', 'pictureFileId'])
], TripPlanModule, "updateTripDetailInvoice", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id'])
], TripPlanModule, "deleteTripDetailInvoice", null);
function updateTripDetailExpenditure(tripDetail) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        //重新计算所有花费
        let invoices = yield _types_1.Models.tripDetailInvoice.find({ where: { tripDetailId: tripDetail.id } });
        let expenditure = 0;
        let personalExpenditure = 0;
        invoices.forEach((v) => {
            expenditure += Number(v.totalMoney);
            if (v.payType == tripPlan_1.EPayType.PERSONAL_PAY) {
                personalExpenditure += Number(v.totalMoney);
            }
        });
        tripDetail.personalExpenditure = personalExpenditure;
        tripDetail.expenditure = expenditure;
        tripDetail = yield tripDetail.save();
        let tripPlan = yield _types_1.Models.tripPlan.get(tripDetail.tripPlanId);
        yield updateTripPlanExpenditure(tripPlan);
        return tripDetail;
    });
}
function updateTripPlanExpenditure(tripPlan) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        let tripDetails = yield _types_1.Models.tripDetail.find({ where: { tripPlanId: tripPlan.id } });
        let expenditure = 0;
        let personalExpenditure = 0;
        tripDetails.forEach((v) => {
            expenditure += Number(v.expenditure);
            personalExpenditure += Number(v.personalExpenditure);
        });
        tripPlan.expenditure = expenditure;
        tripPlan.personalExpenditure = personalExpenditure;
        return tripPlan.save();
    });
}
//尝试修改tripDetail状态
function tryUpdateTripDetailStatus(tripDetail, status) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        if ([tripPlan_1.ETripType.SUBSIDY].indexOf(tripDetail.type) >= 0) {
            tripDetail.status = status;
        }
        else {
            switch (status) {
                case tripPlan_1.EPlanStatus.WAIT_UPLOAD:
                    tripDetail.status = status;
                    break;
                case tripPlan_1.EPlanStatus.WAIT_COMMIT:
                    //如果票据不为空,则设置状态为可提交状态
                    let invoices = yield _types_1.Models.tripDetailInvoice.find({ where: { tripDetailId: tripDetail.id } });
                    if (invoices && invoices.length) {
                        tripDetail.status = tripPlan_1.EPlanStatus.WAIT_COMMIT;
                    }
                    break;
                case tripPlan_1.EPlanStatus.AUDITING:
                    if ([tripPlan_1.EPlanStatus.AUDIT_NOT_PASS, tripPlan_1.EPlanStatus.WAIT_COMMIT].indexOf(tripDetail.status) >= 0) {
                        tripDetail.status = status;
                    }
                    break;
                case tripPlan_1.EPlanStatus.COMPLETE:
                    if (tripPlan_1.EPlanStatus.AUDITING == tripDetail.status) {
                        tripDetail.status = status;
                    }
                    break;
            }
        }
        //更改行程详情状态
        tripDetail = yield tripDetail.save();
        //尝试更改行程状态
        let tripPlan = yield _types_1.Models.tripPlan.get(tripDetail.tripPlanId);
        yield tryUpdateTripPlanStatus(tripPlan, status);
        return tripDetail;
    });
}
//尝试修改tripPlan状态
function tryUpdateTripPlanStatus(tripPlan, status) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        let cannotStatus = {};
        //变tripPlan状态需要tripDetail不能包含状态
        cannotStatus[tripPlan_1.EPlanStatus.WAIT_UPLOAD] = [];
        cannotStatus[tripPlan_1.EPlanStatus.WAIT_COMMIT] = _.concat([tripPlan_1.EPlanStatus.WAIT_UPLOAD], cannotStatus[tripPlan_1.EPlanStatus.WAIT_UPLOAD]);
        cannotStatus[tripPlan_1.EPlanStatus.AUDITING] = _.concat([tripPlan_1.EPlanStatus.AUDIT_NOT_PASS, tripPlan_1.EPlanStatus.WAIT_COMMIT], cannotStatus[tripPlan_1.EPlanStatus.WAIT_COMMIT]);
        cannotStatus[tripPlan_1.EPlanStatus.COMPLETE] = _.concat([tripPlan_1.EPlanStatus.AUDITING], cannotStatus[tripPlan_1.EPlanStatus.AUDITING]);
        //变tripPlan状态,只关注出发交通,返回交通,住宿,特殊审批类型
        let preTripTypeNeeds = [tripPlan_1.ETripType.BACK_TRIP, tripPlan_1.ETripType.OUT_TRIP, tripPlan_1.ETripType.HOTEL, tripPlan_1.ETripType.SPECIAL_APPROVE];
        //更新行程状态
        let tripDetails = yield _types_1.Models.tripDetail.find({
            where: {
                tripPlanId: tripPlan.id,
                type: { $in: preTripTypeNeeds },
                status: { $in: cannotStatus[status] },
            },
            order: [['created_at', 'asc']]
        });
        if (!tripDetails || !tripDetails.length) {
            tripPlan.status = status;
            yield tripPlan.save();
        }
        return tripPlan;
    });
}
function tryObjId(obj) {
    if (obj && obj.id)
        return obj.id;
    return null;
}
TripPlanModule._scheduleTask();
module.exports = TripPlanModule;

//# sourceMappingURL=index.js.map
