/**
 * Created by by wyl on 15-12-16.
 */
'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const index_1 = require("_types/index");
const staff_1 = require("_types/staff");
const auth_cert_1 = require("_types/auth/auth-cert");
var API = require("common/api");
let Logger = require('common/logger');
let logger = new Logger("tripPlan.invoice");
module.exports = function (app) {
    //app.get('/consume/invoice/:consumeId', agentGetTripplanInvoice);
    app.get('/trip-detail/:id/invoice/:fileId', agentGetTripplanDetailInvoice);
};
function checkInvoicePermission(userId, tripDetailId) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        var tripDetail = yield index_1.Models.tripDetail.get(tripDetailId);
        var tripPlan = yield index_1.Models.tripPlan.get(tripDetail.tripPlanId);
        var account = yield index_1.Models.account.get(userId);
        if (account.type == index_1.EAccountType.STAFF) {
            var staff = yield index_1.Models.staff.get(userId);
            if (!staff)
                return false;
            if (staff.id == tripPlan.account.id)
                return true;
            if (staff.company.id == tripPlan.account.company.id &&
                (staff.roleId == staff_1.EStaffRole.ADMIN || staff.roleId == staff_1.EStaffRole.OWNER))
                return true;
        }
        else if (account.type == index_1.EAccountType.AGENCY) {
            var agencyUser = yield index_1.Models.agencyUser.get(userId);
            if (!agencyUser)
                return false;
            var needAgency = yield tripPlan.account.company.getAgency();
            if (agencyUser.agency.id == needAgency.id)
                return true;
        }
        return false;
    });
}
function agentGetTripplanDetailInvoice(req, res, next) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        try {
            req.clearTimeout();
            var authReq = auth_cert_1.parseAuthString(req.query.authstr);
            var result = yield API.auth.authentication(authReq);
            if (!result) {
                console.log('auth failed', JSON.stringify(req.cookies));
                res.sendStatus(403);
                return;
            }
            var tripDetailId = req.params.id;
            var fileId = req.params.fileId;
            var tripDetail = yield index_1.Models.tripDetail.get(tripDetailId);
            var invoices = yield index_1.Models.tripDetailInvoice.find({ where: { tripDetailId: tripDetail.id } });
            let pictures = invoices.map((invoice) => {
                return invoice.pictureFileId;
            });
            if (pictures.indexOf(fileId) < 0) {
                res.sendStatus(404);
                return;
            }
            if (!checkInvoicePermission(result.accountId, tripDetailId)) {
                res.sendStatus(403);
                return;
            }
            var cacheFile = yield API.attachment.getFileCache({ id: fileId, isPublic: false });
            if (!cacheFile) {
                return res.sendStatus(404);
            }
            res.set("Content-Type", cacheFile.type);
            return res.sendFile(cacheFile.file);
        }
        catch (e) {
            logger.error(e.stack || e);
            res.sendStatus(500);
        }
    });
}

//# sourceMappingURL=invoice.js.map
