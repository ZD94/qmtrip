/**
 * Created by yumiao on 15-12-11.
 */
"use strict";
const tslib_1 = require("tslib");
let moment = require("moment");
let DBM = require("common/model").DB.models;
let Logger = require('common/logger');
let logger = new Logger("seeds");
let typeString = ['TripPlanNo', 'AgencyNo', 'CompanyNo', 'CoinAccountNo'];
class SeedModule {
    /**
     * 获取团队信息
     * @param params
     * @param params.type goods_no:商品编号 goods_order_no:实物商品订单编号
     * @param cb
     */
    static getSingleSeedCode(type, options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!options) {
                options = {};
            }
            let minNo = options.minNo;
            let maxNo = options.maxNo;
            if (!minNo) {
                minNo = 1000;
            }
            if (!maxNo) {
                maxNo = 9999;
            }
            if (typeString.indexOf(type) < 0) {
                throw { code: -1, msg: '编号类型不在配置中' };
            }
            let seeds = yield DBM.Seed.findOne({ where: { type: type } });
            if (!seeds) {
                let en = yield DBM.Seed.create({ type: type, minNo: minNo, maxNo: maxNo, nowNo: minNo });
                return en.nowNo;
            }
            let nowNo = 0;
            if (parseInt(seeds.nowNo) >= maxNo) {
                nowNo = minNo;
            }
            else {
                nowNo = parseInt(seeds.nowNo) + 1;
            }
            let [affect, rows] = yield DBM.Seed.update({ nowNo: nowNo }, { returning: true, where: { type: type } });
            return rows[0].nowNo;
        });
    }
    static getSeedNo(type, options) {
        if (!options) {
            options = {};
        }
        let formatDate = options.formatDate || "YYMMDDHHmmss";
        return SeedModule.getSingleSeedCode(type, options)
            .then(function (seeds) {
            let now = moment().format(formatDate);
            return now + seeds;
        });
    }
}
module.exports = SeedModule;

//# sourceMappingURL=index.js.map
