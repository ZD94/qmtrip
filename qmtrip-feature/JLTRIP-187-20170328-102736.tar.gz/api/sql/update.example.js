"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
function update(DB, t) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        //await DB.query(sql, {transaction: t});
    });
}
exports.default = update;

//# sourceMappingURL=update.example.js.map
