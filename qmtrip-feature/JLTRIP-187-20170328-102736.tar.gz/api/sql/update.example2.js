'use strict';

//DB: Sequelize object
//t: Sequelize transaction
//use DB.query(sql, {transaction: t}) for SQL.
module.exports = function(DB, t){
    return Promise.resolve();
}
