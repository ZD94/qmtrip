--schema=public

create schema IF NOT EXISTS agency;
create schema IF NOT EXISTS auth;
create schema IF NOT EXISTS company;
create schema IF NOT EXISTS department;
create schema IF NOT EXISTS staff;
create schema IF NOT EXISTS travel_policy;
create schema IF NOT EXISTS accord_hotel;
create schema IF NOT EXISTS trip_plan;

