/**
 * Created by wlh on 15/12/12.
 */
"use strict";
const tslib_1 = require("tslib");
var API = require("common/api");
const place_1 = require("_types/place");
class ApiPlace {
    /**
     * @method queryPlace
     *
     * 获取匹配城市名称
     *
     * @param {String} keyword 如北京
     * @returns {Promise} [{"id": "BJSA-sky", name: "北京"}, ...]
     * @exapme
     * ```
     * API.place.queryPlace("北京", function(err, result) {
     *      if (err) {
     *          return alert(err);
     *      }
     *
     *      console.info(result);
     * });
     * ```
     */
    static queryPlace(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let _params = params;
            if (!_params) {
                _params = {};
            }
            let { keyword, isAbroad } = _params;
            let cities;
            if (!Boolean(keyword)) {
                cities = yield ApiPlace.hotCities({ limit: 20, isAbroad: isAbroad });
            }
            else {
                cities = yield API.place.queryCity(_params);
            }
            return cities;
        });
    }
    /**
     * @method queryBusinessDistrict
     *
     * 查询商圈信息
     *
     * @param {Object} params 参数
     * @param {String} params.keyword 关键字
     * @param {String} params.code 城市代码
     * @return {Promise} [{"id":"ID", "name": "Name"}, {"id":"ID2", "name": "NAME2"}]
     */
    static queryBusinessDistrict(params) {
        return API.place.queryBusinessDistrict(params)
            .then(function (places) {
            let arr = places.map(function (place) {
                return new place_1.Place(place);
            });
            return arr;
        });
    }
    /**
     * @method hotCities
     *
     * 热门城市
     *
     * @param {Object} params
     * @param {Number} params.limit
     * @return {Promise} [{id: "ID", name: "Name"}]
     */
    static hotCities(params) {
        return API.place.queryHotCity(params)
            .then(function (places) {
            let arr = places.map(function (place) {
                return new place_1.Place(place);
            });
            return arr;
        });
    }
    /**
     * @method hotBusinessDistricts
     *
     * 热门商圈
     *
     * @param {Object} params
     * @param {String} params.cityId 城市ID
     * @return {Promise} [{id:"ID", name:"Name"}]
     */
    static hotBusinessDistricts(params) {
        return API.place.hotBusinessDistricts(params)
            .then(function (places) {
            var arr = places.map(function (place) {
                return new place_1.Place(place);
            });
            return arr;
        });
    }
    /**
     * @method getCityInfo
     * 获取城市信息(名称)
     *
     * @param {string} params.cityCode 城市代码
     * @return {Promise} {id: id, name: name}
     */
    static getCityInfo(params) {
        if (!params.cityCode) {
            throw new Error("cityCode require but is " + params.cityCode);
        }
        return API.place.getCityInfo(params)
            .then(function (result) {
            if (!result) {
                return null;
            }
            return new place_1.Place(result);
        });
    }
    /**
     * @method  getAirPortsByCity
     * 根据城市代码获取机场信息
     * @param   {string}    params.cityCode 城市代码
     * @type {Promise} array
     */
    static getAirPortsByCity(params) {
        if (!params.cityCode) {
            throw new Error("cityCode require but is empty!");
        }
        return API.place.getAirPortsByCity(params)
            .then(function (airports) {
            let arr = airports.map(function (airport) {
                return new place_1.Airport(airport);
            });
            return arr;
        });
    }
    /**
     * @method getAirportById
     * 通过id获取机场信息
     * @param params
     */
    static getAirportById(params) {
        return API.place.getAirportById(params)
            .then(function (airport) {
            return new place_1.Airport(airport);
        });
    }
    /**
     * @method getAirportByCode
     * 通过天巡或胜意代码获取机场信息
     * @param params
     * @returns {*}
     */
    static getAirportByCode(params) {
        return API.place.getAirportBySkyCode(params)
            .then(function (airport) {
            return new place_1.Airport(airport);
        });
    }
    static getAirCompanyById(params) {
        return API.place.getAirCompanyById(params)
            .then(function (airCompany) {
            return new place_1.AirCompany(airCompany);
        });
    }
    /**
     * @method getAirCompanyByCode 获取航空公司
     * @param params
     */
    static getAirCompanyByCode(params) {
        return API.place.getAirCompanyByCode(params)
            .then(function (airCompany) {
            return new place_1.AirCompany(airCompany);
        });
    }
    /**
     * 获取全部城市信息
     * @param params
     * @returns {any}
     */
    static getAllCities(params) {
        if (!params || !params.type)
            params.type = 2;
        return API.place.getAllCities(params);
    }
    /**
     * 获取城市列表根据字符分组
     * @param params
     * @returns {any}
     */
    static queryCitiesGroupByLetter(params) {
        return API.place.queryCitiesGroupByLetter(params);
    }
}
ApiPlace.__public = true;
module.exports = ApiPlace;

//# sourceMappingURL=index.js.map
