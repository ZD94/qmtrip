/**
 * Created by wyl on 15-12-12.
 */
'use strict';
const tslib_1 = require("tslib");
const helper_1 = require("common/api/helper");
const _decorator_1 = require("../_decorator");
const staff_1 = require("_types/staff");
const accordHotel_1 = require("_types/accordHotel");
const _types_1 = require("_types");
const accordHotelCols = accordHotel_1.AccordHotel['$fieldnames'];
class AccordHotelModule {
    /**
     * 创建协议酒店
     * @param data
     * @returns {*}
     */
    static createAccordHotel(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let result = yield _types_1.Models.accordHotel.find({ where: { cityCode: params.cityCode, companyId: params.companyId } });
            if (result && result.length > 0) {
                throw { msg: "该城市协议酒店已设置" };
            }
            var accordHotel = accordHotel_1.AccordHotel.create(params);
            return accordHotel.save();
        });
    }
    /**
     * 删除协议酒店
     * @param params
     * @returns {*}
     */
    static deleteAccordHotel(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var id = params.id;
            var ah_delete = yield _types_1.Models.accordHotel.get(id);
            yield ah_delete.destroy();
            return true;
        });
    }
    /**
     * 更新协议酒店
     * @param id
     * @param data
     * @returns {*}
     */
    static updateAccordHotel(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var id = params.id;
            var ah = yield _types_1.Models.accordHotel.get(id);
            for (var key in params) {
                ah[key] = params[key];
            }
            return ah.save();
        });
    }
    /**
     * 根据id查询协议酒店
     * @param {String} params.id
     * @param {Boolean} params.isReturnDefault 如果不存在返回默认 default true,
     * @returns {*}
     */
    static getAccordHotel(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let id = params.id;
            var ah = yield _types_1.Models.accordHotel.get(id);
            return ah;
        });
    }
    ;
    /**
     * 根据cityCode查询协议酒店
     * @param obj  params.cityCode, params.companyId
     * @returns {*}
     */
    static getAccordHotelByCity(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let cityId = params.cityId;
            var staff = yield staff_1.Staff.getCurrent();
            var options = {
                where: { cityCode: cityId }
            };
            if (staff) {
                options.where.companyId = staff["companyId"]; //只允许查询该企业下的协议酒店
            }
            let paginate = yield _types_1.Models.accordHotel.find(options);
            if (paginate && paginate.length > 0) {
                return paginate[0];
            }
            else {
                throw { code: -1, msg: "没有符合要求的记录" };
            }
        });
    }
    ;
    /**
     * 根据属性查找协议酒店
     * @param params
     * @returns {*}
     */
    static getAccordHotels(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var staff = yield staff_1.Staff.getCurrent();
            params.order = params.order || [['createdAt', 'desc']];
            if (staff) {
                params.where.companyId = staff["companyId"]; //只允许查询该企业下的协议酒店
            }
            let paginate = yield _types_1.Models.accordHotel.find(params);
            let ids = paginate.map(function (t) {
                return t.id;
            });
            return { ids: ids, count: paginate['total'] };
        });
    }
}
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["accordPrice", "cityName", "cityCode", "companyId"], accordHotelCols),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isCompanyAdminOrOwner("0.companyId") },
        { if: _decorator_1.condition.isCompanyAgency("0.companyId") }
    ])
], AccordHotelModule, "createAccordHotel", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"], ["companyId"]),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isAccordHotelAdminOrOwner("0.id") },
        { if: _decorator_1.condition.isAccordHotelAgency("0.id") }
    ])
], AccordHotelModule, "deleteAccordHotel", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"], accordHotelCols),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isAccordHotelAdminOrOwner("0.id") },
        { if: _decorator_1.condition.isAccordHotelAgency("0.id") }
    ])
], AccordHotelModule, "updateAccordHotel", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"], ["companyId"]),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isAccordHotelAdminOrOwner("0.id") },
        { if: _decorator_1.condition.isAccordHotelAgency("0.id") }
    ])
], AccordHotelModule, "getAccordHotel", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["cityCode"])
], AccordHotelModule, "getAccordHotelByCity", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["where.companyId"], ['attributes', 'where.accordPrice', 'where.cityName', 'where.cityCode', 'where.createdAt']),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isCompanyAdminOrOwner("where.companyId") },
        { if: _decorator_1.condition.isCompanyAgency("where.companyId") }
    ])
], AccordHotelModule, "getAccordHotels", null);
module.exports = AccordHotelModule;

//# sourceMappingURL=index.js.map
