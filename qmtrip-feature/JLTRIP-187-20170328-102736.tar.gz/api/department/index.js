/**
 * Created by wyl on 16-01-20.
 */
'use strict';
const tslib_1 = require("tslib");
var _ = require("lodash");
var sequelize = require("common/model").DB;
let DBM = sequelize.models;
let API = require("common/api");
const language_1 = require("common/language");
const department_1 = require("_types/department");
const helper_1 = require("common/api/helper");
const index_1 = require("_types/index");
const staff_1 = require("_types/staff");
const _decorator_1 = require("../_decorator");
const departmentCols = department_1.Department['$fieldnames'];
const staffDepartmentCols = department_1.StaffDepartment['$fieldnames'];
class DepartmentModule {
    /**
     * 创建部门
     * @param data
     * @returns {*}
     */
    static createDepartment(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let result = yield index_1.Models.department.find({ where: { name: params.name, companyId: params.companyId } });
            if (result && result.length > 0) {
                throw { code: -1, msg: "该部门名称已存在，请重新设置" };
            }
            var staff = yield staff_1.Staff.getCurrent();
            var department = department_1.Department.create(params);
            if (staff) {
                var company = staff.company;
                department.company = company;
            }
            return department.save();
        });
    }
    /**
     * 删除部门
     * @param params
     * @returns {*}
     */
    static deleteDepartment(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var id = params.id;
            var department = yield index_1.Models.department.get(params.id);
            let staffs = yield department.getStaffs();
            if (staffs && staffs.length > 0) {
                throw { code: -1, msg: '该部门下有' + staffs.length + '位员工，暂不能删除' };
            }
            let childDepartments = yield department.getChildDepartments();
            if (childDepartments && childDepartments.length > 0) {
                throw { code: -2, msg: '该部门下有子级部门，暂不能删除' };
            }
            yield department.destroy();
            return true;
        });
    }
    /**
     * 更新部门
     * @param id
     * @param data
     * @returns {*}
     */
    static updateDepartment(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (params.parentId) {
                let ids = yield DepartmentModule.getAllChildDepartmentsId({ parentId: params.id });
                if (ids.indexOf(params.parentId) >= 0) {
                    throw language_1.default.ERR.INVALID_ARGUMENT("parentId");
                }
            }
            let dept = yield index_1.Models.department.get(params.id);
            if (params.name) {
                let result = yield index_1.Models.department.find({ where: { name: params.name, companyId: dept.company.id } });
                if (result && result.length > 0) {
                    throw { code: -1, msg: "该部门名称已存在，请重新设置" };
                }
            }
            for (let key in params) {
                dept[key] = params[key];
            }
            return dept.save();
        });
    }
    /**
     * 根据id查询部门
     * @param id
     * @param params
     * @returns {*}
     */
    static getDepartment(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let id = params.id;
            let dept = yield index_1.Models.department.get(id);
            return dept;
        });
    }
    ;
    /**
     * 根据属性查找部门id
     * @param params
     * @returns {*}
     */
    static getDepartments(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            params.order = params.order || [['createdAt', 'desc']];
            let paginate = yield index_1.Models.department.find(params);
            return { ids: paginate.map((s) => { return s.id; }), count: paginate['total'] };
        });
    }
    /**
     * 得到企业一级部门
     * @param params
     * @returns {*}
     */
    static getFirstClassDepartments(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var staff = yield staff_1.Staff.getCurrent();
            let options = {};
            params['parentId'] = null;
            options.where = params;
            options.order = [["created_at", "desc"]];
            if (staff) {
                options.where.companyId = staff["companyId"]; //只允许查询该企业下的部门
            }
            return index_1.Models.department.find(options);
        });
    }
    /**
     * 得到一级子级部门
     * @param params
     * @returns {*}
     */
    static getChildDepartments(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var staff = yield staff_1.Staff.getCurrent();
            var options = {};
            options.where = params;
            options.order = [["created_at", "desc"]];
            if (staff) {
                params.companyId = staff["companyId"]; //只允许查询该企业下的部门
            }
            return index_1.Models.department.find(options);
        });
    }
    /**
     * 得到所有子级部门
     * @param params
     * @returns {*}
     */
    static getAllChildren(params) {
        var sql = "with RECURSIVE cte as " +
            "( select a.id,a.name,a.parent_id from department.departments a where id='" + params.parentId + "' " +
            "union all select k.id,k.name,k.parent_id  from department.departments k inner join cte c on c.id = k.parent_id " +
            "where k.deleted_at is null) " +
            "select * from cte";
        return sequelize.query(sql)
            .spread(function (children, row) {
            return children;
        });
    }
    static getAllChildDepartments(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var staff = yield staff_1.Staff.getCurrent();
            if (staff) {
                params.companyId = staff["companyId"]; //只允许查询该企业下的部门
            }
            return DepartmentModule.getAllChildren(params);
        });
    }
    /**
     * 得到所有子级部门id数组
     * @param params
     * @returns {*}
     */
    static getAllChildDepartmentsId(params) {
        var ids = [];
        var sql = "with RECURSIVE cte as " +
            "( select a.id,a.name,a.parent_id from department.departments a where id='" + params.parentId + "' " +
            "union all select k.id,k.name,k.parent_id  from department.departments k inner join cte c on c.id = k.parent_id " +
            "where k.deleted_at is null) " +
            "select * from cte";
        return sequelize.query(sql)
            .spread(function (children, row) {
            for (var i = 0; i < children.length; i++)
                ids.push(children[i].id);
            return ids;
        });
    }
    /**
     * 得到部门下员工总数（包括子部门下的员工）
     * @param params
     * @returns {*}
     */
    static getAllStaffNum(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let ids = yield DepartmentModule.getAllChildDepartmentsId({ parentId: params.departmentId });
            let idsStr = ids.join("','");
            let sql = "select count(*) from" +
                " (select distinct staff_id from department.staff_departments where department_id in ('" + idsStr + "') and deleted_at is null) as a";
            let result = yield sequelize.query(sql);
            return result[0][0].count;
        });
    }
    static getStaffs(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let currentStaff = yield staff_1.Staff.getCurrent();
            let options = params.options;
            if (!options)
                options = { where: {} };
            if (!options.where)
                options.where = {};
            let pagers = yield index_1.Models.staffDepartment.find({ where: { departmentId: params.id }, order: [['createdAt', 'desc']] });
            let departmentStaffs = [];
            departmentStaffs.push.apply(departmentStaffs, pagers);
            while (pagers.hasNextPage()) {
                let nextPager = yield pagers.nextPage();
                departmentStaffs.push.apply(departmentStaffs, nextPager);
                // pagers = nextPager;
            }
            let ids = yield Promise.all(departmentStaffs.map(function (t) {
                return t.staffId;
            }));
            options.where.staffStatus = staff_1.EStaffStatus.ON_JOB;
            options.where.companyId = currentStaff.company.id;
            options.where.id = { $in: ids };
            //姓名Z-A
            if (options.order == 'nameDesc') {
                options.order = "convert_to(name,'gbk') desc";
            }
            //姓名A-Z
            if (options.order == 'nameAsc') {
                options.order = "convert_to(name,'gbk') asc";
            }
            //角色排序
            if (options.order == 'role') {
                options.order = [['roleId', 'asc']];
            }
            //差率标准排序
            if (options.order == 'travelPolicy') {
                options.order = [['travelPolicyId', 'asc']];
            }
            //员工状态
            /*if(options.order == 'status'){
                DBM.Staff.belongsTo(DBM.Account, {foreignKey: 'id', targetKey: 'id'});
                options.include = [{
                    model: DBM.Account,
                    attributes : []
                }];
                options.order = '"' + 'Account' + '"' + '.status asc';
             }*/
            let _order = options.order;
            if (options.order == 'status') {
                delete options.order;
            }
            //默认按创建时间排序排序
            if (options.order == 'createdAt' || !options.order) {
                options.order = [['createdAt', 'desc']];
            }
            let staffs = yield index_1.Models.staff.find(options);
            //取出集合之后排序 不是对全部数据进行排序会出问题
            /*if(_order == 'status'){
                staffs.sort(function(a,b){
                    return a.status - b.status;
                })
            }*/
            return staffs;
        });
    }
    static deleteDepartmentByTest(params) {
        return DBM.Department.destroy({ where: { $or: [{ name: params.name }, { companyId: params.companyId }] } })
            .then(function () {
            return true;
        });
    }
    /****************************************StaffDepartment begin************************************************/
    /**
     * 创建员工部门记录
     * @param data
     * @returns {*}
     */
    static createStaffDepartment(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var staffDepartment = department_1.StaffDepartment.create(params);
            var already = yield index_1.Models.staffDepartment.find({ where: { departmentId: params.departmentId, staffId: params.staffId } });
            if (already && already.length > 0) {
                return already[0];
            }
            var result = yield staffDepartment.save();
            return result;
        });
    }
    /**
     * 删除员工部门记录
     * @param params
     * @returns {*}
     */
    static deleteStaffDepartment(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var id = params.id;
            var ah_delete = yield index_1.Models.staffDepartment.get(id);
            yield ah_delete.destroy();
            return true;
        });
    }
    /**
     * 更新员工部门记录
     * @param id
     * @param data
     * @returns {*}
     */
    static updateStaffDepartment(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var id = params.id;
            var ah = yield index_1.Models.staffDepartment.get(id);
            for (var key in params) {
                ah[key] = params[key];
            }
            return ah.save();
        });
    }
    /**
     * 根据id查询员工部门记录
     * @param {String} params.id
     * @returns {*}
     */
    static getStaffDepartment(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let id = params.id;
            var ah = yield index_1.Models.staffDepartment.get(id);
            return ah;
        });
    }
    ;
    /**
     * 根据属性查找员工部门记录
     * @param params
     * @returns {*}
     */
    static getStaffDepartments(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var staff = yield staff_1.Staff.getCurrent();
            let paginate = yield index_1.Models.staffDepartment.find(params);
            let ids = paginate.map(function (t) {
                return t.id;
            });
            return { ids: ids, count: paginate['total'] };
        });
    }
}
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["name", "companyId", "parentId"], departmentCols),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isCompanyAdminOrOwner("0.companyId") },
        { if: _decorator_1.condition.isCompanyAgency("0.companyId") },
        { if: _decorator_1.condition.isCompanyDepartment("0.parentId") }
    ])
], DepartmentModule, "createDepartment", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"]),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isDepartmentAdminOrOwner("0.id") },
        { if: _decorator_1.condition.isDepartmentAgency("0.id") }
    ])
], DepartmentModule, "deleteDepartment", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"], departmentCols),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isDepartmentAdminOrOwner("0.id") },
        { if: _decorator_1.condition.isDepartmentAgency("0.id") }
    ])
], DepartmentModule, "updateDepartment", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"]),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isDepartmentCompany("0.id") },
        { if: _decorator_1.condition.isSelfDepartment("0.id") },
        { if: _decorator_1.condition.isDepartmentAgency("0.id") }
    ])
], DepartmentModule, "getDepartment", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["where.companyId"], departmentCols.map((v) => 'where.' + v)),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isCompanyAdminOrOwner("where.companyId") },
        { if: _decorator_1.condition.isCompanyAgency("where.companyId") }
    ])
], DepartmentModule, "getDepartments", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["companyId"]),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isCompanyAdminOrOwner("0.companyId") },
        { if: _decorator_1.condition.isCompanyAgency("0.companyId") }
    ])
], DepartmentModule, "getFirstClassDepartments", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["parentId"], ["companyId"]),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isDepartmentAdminOrOwner("0.parentId") },
        { if: _decorator_1.condition.isDepartmentAgency("0.parentId") }
    ])
], DepartmentModule, "getChildDepartments", null);
tslib_1.__decorate([
    helper_1.requireParams(["parentId"]),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isDepartmentAdminOrOwner("0.parentId") },
        { if: _decorator_1.condition.isDepartmentAgency("0.parentId") }
    ])
], DepartmentModule, "getAllChildren", null);
tslib_1.__decorate([
    helper_1.requireParams(["parentId"]),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isDepartmentAdminOrOwner("0.parentId") },
        { if: _decorator_1.condition.isDepartmentAgency("0.parentId") }
    ])
], DepartmentModule, "getAllChildDepartments", null);
tslib_1.__decorate([
    helper_1.requireParams(["parentId"]),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isDepartmentAdminOrOwner("0.parentId") },
        { if: _decorator_1.condition.isDepartmentAgency("0.parentId") }
    ])
], DepartmentModule, "getAllChildDepartmentsId", null);
tslib_1.__decorate([
    helper_1.requireParams(["departmentId"]),
    _decorator_1.conditionDecorator([
        { if: _decorator_1.condition.isDepartmentAdminOrOwner("0.departmentId") },
        { if: _decorator_1.condition.isDepartmentAgency("0.departmentId") }
    ])
], DepartmentModule, "getAllStaffNum", null);
tslib_1.__decorate([
    helper_1.clientExport
], DepartmentModule, "getStaffs", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["departmentId", "staffId"], staffDepartmentCols)
], DepartmentModule, "createStaffDepartment", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"])
], DepartmentModule, "deleteStaffDepartment", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"], staffDepartmentCols)
], DepartmentModule, "updateStaffDepartment", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"])
], DepartmentModule, "getStaffDepartment", null);
tslib_1.__decorate([
    helper_1.clientExport
], DepartmentModule, "getStaffDepartments", null);
module.exports = DepartmentModule;

//# sourceMappingURL=index.js.map
