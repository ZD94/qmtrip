/**
 * Created by wyl on 16-12-6.
 */
'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const index_1 = require("_types/index");
const coin_1 = require("_types/coin");
var config = require('config');
var API = require("common/api");
module.exports = function (app) {
    app.get("/duiba/costcredit", costCredit);
    app.get("/duiba/result/notice", resultNotice);
    app.get("/duiba/addcredit", addCredit);
};
/**
 * 扣积分接口
 * @param req
 * @param res
 * @param next
 * @returns {any}
 */
function costCredit(req, res, next) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        console.info("扣积分接口================");
        var params = req.query;
        var { uid, credits, appKey, timestamp, description, orderNum, actualPrice, sign } = params;
        var staff = yield index_1.Models.staff.get(uid);
        staff.coinAccount = staff.$parents["account"]["coinAccount"];
        //资金账户不存在先创建
        if (!staff.coinAccount) {
            let ca = coin_1.CoinAccount.create();
            yield ca.save();
            let account = yield index_1.Models.account.get(staff.id);
            account.coinAccount = ca;
            yield account.save();
            // staff.coinAccount = ca;
            // await staff.save();
        }
        var coinAccount = staff.coinAccount;
        if (!appKey || appKey != config.duiba.appKey) {
            res.json({
                'status': 'fail',
                'errorMessage': 'appKey错误',
                'credits': coinAccount.balance
            });
        }
        if (params.sign) {
            delete params.sign;
        }
        var _sign = yield API.duiba.getSign(params);
        if (sign != _sign) {
            res.json({
                'status': 'fail',
                'errorMessage': '签名错误',
                'credits': coinAccount.balance
            });
        }
        var coinAccountChanges = yield index_1.Models.coinAccountChange.find({ where: { duiBaOrderNum: orderNum } });
        //防止订单重复处理
        if (!coinAccountChanges || coinAccountChanges.length <= 0) {
            var result = yield coinAccount.lockCoin(credits, description, orderNum);
            res.json({
                'status': 'ok',
                'errorMessage': '',
                'bizId': result.coinAccountChange.id,
                'credits': result.coinAccount.balance
            });
        }
        else {
            res.json({
                'status': 'ok',
                'errorMessage': '该订单已处理',
                'bizId': coinAccountChanges[0].id,
                'credits': coinAccount.balance
            });
        }
    });
}
/**
 * 兑换结果通知接口
 * @param req
 * @param res
 * @param next
 * @returns {any}
 */
function resultNotice(req, res, next) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        console.info("接收通知接口================");
        var params = req.query;
        var { appKey, timestamp, success, errorMessage, orderNum, bizId, sign } = params;
        if (params.sign) {
            delete params.sign;
        }
        if (!appKey || appKey != config.duiba.appKey) {
            res.json({
                'status': 'fail',
                'errorMessage': 'appKey错误',
            });
        }
        var _sign = yield API.duiba.getSign(params);
        if (sign != _sign) {
            res.json({
                'status': 'fail',
                'errorMessage': '签名错误',
            });
        }
        //扣积分请求超时时兑吧也会发回失败通知 此时未携带bizId 所以查失败订单不能用bizId 要用orderNum
        var coinAccountChanges = yield index_1.Models.coinAccountChange.find({ where: { duiBaOrderNum: orderNum, type: coin_1.COIN_CHANGE_TYPE.LOCK } });
        var coinAccountChange;
        if (coinAccountChanges && coinAccountChanges.length > 0) {
            coinAccountChange = coinAccountChanges[0];
            var coinAccount = yield index_1.Models.coinAccount.get(coinAccountChange.coinAccountId);
            if (!coinAccountChange.coins) {
                coinAccountChange.coins = 0;
            }
            if (typeof coinAccountChange.coins == 'string') {
                coinAccountChange.coins = Number(coinAccountChange.coins);
            }
            if (success == "false") {
                if (typeof coinAccount.locks == 'string') {
                    coinAccount.locks = Number(coinAccount.locks);
                }
                coinAccount.locks = coinAccount.locks - coinAccountChange.coins;
                yield coinAccount.save();
                yield coinAccountChange.destroy();
                res.json({
                    'status': 'fail',
                    'errorMessage': errorMessage,
                });
            }
            else {
                if (typeof coinAccount.locks == 'string') {
                    coinAccount.locks = Number(coinAccount.locks);
                }
                if (!coinAccount.consume) {
                    coinAccount.consume = 0;
                }
                if (typeof coinAccount.consume == 'string') {
                    coinAccount.consume = Number(coinAccount.consume);
                }
                coinAccount.locks = coinAccount.locks - coinAccountChange.coins;
                coinAccount.consume = coinAccount.consume + coinAccountChange.coins;
                yield coinAccount.save();
                coinAccountChange.type = coin_1.COIN_CHANGE_TYPE.CONSUME;
                yield coinAccountChange.save();
                res.json({
                    'status': 'success',
                });
            }
        }
        else {
            res.send('ok');
        }
    });
}
/**
 * 增加积分
 * @param req
 * @param res
 * @param next
 * @returns {any}
 */
function addCredit(req, res, next) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        var params = req.query;
        var { uid, credits, appKey, type, timestamp, description, orderNum, sign } = params;
        var staff = yield index_1.Models.staff.get(uid);
        staff.coinAccount = staff.$parents["account"]["coinAccount"];
        //资金账户不存在先创建
        if (!staff.coinAccount) {
            let ca = coin_1.CoinAccount.create();
            yield ca.save();
            let account = yield index_1.Models.account.get(staff.id);
            account.coinAccount = ca;
            yield account.save();
            // staff.coinAccount = ca;
            // await staff.save();
        }
        var coinAccount = staff.coinAccount;
        if (!appKey || appKey != config.duiba.appKey) {
            res.json({
                'status': 'fail',
                'errorMessage': 'appKey错误',
                'credits': coinAccount.balance
            });
        }
        if (params.sign) {
            delete params.sign;
        }
        var _sign = yield API.duiba.getSign(params);
        if (sign != _sign) {
            res.json({
                'status': 'fail',
                'errorMessage': '签名错误',
                'credits': coinAccount.balance
            });
        }
        var coinAccountChanges = yield index_1.Models.coinAccountChange.find({ where: { duiBaOrderNum: orderNum } });
        //防止订单重复处理
        if (!coinAccountChanges || coinAccountChanges.length <= 0) {
            var result = yield coinAccount.addCoin(credits, description, orderNum);
            res.json({
                'status': 'ok',
                'errorMessage': '',
                'bizId': result.coinAccountChange.id,
                'credits': coinAccount.balance
            });
        }
        else {
            res.json({
                'status': 'ok',
                'errorMessage': '',
                'bizId': coinAccountChanges[0].id,
                'credits': coinAccount.balance
            });
        }
    });
}

//# sourceMappingURL=duiba.js.map
