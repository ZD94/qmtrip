/**
 * Created by wyl on 16-12-6.
 */
'use strict';
const tslib_1 = require("tslib");
const helper_1 = require("../../common/api/helper");
const staff_1 = require("_types/staff/staff");
var config = require('config');
var URL = require('url');
var utils = require("common/utils");
var baseUrl = "https://www.duiba.com.cn/autoLogin/autologin";
class DuiBa {
    /**
     * 获取免登陆url
     * @param params
     * @param params.redirect 重定向地址
     * @returns {string}
     */
    static getLoginUrl(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var staff = yield staff_1.Staff.getCurrent();
            if (!params)
                params = {};
            params.uid = staff.id;
            var credits = 0;
            staff.coinAccount = staff.$parents["account"]["coinAccount"];
            if (staff.coinAccount && staff.coinAccount.balance) {
                credits = staff.coinAccount.balance;
            }
            credits = Math.floor(credits);
            params.credits = credits;
            params.appKey = config.duiba.appKey;
            params.appSecret = config.duiba.appSecret;
            if (!params.timestamp)
                params.timestamp = new Date().getTime();
            let sign = yield DuiBa.getSign(params);
            params.sign = sign;
            if (params.hasOwnProperty("appSecret")) {
                delete params.appSecret;
            }
            let u = URL.parse(baseUrl);
            u.query = params;
            let url = URL.format(u);
            return url;
        });
    }
    static getSign(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (params.hasOwnProperty("sign")) {
                delete params.sign;
            }
            if (!params.hasOwnProperty("appSecret")) {
                params.appSecret = config.duiba.appSecret;
            }
            let keys = Object.keys(params).sort();
            var keyValue = "";
            for (let key of keys) {
                keyValue += params[key];
            }
            var sign = utils.md5(keyValue);
            return sign;
        });
    }
}
DuiBa.__initHttpApp = require('./duiba');
tslib_1.__decorate([
    helper_1.clientExport
], DuiBa, "getLoginUrl", null);
module.exports = DuiBa;

//# sourceMappingURL=index.js.map
