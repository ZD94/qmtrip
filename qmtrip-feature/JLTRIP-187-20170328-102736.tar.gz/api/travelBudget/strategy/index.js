/**
 * Created by wlh on 16/8/13.
 */
'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const prefer_1 = require("../prefer");
const index_1 = require("_types/index");
function formatTicketData(tickets) {
    let _tickets = [];
    //把数据平铺
    for (var i = 0, ii = tickets.length; i < ii; i++) {
        let agents = tickets[i].agents;
        for (var j = 0, jj = agents.length; j < jj; j++) {
            let cabins = agents[j].cabins;
            for (var n = 0, nn = cabins.length; n < nn; n++) {
                let cabin = cabins[n];
                let _ticket = {
                    No: tickets[i].No,
                    departDateTime: tickets[i].departDateTime,
                    arrivalDateTime: tickets[i].arrivalDateTime,
                    originPlace: tickets[i].originPlace,
                    destination: tickets[i].destination,
                    originStation: tickets[i].originStation,
                    destinationStation: tickets[i].destinationStation,
                    agent: agents[j].name,
                    cabin: cabin.name,
                    price: cabin.price,
                    remainNum: cabin.remainNum,
                    bookUrl: agents[j].bookUrl,
                    duration: tickets[i].duration || ((new Date(tickets[i].arrivalDateTime).valueOf() - new Date(tickets[i].departDateTime).valueOf()) / (60 * 1000)),
                    type: tickets[i].type,
                    stops: tickets[i].stops,
                    segs: tickets[i].segs,
                };
                _tickets.push(_ticket);
            }
        }
    }
    return _tickets;
}
function formatHotel(hotels) {
    let _hotels = [];
    for (let i = 0, ii = hotels.length; i < ii; i++) {
        let hotel = hotels[i];
        let agents = hotel.agents || hotel['agent'];
        for (var j = 0, jj = agents.length; j < jj; j++) {
            _hotels.push({
                name: hotel.name,
                latitude: hotel.latitude,
                longitude: hotel.longitude,
                star: hotel.star,
                price: agents[j].price,
                bookUrl: agents[j].bookUrl,
                agent: agents[j].name,
                checkInDate: hotel.checkInDate,
                checkOutDate: hotel.checkOutDate,
                outPriceRange: false
            });
        }
    }
    return _hotels;
}
class AbstractHotelStrategy {
    constructor(qs, options) {
        this.qs = qs;
        if (options && options.isRecord) {
            this.isRecord = true;
        }
        else {
            this.isRecord = false;
        }
        this.prefers = [];
    }
    addPrefer(p) {
        this.prefers.push(p);
    }
    getMarkedScoreHotels(hotels) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            for (let prefer of self.prefers) {
                hotels = yield prefer.markScore(hotels);
            }
            return hotels;
        });
    }
    getResult(hotels, isRetMarkedData) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let _hotels = formatHotel(hotels);
            if (!_hotels || !_hotels.length) {
                const defaultPrice = {
                    "5": 500,
                    "4": 450,
                    "3": 400,
                    "2": 350
                };
                return {
                    price: defaultPrice[this.qs.star]
                };
            }
            _hotels = yield this.getMarkedScoreHotels(_hotels);
            _hotels.sort((v1, v2) => {
                return v2.score - v1.score;
            });
            _hotels = yield this.customMarkedScoreData(_hotels);
            let ret = _hotels[0];
            let result = {
                price: ret.price,
                agent: ret.agent,
                name: ret.name,
                star: ret.star,
                latitude: ret.latitude,
                longitude: ret.longitude,
                checkInDate: this.qs.query.checkInDate,
                checkOutDate: this.qs.query.checkOutDate,
                cityName: this.qs.query.city.name,
                hotelName: this.qs.query.hotelName
            };
            if (isRetMarkedData) {
                result.markedScoreData = _hotels;
            }
            if (this.isRecord) {
                let travelBudgetLog = yield index_1.Models.travelBudgetLog.create({});
                travelBudgetLog.title = `[住宿]${this.qs.query.city.name}-(${this.qs.query.checkInDate})`;
                travelBudgetLog.prefers = this.qs.prefers;
                travelBudgetLog.query = this.qs.query;
                travelBudgetLog.originData = hotels;
                travelBudgetLog.type = 2;
                travelBudgetLog.result = result;
                travelBudgetLog.markedData = _hotels;
                let log = yield travelBudgetLog.save();
                result.id = log.id;
            }
            return result;
        });
    }
}
exports.AbstractHotelStrategy = AbstractHotelStrategy;
class CommonHotelStrategy extends AbstractHotelStrategy {
    constructor(qs, options) {
        super(qs, options);
        this.qs = qs;
    }
    customMarkedScoreData(hotels) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            hotels.sort((v1, v2) => {
                let diff = v2.score - v1.score;
                if (diff)
                    return diff;
                return v2.price - v1.price;
            });
            return hotels;
        });
    }
}
exports.CommonHotelStrategy = CommonHotelStrategy;
class HighPriceHotelStrategy extends AbstractHotelStrategy {
    constructor(qs, options) {
        super(qs, options);
        this.qs = qs;
    }
    customMarkedScoreData(hotels) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            hotels.sort((v1, v2) => {
                let diff = v2.score - v1.score;
                if (diff)
                    return diff;
                return v1.price - v2.price;
            });
            return hotels;
        });
    }
}
exports.HighPriceHotelStrategy = HighPriceHotelStrategy;
class AbstractTicketStrategy {
    constructor(qs, options) {
        this.qs = qs;
        if (options && options.isRecord) {
            this.isRecord = true;
        }
        else {
            this.isRecord = false;
        }
        this.prefers = [];
    }
    addPrefer(p) {
        this.prefers.push(p);
    }
    getMarkedScoreTickets(tickets) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            self.prefers.forEach((p) => tslib_1.__awaiter(this, void 0, void 0, function* () {
                tickets = yield p.markScore(tickets);
            }));
            return tickets;
        });
    }
    getResult(tickets, isRetMarkedData) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let _tickets = formatTicketData(tickets);
            if (!_tickets || !_tickets.length) {
                return {
                    price: -1
                };
            }
            _tickets = yield this.getMarkedScoreTickets(_tickets);
            _tickets.sort((v1, v2) => {
                return v2.score - v1.score;
            });
            _tickets = yield this.customerMarkedScoreData(_tickets);
            let ret = _tickets[0];
            let result = {
                price: ret.price,
                type: ret.type,
                No: ret.No,
                agent: ret.agent,
                cabin: ret.cabin,
                destination: ret.destination,
                originPlace: ret.originPlace,
                departDateTime: ret.departDateTime,
                arrivalDateTime: ret.arrivalDateTime,
                leaveDate: this.qs.query.leaveDate
            };
            if (isRetMarkedData) {
                result.markedScoreData = _tickets;
            }
            if (this.isRecord) {
                let travelBudgetLog = yield index_1.Models.travelBudgetLog.create({});
                travelBudgetLog.title = `[交通]${this.qs.query.originPlace.name}-${this.qs.query.destination.name}(${this.qs.query.leaveDate})`;
                travelBudgetLog.prefers = this.qs.prefers;
                travelBudgetLog.query = this.qs.query;
                travelBudgetLog.originData = tickets;
                travelBudgetLog.type = 1;
                travelBudgetLog.result = result;
                travelBudgetLog.markedData = _tickets;
                let log = yield travelBudgetLog.save();
                result.id = log.id;
            }
            return result;
        });
    }
}
exports.AbstractTicketStrategy = AbstractTicketStrategy;
class CommonTicketStrategy extends AbstractTicketStrategy {
    constructor(query, options) {
        super(query, options);
        this.query = query;
    }
    customerMarkedScoreData(tickets) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            tickets.sort((v1, v2) => {
                let diff = v2.score - v1.score;
                if (diff)
                    return diff;
                return v1.price - v2.price;
            });
            return tickets;
        });
    }
}
exports.CommonTicketStrategy = CommonTicketStrategy;
class HighPriceTicketStrategy extends AbstractTicketStrategy {
    constructor(query, options) {
        super(query, options);
        this.query = query;
    }
    customerMarkedScoreData(tickets) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            tickets.sort((v1, v2) => {
                let diff = v2.score - v1.score;
                if (diff)
                    return diff;
                return v2.price - v1.price;
            });
            return tickets;
        });
    }
}
exports.HighPriceTicketStrategy = HighPriceTicketStrategy;
class TrafficBudgetStrategyFactory {
    static getStrategy(qs, options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let policy = qs.policy;
            let prefers = qs.prefers; //保存的是企业打分参数信息
            let strategy;
            //选择策略
            switch (policy) {
                case 'bmw':
                    strategy = new HighPriceTicketStrategy(qs, options);
                    break;
                default:
                    strategy = new CommonTicketStrategy(qs, options);
            }
            //通过企业配置的喜好打分
            for (let k of prefers) {
                let prefer = PreferFactory.getPrefer(k.name, k.options);
                if (!prefer)
                    continue;
                strategy.addPrefer(prefer);
            }
            return strategy;
        });
    }
}
exports.TrafficBudgetStrategyFactory = TrafficBudgetStrategyFactory;
class HotelBudgetStrategyFactory {
    static getStrategy(qs, options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            //let policy = qs.policy;
            let prefers = qs.prefers;
            let strategy = new CommonHotelStrategy(qs, options);
            for (let p of prefers) {
                let prefer = PreferFactory.getPrefer(p.name, p.options, 'hotel');
                if (!prefer)
                    continue;
                strategy.addPrefer(prefer);
            }
            return strategy;
        });
    }
}
exports.HotelBudgetStrategyFactory = HotelBudgetStrategyFactory;
class PreferFactory {
    static getPrefer(name, options, type) {
        let cls = type == 'hotel' ? prefer_1.hotelPrefers[name] : prefer_1.ticketPrefers[name];
        if (cls && typeof cls == 'function') {
            return new (cls)(name, options);
        }
        return null;
    }
}

//# sourceMappingURL=index.js.map
