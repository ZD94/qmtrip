/**
 * Created by wlh on 16/8/11.
 */
'use strict';
const tslib_1 = require("tslib");
const travelbudget_1 = require("_types/travelbudget");
const index_1 = require("./index");
const ONLY_TRAIN_DURATION = 3.5 * 60;
const ONLY_FLIGHT_DURATION = 6 * 60;
class SelectTrafficByTimePrefer extends index_1.AbstractPrefer {
    constructor(name, options) {
        super(name, options);
        if (!this.selectTrainDuration) {
            this.selectTrainDuration = ONLY_TRAIN_DURATION;
        }
        if (!this.selectFlightDuration) {
            this.selectFlightDuration = ONLY_FLIGHT_DURATION;
        }
        if (!this.score) {
            this.score = 0;
        }
        if (!this.commonTrainScore) {
            this.commonTrainScore = 0;
        }
    }
    markScoreProcess(tickets) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            //分离火车,飞机预算
            let trains = [];
            let highTrains = [];
            let trains2 = [];
            let trains3 = [];
            let flights = [];
            tickets.forEach((v) => {
                if (v.type == travelbudget_1.TRAFFIC.TRAIN && /^[gc]/i.test(v.No)) {
                    highTrains.push(v);
                    return;
                }
                if (v.type == travelbudget_1.TRAFFIC.TRAIN && /^[d]/i.test(v.No)) {
                    trains2.push(v);
                    return;
                }
                if (v.type == travelbudget_1.TRAFFIC.TRAIN) {
                    trains3.push(v);
                }
                flights.push(v);
            });
            if (highTrains.length) {
                trains = highTrains;
            }
            if (!trains.length)
                trains = trains2;
            if (!trains.length)
                trains = trains3;
            if (!trains.length)
                return flights;
            trains.sort(function (v1, v2) {
                return v1.duration - v2.duration;
            });
            let midIdx = Math.ceil(trains.length / 2) - 1;
            let gainScoreTraffic = null;
            if (typeof trains[midIdx] == 'string') {
                trains[midIdx].duration = trains[midIdx].duration;
            }
            if (trains[midIdx].duration <= self.selectTrainDuration) {
                console.info(`时长小于只选火车:${trains[midIdx].duration} < ${self.selectTrainDuration}`);
                //火车加分
                gainScoreTraffic = travelbudget_1.TRAFFIC.TRAIN;
            }
            else if (trains[midIdx].duration > self.selectFlightDuration) {
                console.info(`时长大于只选飞机:${trains[midIdx].duration} > ${self.selectFlightDuration}`);
                gainScoreTraffic = travelbudget_1.TRAFFIC.FLIGHT;
            }
            else {
                console.info(`平均时长无法决定选择飞机火车:${self.selectFlightDuration} < ${trains[midIdx].duration} < ${self.selectTrainDuration}`);
            }
            tickets = tickets.map((v) => {
                if (!v.score)
                    v.score = 0;
                if (!v.reasons)
                    v.reasons = [];
                //普通车减掉score
                if (v.type == travelbudget_1.TRAFFIC.TRAIN) {
                    if (/^d/i.test(v.No)) {
                        v.score += self.commonTrainScore / 2;
                        v.reasons.push(`动车${self.commonTrainScore / 2}`);
                    }
                    else if (/^[^gcd]/i.test(v.No)) {
                        v['score'] += self.commonTrainScore;
                        v.reasons.push(`普通车${self.commonTrainScore}`);
                    }
                }
                if (gainScoreTraffic !== null && gainScoreTraffic !== undefined && v.type == gainScoreTraffic) {
                    v.score += self.score;
                    v.reasons.push(`正确交通方式 +${self.score}`);
                }
                return v;
            });
            return tickets;
        });
    }
}
module.exports = SelectTrafficByTimePrefer;

//# sourceMappingURL=ticket-selectTrafficByTime.js.map
