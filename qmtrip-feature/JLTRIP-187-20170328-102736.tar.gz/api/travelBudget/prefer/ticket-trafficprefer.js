/**
 * Created by wlh on 16/9/2.
 */
'use strict';
const tslib_1 = require("tslib");
const travelbudget_1 = require("_types/travelbudget");
const index_1 = require("./index");
class TrafficPrefer extends index_1.AbstractPrefer {
    constructor(name, options) {
        super(name, options);
        if (!this.score) {
            this.score = 0;
        }
    }
    markScoreProcess(tickets) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            if (!self.expectTraffic)
                return tickets;
            let _expectTraffic = self.expectTraffic == 'train' ? travelbudget_1.TRAFFIC.TRAIN : travelbudget_1.TRAFFIC.FLIGHT;
            tickets = tickets.map((v) => {
                if (!v.score)
                    v.score = 0;
                if (!v.reasons)
                    v.reasons = [];
                if (v.type == _expectTraffic) {
                    v.score += self.score;
                    v.reasons.push(`符合期望交通方式:${self.score}`);
                }
                return v;
            });
            return tickets;
        });
    }
}
module.exports = TrafficPrefer;

//# sourceMappingURL=ticket-trafficprefer.js.map
