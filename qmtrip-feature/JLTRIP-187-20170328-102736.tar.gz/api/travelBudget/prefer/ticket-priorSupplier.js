/**
 * Created by wlh on 16/8/10.
 */
'use strict';
const tslib_1 = require("tslib");
const travelbudget_1 = require("_types/travelbudget");
const index_1 = require("./index");
//优先供应商
// const CHEAP_SUPPLIERS = ['中国北方航空公司', '大新华航空公司', '上海航空公司'];
class PriorSupplierPrefer extends index_1.AbstractPrefer {
    constructor(name, options) {
        super(name, options);
        if (!this.score) {
            this.score = 0;
        }
    }
    markScoreProcess(tickets) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!tickets.length)
                return tickets;
            let self = this;
            tickets = tickets.map((v) => {
                if (!v['score'])
                    v['score'] = 0;
                if (!v['reasons'])
                    v['reasons'] = [];
                let supplier = "";
                if (v.type == travelbudget_1.TRAFFIC.FLIGHT && v.No && v.No.length > 2) {
                    supplier = v.No.substr(0, 2);
                }
                if (v.type == travelbudget_1.TRAFFIC.FLIGHT && supplier.length > 0 && self.priorSuppliers.indexOf(supplier) >= 0) {
                    v['score'] += self.score;
                    v['reasons'].push(`优先乘坐的供应商 ${self.score}`);
                }
                return v;
            });
            return tickets;
        });
    }
}
module.exports = PriorSupplierPrefer;

//# sourceMappingURL=ticket-priorSupplier.js.map
