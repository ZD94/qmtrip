/**
 * Created by wlh on 2016/12/13.
 */
'use strict';
const tslib_1 = require("tslib");
const index_1 = require("./index");
class DirectArrivePrefer extends index_1.AbstractPrefer {
    constructor(name, options) {
        super(name, options);
        this.baseScore = options.baseScore || 20000;
        this.rate = options.rate || 1.05;
    }
    markScoreProcess(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            data = data.map((v) => {
                if (!v.score) {
                    v.score = 0;
                }
                if (!v.reasons) {
                    v.reasons = [];
                }
                if (v.segs && v.segs.length) {
                    let l = v.segs.length;
                    if (l > 1) {
                        let score = self.baseScore * (1 - (l - 1) * self.rate);
                        v.score += score;
                        v.reasons.push(`需经过${l - 1}次中转: ${score}`);
                    }
                }
                return v;
            });
            return data;
        });
    }
}
module.exports = DirectArrivePrefer;

//# sourceMappingURL=ticket-directArrive.js.map
