/**
 * Created by wlh on 16/8/15.
 */
'use strict';
const tslib_1 = require("tslib");
const index_1 = require("./index");
const _ = require("lodash");
class StarMatchPrefer extends index_1.AbstractPrefer {
    constructor(name, options) {
        super(name, options);
        if (!this.score) {
            this.score = 0;
        }
        if (/,/.test(options.expectStar)) {
            this.expectStar = options.expectStar.split(/,/g);
        }
        if (!_.isArray(this.expectStar)) {
            this.expectStar = [this.expectStar];
        }
        this.expectStar = this.expectStar.map((v) => {
            return parseInt(v);
        });
    }
    markScoreProcess(hotels) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            hotels = hotels.map((v) => {
                if (!v.score)
                    v.score = 0;
                if (!v.reasons)
                    v.reasons = [];
                if (self.expectStar.indexOf(v.star) >= 0) {
                    v.score += self.score;
                    v.reasons.push(`符合星级标准+${self.score}`);
                }
                else {
                    v.reasons.push(`不符合星际标准0`);
                }
                return v;
            });
            return hotels;
        });
    }
}
module.exports = StarMatchPrefer;

//# sourceMappingURL=hotel-star-match.js.map
