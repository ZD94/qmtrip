/**
 * Created by wlh on 16/8/15.
 */
'use strict';
const tslib_1 = require("tslib");
const index_1 = require("./index");
const BLACKLIST_HOTEL_AGENTS = ['hotels.com', '好订'];
class BlackListPrefer extends index_1.AbstractPrefer {
    constructor(name, options) {
        super(name, options);
        if (!this.score) {
            this.score = 0;
        }
    }
    markScoreProcess(hotels) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            hotels = hotels.map((hotel) => {
                if (!hotel.score)
                    hotel.score = 0;
                if (!hotel.reasons)
                    hotel.reasons = [];
                if (BLACKLIST_HOTEL_AGENTS.indexOf(hotel.agent) >= 0) {
                    hotel.score += self.score;
                    hotel.reasons.push(`供应商黑名单+${self.score}`);
                }
                else {
                    hotel.reasons.push(`不在供应商黑名单 0`);
                }
                return hotel;
            });
            return hotels;
        });
    }
}
module.exports = BlackListPrefer;

//# sourceMappingURL=hotel-blacklist.js.map
