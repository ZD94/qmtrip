/**
 * Created by wlh on 2017/2/21.
 */
'use strict';
const tslib_1 = require("tslib");
const index_1 = require("./index");
const travelbudget_1 = require("_types/travelbudget");
var API = require("common/api");
class TransitCityInChinaPrefer extends index_1.AbstractPrefer {
    constructor(name, options) {
        super(name, options);
        this.baseScore = options.baseScore;
    }
    markScoreProcess(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            let ps = data.map((ticket) => tslib_1.__awaiter(this, void 0, void 0, function* () {
                if (!ticket.score)
                    ticket.score = 0;
                if (!ticket.reasons) {
                    ticket.reasons = [];
                }
                //不是机票信息
                if (ticket.type != travelbudget_1.TRAFFIC.FLIGHT)
                    return ticket;
                //没有中转信息
                if (!ticket.segs || ticket.segs.length < 1)
                    return ticket;
                //查看中转城市中国外城市数据
                let transitInChinaNum = 0;
                for (let i = 1, ii = ticket.segs.length; i < ii; i++) {
                    let seg = ticket.segs[i];
                    let city = yield API.place.getCityInfo({ cityCode: seg.deptAirport.city });
                    if (city && !city.isAbroad) {
                        transitInChinaNum += 1;
                    }
                }
                if (!transitInChinaNum || transitInChinaNum < 1)
                    return ticket;
                let score = self.baseScore * Math.sqrt(transitInChinaNum);
                ticket.score += score;
                ticket.reasons.push(`中转城市在国内:${score}`);
                return ticket;
            }));
            data = yield Promise.all(ps);
            return data;
        });
    }
}
module.exports = TransitCityInChinaPrefer;

//# sourceMappingURL=ticket-transitCityInChinaPrefer.js.map
