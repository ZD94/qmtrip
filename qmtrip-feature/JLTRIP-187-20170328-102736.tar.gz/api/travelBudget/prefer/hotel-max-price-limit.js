/**
 * Created by wlh on 16/8/11.
 */
'use strict';
const tslib_1 = require("tslib");
const index_1 = require("./index");
class MaxPriceLimitPrefer extends index_1.AbstractPrefer {
    constructor(name, options) {
        super(name, options);
        if (!this.score) {
            this.score = 0;
        }
    }
    markScoreProcess(hotels) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            hotels = hotels.map((v) => {
                if (!v.score)
                    v.score = 0;
                if (!v.reasons)
                    v.reasons = [];
                if (!v.outPriceRange && v.price > self.maxPrice) {
                    v.score += self.score;
                    v.reasons.push(`超过限价${self.maxPrice} -${self.score}`);
                }
                return v;
            });
            return hotels;
        });
    }
}
module.exports = MaxPriceLimitPrefer;

//# sourceMappingURL=hotel-max-price-limit.js.map
