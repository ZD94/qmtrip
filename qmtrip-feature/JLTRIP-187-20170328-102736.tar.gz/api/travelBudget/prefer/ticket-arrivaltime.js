/**
 * Created by wlh on 16/8/10.
 */
'use strict';
const tslib_1 = require("tslib");
const index_1 = require("./index");
class ArrivalTimePrefer extends index_1.AbstractPrefer {
    constructor(name, options) {
        super(name, options);
        this.name = name;
        if (!this.score) {
            this.score = 0;
        }
    }
    markScoreProcess(tickets) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            let d1 = this.begin;
            let d2 = this.end;
            if (d1 && typeof d1 == 'string') {
                d1 = new Date(d1);
            }
            if (d2 && typeof d2 == 'string') {
                d2 = new Date(d2);
            }
            tickets = tickets.map((v) => {
                if (!v['score'])
                    v['score'] = 0;
                if (!v.reasons)
                    v['reasons'] = [];
                let d = new Date(v.arrivalDateTime).valueOf();
                if (d1) {
                    let _d1 = d1.valueOf();
                    if (_d1 - d > 0) {
                        v['score'] += self.score;
                        v.reasons.push(`到达时间早于规定时间 ${self.score}`);
                        return v;
                    }
                }
                if (d2) {
                    let _d2 = d2.valueOf();
                    if (d - _d2 > 0) {
                        v['score'] += self.score;
                        v.reasons.push(`到达时间晚于规定时间 ${self.score}`);
                        return v;
                    }
                }
                return v;
            });
            return tickets;
        });
    }
}
module.exports = ArrivalTimePrefer;

//# sourceMappingURL=ticket-arrivaltime.js.map
