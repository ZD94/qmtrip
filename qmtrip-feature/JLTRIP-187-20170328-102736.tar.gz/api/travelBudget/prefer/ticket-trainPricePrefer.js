/**
 * Created by wyl on 16/9/20.
 */
'use strict';
const tslib_1 = require("tslib");
const travelbudget_1 = require("_types/travelbudget");
const index_1 = require("./index");
class TrainPricePrefer extends index_1.AbstractPrefer {
    constructor(name, options) {
        super(name, options);
        if (!this.score) {
            this.score = 0;
        }
    }
    markScoreProcess(tickets) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!tickets.length)
                return tickets;
            let self = this;
            tickets = tickets.map((v) => {
                if (!v.score)
                    v.score = 0;
                if (!v.reasons)
                    v.reasons = [];
                if (v.type == travelbudget_1.TRAFFIC.TRAIN) {
                    var addScore = v.price / v.duration * 1000;
                    v.score += addScore;
                    v.reasons.push(`火车价格打分 ${addScore}`);
                }
                return v;
            });
            return tickets;
        });
    }
}
module.exports = TrainPricePrefer;

//# sourceMappingURL=ticket-trainPricePrefer.js.map
