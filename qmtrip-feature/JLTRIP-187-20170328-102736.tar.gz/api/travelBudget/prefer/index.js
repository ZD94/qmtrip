/**
 * Created by wlh on 16/8/11.
 */
'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const _ = require("lodash");
const Logger = require("common/logger");
const moment = require("moment");
let logger = new Logger('travel-budget');
class AbstractPrefer {
    constructor(name, options) {
        this.name = name;
        if (options) {
            for (let k in options) {
                this[k] = options[k];
            }
        }
    }
    markScore(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            logger.info(`. BEGIN ${this.name}`);
            let ret = yield this.markScoreProcess(data);
            logger.info(`. END ${this.name}`);
            return ret;
        });
    }
}
exports.AbstractPrefer = AbstractPrefer;
var DEFAULT_PREFER_CONFIG_TYPE;
(function (DEFAULT_PREFER_CONFIG_TYPE) {
    DEFAULT_PREFER_CONFIG_TYPE[DEFAULT_PREFER_CONFIG_TYPE["INTERNAL_TICKET"] = 1] = "INTERNAL_TICKET";
    DEFAULT_PREFER_CONFIG_TYPE[DEFAULT_PREFER_CONFIG_TYPE["INTERNAL_HOTEL"] = 2] = "INTERNAL_HOTEL";
    DEFAULT_PREFER_CONFIG_TYPE[DEFAULT_PREFER_CONFIG_TYPE["DOMESTIC_TICKET"] = 3] = "DOMESTIC_TICKET";
    DEFAULT_PREFER_CONFIG_TYPE[DEFAULT_PREFER_CONFIG_TYPE["DOMESTIC_HOTEL"] = 4] = "DOMESTIC_HOTEL";
})(DEFAULT_PREFER_CONFIG_TYPE = exports.DEFAULT_PREFER_CONFIG_TYPE || (exports.DEFAULT_PREFER_CONFIG_TYPE = {}));
const sysPrefer = require("./default-prefer/sys-prefer.json");
const defaultPrefer = require("./default-prefer/default-company-prefer.json");
function loadPrefers(prefers, qs, type) {
    let defaultPrefers;
    let sysPrefers;
    switch (type) {
        case DEFAULT_PREFER_CONFIG_TYPE.DOMESTIC_HOTEL:
            sysPrefers = _.cloneDeep(sysPrefer.domesticHotel);
            if (!prefers || !prefers.length) {
                prefers = _.cloneDeep(defaultPrefer.domesticHotel);
            }
            defaultPrefers = mergePrefers(sysPrefers, prefers);
            break;
        case DEFAULT_PREFER_CONFIG_TYPE.INTERNAL_TICKET:
            sysPrefers = _.cloneDeep(sysPrefer.abroadTraffic);
            if (!prefers || !prefers.length) {
                prefers = _.cloneDeep(defaultPrefer.abroadTraffic);
            }
            defaultPrefers = mergePrefers(sysPrefers, prefers);
            break;
        case DEFAULT_PREFER_CONFIG_TYPE.DOMESTIC_TICKET:
            sysPrefers = _.cloneDeep(sysPrefer.domesticTraffic);
            if (!prefers || !prefers.length) {
                prefers = _.cloneDeep(defaultPrefer.domesticTraffic);
            }
            defaultPrefers = mergePrefers(sysPrefers, prefers);
            break;
        case DEFAULT_PREFER_CONFIG_TYPE.INTERNAL_HOTEL:
            sysPrefers = _.cloneDeep(sysPrefer.abroadHotel);
            if (!prefers || !prefers.length) {
                prefers = _.cloneDeep(defaultPrefer.abroadHotel);
            }
            defaultPrefers = mergePrefers(sysPrefers, prefers);
            break;
    }
    let _prefers = JSON.stringify(defaultPrefers);
    let _compiled = _.template(_prefers, { 'imports': { 'moment': moment } });
    return JSON.parse(_compiled(qs));
}
exports.loadPrefers = loadPrefers;
function mergePrefers(prefers, newPrefers) {
    if (!newPrefers) {
        newPrefers = [];
    }
    newPrefers.forEach((prefer) => {
        prefers.push(prefer);
    });
    return prefers;
}
exports.hotelPrefers = {
    starMatch: require('./hotel-star-match'),
    blackList: require('./hotel-blacklist'),
    represent: require('./hotel-represent'),
    price: require('./hotel-price'),
    priceRange: require('./hotel-pricerange')
};
exports.ticketPrefers = {
    arrivalTime: require('./ticket-arrivaltime'),
    departTime: require('./ticket-departtime'),
    cheapSupplier: require('./ticket-cheapsupplier'),
    cabin: require('./ticket-cabin'),
    runningTimePrefer: require('./ticket-runningTimePrefer'),
    departStandardTimePrefer: require('./ticket-departStandardTimePrefer'),
    arriveStandardTimePrefer: require('./ticket-arriveStandardTimePrefer'),
    trainDurationPrefer: require('./ticket-trainDurationPrefer'),
    latestArrivalTimePrefer: require('./ticket-latestArrivalTimePrefer'),
    earliestGoBackTimePrefer: require('./ticket-earliestGoBackTimePrefer'),
    trainPricePrefer: require('./ticket-trainPricePrefer'),
    planePricePrefer: require('./ticket-planePricePrefer'),
    planeNumberPrefer: require('./ticket-planeNumberPrefer'),
    permitOnlySupplier: require('./ticket-permitOnlySupplier'),
    priorSupplier: require('./ticket-priorSupplier'),
    directArrive: require('./ticket-directArrive'),
    transitWaitDuration: require('./ticket-transitWaitDurationPrefer'),
    transitCityInChina: require("./ticket-transitCityInChinaPrefer"),
};

//# sourceMappingURL=index.js.map
