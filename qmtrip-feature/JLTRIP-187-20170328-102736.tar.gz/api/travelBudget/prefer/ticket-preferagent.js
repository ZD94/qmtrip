/**
 * Created by wlh on 16/8/23.
 */
'use strict';
const tslib_1 = require("tslib");
const index_1 = require("./index");
class AgentPrefer extends index_1.AbstractPrefer {
    constructor(name, options) {
        super(name, options);
        if (!this.expectedAgents) {
            this.expectedAgents = [];
        }
        if (!this.score) {
            this.score = 0;
        }
    }
    markScoreProcess(tickets) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            tickets = tickets.map((v) => {
                if (!v['score'])
                    v['score'] = 0;
                if (!v.reasons)
                    v.reasons = [];
                let result = false;
                self.expectedAgents.forEach((agent) => {
                    if (v.agent && agent.indexOf(v.agent) >= 0) {
                        result = true;
                        return false;
                    }
                });
                if (result) {
                    v.score += self.score;
                    v.reasons.push(`期望代理商${self.score}`);
                }
                return v;
            });
            return tickets;
        });
    }
}
module.exports = AgentPrefer;

//# sourceMappingURL=ticket-preferagent.js.map
