"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
/**
 * Created by wlh on 15/12/12.
 */
const helper_1 = require("common/api/helper");
const _types_1 = require("_types");
const tripPlan_1 = require("_types/tripPlan");
const travelPolicy_1 = require("_types/travelPolicy");
const staff_1 = require("_types/staff");
const API = require("common/api");
const validate = require("common/validate");
const language_1 = require("common/language");
const moment = require('moment');
const cache = require("common/cache");
const utils = require("common/utils");
const _ = require("lodash");
const travelbudget_1 = require("_types/travelbudget");
const index_1 = require("./strategy/index");
const prefer_1 = require("./prefer");
class ApiTravelBudget {
    static getBudgetInfo(params) {
        let accountId = params.accountId;
        if (!accountId) {
            accountId = Zone.current.get('session')["accountId"];
        }
        let key = `budgets:${accountId}:${params.id}`;
        return cache.read(key);
    }
    /**
    * @method getTravelPolicyBudget
    *
    * 获取合适差旅预算
    *
    * @param {Object} params 参数
    * @param {String} params.originPlace 出发地
    * @param {String} params.destinationPlace 目的地
    * @param {String} params.leaveDate 出发时间 YYYY-MM-DD
    * @param {String} [params.latestArriveTime] 最晚到达时间
    * @param {String} [params.leaveTime] 出发最晚到达时间 HH:mm
    * @param {String} [params.goBackDate] 返回时间(可选) YYYY-MM-DD
    * @param {String} [params.goBackTime] 返程最晚时间
    * @param {String} [params.checkInDate] 如果不传=leaveDate 入住时间
    * @param {String} [params.checkOutDate] 如果不传=goBackDate 离开时间
    * @param {String} [params.businessDistrict] 商圈ID
    * @param {Boolean} [params.isNeedHotel] 是否需要酒店
    * @param {Boolean} [params.isRoundTrip] 是否往返 [如果为true,goBackDate必须存在]
    * @param {Boolean} [params.isNeedTraffic] 是否需要交通
    * @param {Striing} [params.reason] 出差事由
    * @param {String} [params.hotelName] 住宿地标名称
    * @return {Promise} {traffic: "2000", hotel: "1500", "price": "3500"}
    */
    static getTravelPolicyBudget(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let { accountId } = Zone.current.get('session');
            let staffId = params.staffId || accountId;
            let staff = yield _types_1.Models.staff.get(staffId);
            let travelPolicy = yield staff.getTravelPolicy();
            if (!travelPolicy) {
                throw new Error(`差旅标准还未设置`);
            }
            let paramsToBudget = [];
            let destinationPlacesInfo = params.destinationPlacesInfo;
            if (destinationPlacesInfo && destinationPlacesInfo.length > 0) {
                for (let j = 0; j < destinationPlacesInfo.length; j++) {
                    let paramsItem = {};
                    for (let key in destinationPlacesInfo[j]) {
                        paramsItem[key] = destinationPlacesInfo[j][key];
                    }
                    paramsItem.staffId = params.staffId;
                    if (j == 0) {
                        if (params.originPlace) {
                            paramsItem.originPlace = params.originPlace;
                        }
                        else {
                            paramsItem.isNeedTraffic = false;
                            paramsItem.isRoundTrip = false;
                        }
                    }
                    else {
                        paramsItem.originPlace = destinationPlacesInfo[j - 1].destinationPlace;
                    }
                    paramsToBudget.push(paramsItem);
                }
            }
            let isRoundTrip = params.isRoundTrip;
            let momentDateFormat = "YYYY-MM-DD";
            let budgets = [];
            for (let i = 0; i < paramsToBudget.length; i++) {
                let { leaveDate, //离开日期
                goBackDate, //返回日期
                originPlace, //出发城市
                destinationPlace, //目的地
                checkInDate, //入住日期
                checkOutDate, //离开日期
                businessDistrict, //商圈
                earliestLeaveDateTime, //最早离开时间
                latestArrivalDateTime, //最晚到达时间
                earliestGoBackDateTime, //最早返回日期
                latestGoBackDateTime, //最晚返回日期
                isNeedHotel, //是否需要住宿
                isNeedTraffic, //是否需要交通
                subsidy, //补助信息
                hotelName //住宿地标名称
                 } = paramsToBudget[i];
                if (!Boolean(leaveDate)) {
                    throw language_1.default.ERR.LEAVE_DATE_FORMAT_ERROR();
                }
                if (!isNeedTraffic && !isNeedHotel) {
                    throw new Error("住宿和交通不能同时不需要");
                }
                //住宿需要参数
                if (isNeedHotel) {
                    if (!Boolean(checkInDate)) {
                        checkInDate = leaveDate;
                    }
                    if (!Boolean(checkOutDate)) {
                        checkOutDate = goBackDate;
                    }
                }
                //去程参数
                if (isNeedTraffic && !leaveDate) {
                    throw language_1.default.ERR.LEAVE_DATE_FORMAT_ERROR();
                }
                if (isNeedTraffic && !originPlace) {
                    throw language_1.default.ERR.CITY_NOT_EXIST();
                }
                if (!destinationPlace) {
                    throw language_1.default.ERR.CITY_NOT_EXIST();
                }
                //返程需要参数
                if (isRoundTrip) {
                    if (!Boolean(goBackDate))
                        throw language_1.default.ERR.GO_BACK_DATE_FORMAT_ERROR();
                }
                yield new Promise(function (resolve, reject) {
                    let session = { accountId: staffId };
                    Zone.current.fork({ name: "getTravelPolicy", properties: { session: session } })
                        .run(function () {
                        return tslib_1.__awaiter(this, void 0, void 0, function* () {
                            if (isNeedTraffic) {
                                try {
                                    //去程预算
                                    let budget = yield ApiTravelBudget.getTrafficBudget({
                                        originPlace: originPlace,
                                        destinationPlace: destinationPlace,
                                        leaveDate: leaveDate,
                                        earliestLeaveDateTime: earliestLeaveDateTime,
                                        latestArrivalDateTime: latestArrivalDateTime,
                                    });
                                    budget.tripType = tripPlan_1.ETripType.OUT_TRIP;
                                    budgets.push(budget);
                                }
                                catch (err) {
                                    reject(err);
                                }
                            }
                            if (isNeedTraffic && isRoundTrip && i == (paramsToBudget.length - 1)) {
                                try {
                                    let _params = {
                                        originPlace: destinationPlace,
                                        destinationPlace: paramsToBudget[0].originPlace,
                                        leaveDate: goBackDate,
                                        earliestLeaveDateTime: earliestGoBackDateTime,
                                        latestArrivalTime: latestGoBackDateTime,
                                    };
                                    let budget = yield ApiTravelBudget.getTrafficBudget(_params);
                                    budget.tripType = tripPlan_1.ETripType.BACK_TRIP;
                                    budgets.push(budget);
                                }
                                catch (err) {
                                    reject(err);
                                }
                            }
                            if (isNeedHotel) {
                                try {
                                    let budget = yield ApiTravelBudget.getHotelBudget({
                                        city: destinationPlace,
                                        businessDistrict: businessDistrict,
                                        checkInDate: leaveDate,
                                        checkOutDate: goBackDate,
                                        hotelName: hotelName
                                    });
                                    budget.tripType = tripPlan_1.ETripType.HOTEL;
                                    budgets.push(budget);
                                }
                                catch (err) {
                                    console.info(err);
                                    reject(err);
                                }
                            }
                            if (subsidy && subsidy.template) {
                                let goBackDay = moment(goBackDate).format("YYYY-MM-DD");
                                let leaveDay = moment(leaveDate).format("YYYY-MM-DD");
                                let days = moment(goBackDay).diff(moment(leaveDay), 'days');
                                days = days + 1;
                                if (!subsidy.hasFirstDaySubsidy) {
                                    days = days - 1;
                                }
                                if (!subsidy.hasLastDaySubsidy) {
                                    days = days - 1;
                                }
                                if (days > 0) {
                                    let budget = {};
                                    budget.fromDate = leaveDate;
                                    budget.endDate = goBackDate;
                                    budget.hasFirstDaySubsidy = subsidy.hasFirstDaySubsidy;
                                    budget.hasLastDaySubsidy = subsidy.hasLastDaySubsidy;
                                    budget.tripType = tripPlan_1.ETripType.SUBSIDY;
                                    budget.type = tripPlan_1.EInvoiceType.SUBSIDY;
                                    budget.price = subsidy.template.target.subsidyMoney * days;
                                    budget.duringDays = days;
                                    budget.template = { id: subsidy.template.target.id, name: subsidy.template.target.name };
                                    budgets.push(budget);
                                }
                            }
                            resolve(true);
                        });
                    });
                });
            }
            let obj = {};
            obj.budgets = budgets;
            obj.query = params;
            obj.createAt = Date.now();
            let _id = Date.now() + utils.getRndStr(6);
            let key = `budgets:${staffId}:${_id}`;
            yield cache.write(key, JSON.stringify(obj));
            return _id;
        });
    }
    /**
     * @method getHotelBudget
     *
     * 获取酒店住宿预算
     *
     * @param {Object} params
     * @param {UUID} params.accountId 账号ID
     * @param {String} params.city    城市ID
     * @param {String} params.businessDistrict 商圈ID
     * @param {Date} params.checkInDate 入住时间
     * @param {Date} params.checkOutDate 离开时间
     * @return {Promise} {prize: 1000, hotel: "酒店名称"}
     */
    static getHotelBudget(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let { city, businessDistrict, checkInDate, checkOutDate, hotelName } = params;
            if (!Boolean(city)) {
                throw language_1.default.ERR.CITY_NOT_EXIST();
            }
            if (!checkInDate) {
                throw language_1.default.ERR.CHECK_IN_DATE_FORMAT_ERROR();
            }
            if (!checkOutDate) {
                throw language_1.default.ERR.CHECK_OUT_DATE_FORMAT_ERROR();
            }
            checkOutDate = new Date(moment(checkOutDate).format('YYYY-MM-DD'));
            checkInDate = new Date(moment(checkInDate).format('YYYY-MM-DD'));
            if (checkOutDate < checkInDate) {
                throw { code: -1, msg: "离开日期大于入住日期" };
            }
            let days = moment(checkOutDate).diff(checkInDate, 'days');
            var staff = yield staff_1.Staff.getCurrent();
            if (!staff || !staff["travelPolicyId"]) {
                throw language_1.default.ERR.TRAVEL_POLICY_NOT_EXIST();
            }
            city = yield API.place.getCityInfo({ cityCode: city.id || city });
            //查询是否有协议酒店
            let accordHotel;
            try {
                accordHotel = yield API.accordHotel.getAccordHotelByCity({ cityId: city.id || city });
            }
            catch (err) {
            }
            if (accordHotel) {
                return {
                    price: accordHotel.accordPrice * days, type: tripPlan_1.EInvoiceType.HOTEL,
                    hotelName: hotelName, cityName: city.name, checkInDate: checkInDate, checkOutDate: checkOutDate
                };
            }
            //查询员工差旅标准
            let policy = yield staff.getTravelPolicy();
            let hotelStar = [travelPolicy_1.EHotelLevel.THREE_STAR];
            if (!policy) {
                throw language_1.default.ERR.TRAVEL_POLICY_NOT_EXIST();
            }
            if (city.isAbroad && (!policy.isOpenAbroad || !policy.abroadHotelLevels.length)) {
                throw language_1.default.ERR.ABROAD_TRAVEL_POLICY_NOT_EXIST();
            }
            //区分国内国外标准
            if (city.isAbroad) {
                hotelStar = policy.abroadHotelLevels;
            }
            else {
                hotelStar = policy.hotelLevels;
            }
            let gps = [];
            if (businessDistrict && /,/g.test(businessDistrict)) {
                gps = businessDistrict.split(/,/);
            }
            else {
                let obj;
                if (businessDistrict) {
                    obj = API.place.getCityInfo({ cityCode: businessDistrict });
                }
                if (!obj || !obj.latitude || !obj.longitude) {
                    obj = city;
                }
                gps = [obj.latitude, obj.longitude];
            }
            let qs = {};
            let query = {
                star: hotelStar,
                city: city,
                latitude: gps[0],
                longitude: gps[1],
                businessDistrict: businessDistrict,
                checkInDate: checkInDate,
                checkOutDate: checkOutDate,
                isAbroad: city.isAbroad,
                hotelName: hotelName
            };
            let budgetConfig = staff.company.budgetConfig;
            if (!budgetConfig) {
                budgetConfig = {};
            }
            let key = prefer_1.DEFAULT_PREFER_CONFIG_TYPE.DOMESTIC_HOTEL;
            if (city.isAbroad) {
                key = prefer_1.DEFAULT_PREFER_CONFIG_TYPE.INTERNAL_HOTEL;
            }
            let prefers = prefer_1.loadPrefers(budgetConfig.hotel, { local: query }, key);
            qs.prefers = prefers;
            qs.query = query;
            let hotels = yield API.hotel.search_hotels(query);
            let strategy = yield index_1.HotelBudgetStrategyFactory.getStrategy(qs, { isRecord: true });
            let budget = yield strategy.getResult(hotels);
            budget.type = tripPlan_1.EInvoiceType.HOTEL;
            return budget;
        });
    }
    /**
     * @method getTrafficBudget
     * 获取交通预算
     *
     * @param {String} params.originPlace 出发地
     * @param {String} params.destinationPlace 目的地
     * @param {String} params.leaveDate 出发时间 YYYY-MM-DD
     * @param {String} params.leaveTime 最晚到达时间 HH:mm
     * @return {Promise} {price: "1000"}
     */
    static getTrafficBudget(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let { originPlace, destinationPlace, leaveDate, latestArrivalDateTime, earliestLeaveDateTime } = params;
            if (!destinationPlace) {
                throw new Error(JSON.stringify({ code: -1, msg: "目的地城市信息不存在" }));
            }
            if (!originPlace) {
                throw new Error(JSON.stringify({ code: -1, msg: "出发城市信息不存在" }));
            }
            if (!leaveDate) {
                throw { code: -1, msg: "出发时间不存在" };
            }
            //查询员工信息
            let staff = yield staff_1.Staff.getCurrent();
            if (!staff || !staff['travelPolicyId']) {
                throw language_1.default.ERR.TRAVEL_POLICY_NOT_EXIST();
            }
            //查询员工差旅标准
            let policy = yield staff.getTravelPolicy();
            if (!policy) {
                throw language_1.default.ERR.TRAVEL_POLICY_NOT_EXIST();
            }
            let isAbroad = false;
            let m_originCity = yield API.place.getCityInfo({ cityCode: originPlace.id || originPlace });
            let m_destination = yield API.place.getCityInfo({ cityCode: destinationPlace.id || destinationPlace });
            //转换成当地时间
            if (!latestArrivalDateTime) {
                params.latestArrivalDateTime = undefined;
            }
            else {
                let endFix = getTimezoneStr(m_destination.offsetUtc);
                params.latestArrivalDateTime = new Date(moment(latestArrivalDateTime).format(`YYYY-MM-DD HH:mm:ss`) + endFix);
            }
            if (!earliestLeaveDateTime) {
                params.earliestLeaveDateTime = undefined;
            }
            else {
                let endFix = getTimezoneStr(m_originCity.offsetUtc);
                params.earliestLeaveDateTime = new Date(moment(earliestLeaveDateTime).format(`YYYY-MM-DD HH:mm:ss`) + endFix);
            }
            if (m_destination.isAbroad || m_originCity.isAbroad) {
                isAbroad = true;
            }
            let cabins;
            if (isAbroad && (!policy.isOpenAbroad || !policy.abroadPlaneLevels.length)) {
                throw language_1.default.ERR.ABROAD_TRAVEL_POLICY_NOT_EXIST();
            }
            //区分国内国外标准
            if (isAbroad) {
                cabins = policy.abroadPlaneLevels;
            }
            else {
                cabins = policy.planeLevels;
            }
            if (!cabins || !cabins.length) {
                cabins = [travelPolicy_1.EPlaneLevel.ECONOMY, travelPolicy_1.EPlaneLevel.BUSINESS, travelPolicy_1.EPlaneLevel.FIRST];
            }
            let trainCabins = policy.trainLevels;
            if (!trainCabins || !trainCabins.length) {
                trainCabins = [];
            }
            let flightTickets = [];
            if (m_originCity && m_destination) {
                flightTickets = yield API.flight.search_ticket({
                    originPlace: m_originCity,
                    destination: m_destination,
                    leaveDate: leaveDate,
                    cabin: cabins,
                    isAbroad: isAbroad,
                });
                if (!flightTickets) {
                    flightTickets = [];
                }
            }
            let trainTickets = [];
            if (!isAbroad) {
                trainTickets = yield API.train.search_ticket({
                    originPlace: m_originCity,
                    destination: m_destination,
                    leaveDate: leaveDate,
                    cabin: trainCabins
                });
                if (!trainTickets) {
                    trainTickets = [];
                }
            }
            let preferConfig = staff.company.budgetConfig;
            let qs = {};
            params['expectTrainCabins'] = trainCabins;
            params['expectFlightCabins'] = cabins;
            let defaults = [];
            if (isAbroad) {
                defaults = prefer_1.loadPrefers(preferConfig.abroadTraffic, { local: params }, prefer_1.DEFAULT_PREFER_CONFIG_TYPE.INTERNAL_TICKET);
                qs.prefers = defaults;
            }
            else {
                defaults = prefer_1.loadPrefers(preferConfig.traffic, { local: params }, prefer_1.DEFAULT_PREFER_CONFIG_TYPE.DOMESTIC_TICKET);
                qs.prefers = defaults;
            }
            if (!qs.prefers) {
                qs.prefers = [];
            }
            qs.query = params;
            qs.query.originPlace = m_originCity;
            qs.query.destination = m_destination;
            let tickets = _.concat(flightTickets, trainTickets);
            let strategy = yield index_1.TrafficBudgetStrategyFactory.getStrategy(qs, { isRecord: true });
            let result = yield strategy.getResult(tickets);
            console.log("result: ", result);
            result.cabinClass = result.cabin;
            result.originPlace = m_originCity;
            result.destination = m_destination;
            if (result.type == travelbudget_1.TRAFFIC.FLIGHT) {
                let fullPriceObj = yield API.place.getFlightFullPrice({
                    originPlace: m_originCity.id,
                    destination: m_destination.id,
                });
                result.fullPrice = fullPriceObj ? fullPriceObj.EPrice : 0;
            }
            return result;
        });
    }
    static reportBudgetError(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let { accountId } = Zone.current.get('session');
            let { budgetId } = params;
            //let staff = await Staff.getCurrent();
            let content = yield ApiTravelBudget.getBudgetInfo({ id: budgetId, accountId: accountId });
            let budgets = content.budgets;
            let ps = budgets.map((budget) => tslib_1.__awaiter(this, void 0, void 0, function* () {
                if (!budget.id) {
                    return true;
                }
                let log = yield _types_1.Models.travelBudgetLog.get(budget.id);
                log.status = -1;
                return log.save();
            }));
            yield Promise.all(ps);
            return true;
        });
    }
    static __initHttpApp(app) {
        function _auth_middleware(req, res, next) {
            let key = req.query.key;
            if (!key || key != 'jingli2016') {
                return res.send(403);
            }
            next();
        }
        app.get("/api/budgets", _auth_middleware, function (req, res, next) {
            let { p, pz } = req.query;
            if (!p || !/^\d+$/.test(p) || p < 1) {
                p = 1;
            }
            if (!pz || !/^\d+$/.test(pz) || pz < 1) {
                pz = 20;
            }
            let offset = (p - 1) * pz;
            _types_1.Models.travelBudgetLog.find({ where: {}, limit: pz, offset: offset, order: 'created_at desc' })
                .then((travelBudgetLogs) => {
                let datas = travelBudgetLogs.map((v) => {
                    return v.target;
                });
                res.header('Access-Control-Allow-Origin', '*');
                res.json(datas);
            })
                .catch(next);
        });
        app.post('/api/budgets', _auth_middleware, function (req, res, next) {
            let { query, prefers, policy, originData, type } = req.body;
            let qs = {
                policy: policy,
                prefers: JSON.parse(prefers),
                query: JSON.parse(query),
            };
            let factory = (type == 1) ? index_1.TrafficBudgetStrategyFactory : index_1.HotelBudgetStrategyFactory;
            factory.getStrategy(qs, { isRecord: false })
                .then((strategy) => {
                return strategy.getResult(JSON.parse(originData), true);
            })
                .then((result) => {
                res.header('Access-Control-Allow-Origin', '*');
                res.json(result);
            })
                .catch(next);
        });
    }
}
tslib_1.__decorate([
    helper_1.clientExport
], ApiTravelBudget, "getBudgetInfo", null);
tslib_1.__decorate([
    helper_1.clientExport
], ApiTravelBudget, "getTravelPolicyBudget", null);
tslib_1.__decorate([
    helper_1.clientExport
], ApiTravelBudget, "getHotelBudget", null);
tslib_1.__decorate([
    helper_1.clientExport
], ApiTravelBudget, "getTrafficBudget", null);
tslib_1.__decorate([
    helper_1.clientExport
], ApiTravelBudget, "reportBudgetError", null);
exports.default = ApiTravelBudget;
function getTimezoneStr(seconds) {
    const HOUR = 60 * 60;
    const MINUTE = 60;
    let hours = seconds / HOUR;
    if (hours < 0) {
        hours = Math.ceil(hours);
    }
    else {
        hours = Math.floor(hours);
    }
    let minute = (seconds - hours * HOUR) / MINUTE;
    if (minute < 0) {
        minute = Math.ceil(minute);
    }
    else {
        minute = Math.floor(minute);
    }
    let ret = 'GMT';
    if (hours < 0) {
        ret += '-';
        if (hours > -10) {
            ret += '0';
        }
        hours = -hours;
        ret += hours;
    }
    else {
        ret += '+';
        if (hours < 10) {
            ret += '0';
        }
        ret += hours;
    }
    if (minute < 0) {
        minute = -minute;
    }
    if (minute < 10) {
        ret += '0';
    }
    ret += minute;
    return " " + ret;
}

//# sourceMappingURL=index.js.map
