/**
 * Created by wlh on 2017/2/9.
 */
'use strict';

//# sourceMappingURL=hotel-price.test.js.map
