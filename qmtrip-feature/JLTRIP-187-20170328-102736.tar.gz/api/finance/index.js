/**
 * Created by wlh on 2016/10/11.
 */
'use strict';
const tslib_1 = require("tslib");
const helper_1 = require("common/api/helper");
const index_1 = require("_types/index");
const L = require("common/language");
class FinanceModule {
    static getTripPlan(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let { tripPlanId, code } = params;
            if (!isValidCode(tripPlanId, code)) {
                throw L.ERR.PERMISSION_DENY();
            }
            return yield index_1.Models.tripPlan.get(tripPlanId);
        });
    }
    static getTripDetails(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let { tripPlanId, code } = params;
            if (!isValidCode(tripPlanId, code)) {
                throw L.ERR.PERMISSION_DENY();
            }
            let tripPlan = yield index_1.Models.tripPlan.get(tripPlanId);
            return index_1.Models.tripDetail.find({
                where: { tripPlanId: tripPlan.id },
                order: [["created_at", "asc"]]
            });
        });
    }
    static getTripPlanStaff(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let { tripPlanId, code } = params;
            if (!isValidCode(tripPlanId, code)) {
                throw L.ERR.PERMISSION_DENY();
            }
            let tripPlan = yield index_1.Models.tripPlan.get(tripPlanId);
            let staff = yield index_1.Models.staff.get(tripPlan.account.id);
            return { id: staff.id, name: staff.name, mobile: staff.mobile, email: staff.email };
        });
    }
    static getTripDetail(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let { tripPlanId, tripDetailId, code } = params;
            if (!isValidCode(tripPlanId, code)) {
                throw L.ERR.PERMISSION_DENY();
            }
            let tripDetail = yield index_1.Models.tripDetail.get(tripDetailId, { notRetChild: true });
            if (tripDetail.tripPlanId != tripPlanId) {
                throw L.ERR.PERMISSION_DENY();
            }
            return tripDetail;
        });
    }
}
FinanceModule.__public = true;
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["tripPlanId", "code"])
], FinanceModule, "getTripPlan", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['tripPlanId', 'code'])
], FinanceModule, "getTripDetails", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['tripPlanId', 'code'])
], FinanceModule, "getTripPlanStaff", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['tripPlanId', 'code', 'tripDetailId'])
], FinanceModule, "getTripDetail", null);
function isValidCode(tripPlanId, code) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        let rows = yield index_1.Models.financeCheckCode.find({ where: { tripPlanId: tripPlanId, code: code, isValid: true } });
        if (rows && rows.length)
            return true;
        return false;
    });
}
module.exports = FinanceModule;

//# sourceMappingURL=index.js.map
