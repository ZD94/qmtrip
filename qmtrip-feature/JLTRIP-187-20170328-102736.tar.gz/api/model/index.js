"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const language_1 = require("common/language");
const _types_1 = require("_types");
const helper_1 = require("common/api/helper");
class ModelForClient {
    static create(modelType, obj) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let model = _types_1.Models[modelType];
            if (!model)
                throw language_1.default.ERR.INVALID_ARGUMENT('modelType');
            return model.create(obj);
        });
    }
    static get(modelType, id, options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let model = _types_1.Models[modelType];
            if (!model)
                throw language_1.default.ERR.INVALID_ARGUMENT('modelType');
            return model.get(id, options);
        });
    }
    static find(modelType, options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let model = _types_1.Models[modelType];
            if (!model)
                throw language_1.default.ERR.INVALID_ARGUMENT('modelType');
            return model.$find(options);
        });
    }
    static update(modelType, id, props, options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let model = _types_1.Models[modelType];
            if (!model)
                throw language_1.default.ERR.INVALID_ARGUMENT('modelType');
            let obj = yield model.get(id);
            if (!obj)
                throw language_1.default.ERR.NOT_FOUND('id');
            for (let key in props) {
                obj[key] = props[key];
            }
            return obj.save();
        });
    }
    static destory(modelType, id, options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let model = _types_1.Models[modelType];
            if (!model)
                throw language_1.default.ERR.INVALID_ARGUMENT('modelType');
            let obj = yield model.get(id);
            if (!obj)
                throw language_1.default.ERR.NOT_FOUND('id');
            return obj.destroy();
        });
    }
    static call(modelType, method, id, args) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let model = _types_1.Models[modelType];
            if (!model)
                throw language_1.default.ERR.INVALID_ARGUMENT('modelType');
            let obj = yield model.get(id);
            if (!obj)
                throw language_1.default.ERR.NOT_FOUND('id');
            let func = obj[method];
            if (typeof func !== 'function')
                throw language_1.default.ERR.INVALID_ARGUMENT('method');
            return func.apply(obj, args);
        });
    }
}
tslib_1.__decorate([
    helper_1.clientExport
], ModelForClient, "create", null);
tslib_1.__decorate([
    helper_1.clientExport
], ModelForClient, "get", null);
tslib_1.__decorate([
    helper_1.clientExport
], ModelForClient, "find", null);
tslib_1.__decorate([
    helper_1.clientExport
], ModelForClient, "update", null);
tslib_1.__decorate([
    helper_1.clientExport
], ModelForClient, "destory", null);
tslib_1.__decorate([
    helper_1.clientExport
], ModelForClient, "call", null);
exports.default = ModelForClient;

//# sourceMappingURL=index.js.map
