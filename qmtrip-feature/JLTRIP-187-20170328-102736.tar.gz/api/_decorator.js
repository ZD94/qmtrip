"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const index_1 = require("../common/model/index");
const staff_1 = require("_types/staff");
const agency_1 = require("_types/agency");
const _types_1 = require("_types");
/**
 * Created by wlh on 16/5/16.
 */
const API = require("common/api");
const _ = require("lodash");
const language_1 = require("common/language");
const Models = require("_types").Models;
function requirePermit(permits, type) {
    return function (target, key, desc) {
        let fn = desc.value;
        desc.value = function (...args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                //let context = Zone.current.get('context');
                let session = index_1.getSession();
                let account = Models.account.get(session.accountId);
                if (!account)
                    throw language_1.default.ERR.PERMISSION_DENY();
                yield API.permit.checkPermission({ accountId: session.accountId, permissions: permits, type: account.type });
                return fn.apply(this, args);
            });
        };
        return desc;
    };
}
exports.requirePermit = requirePermit;
//筛选返回结果
function filterResultColumn(columns) {
    return function (target, key, desc) {
        let fn = desc.value;
        desc.value = function (...args) {
            let self = this;
            return fn.apply(self, args)
                .then(function (result) {
                for (let k in result) {
                    if (columns.indexOf(k) < 0) {
                        delete result[k];
                    }
                }
                return result;
            });
        };
        return desc;
    };
}
exports.filterResultColumn = filterResultColumn;
//追加函数参数
function addFuncParams(params) {
    return function (target, key, desc) {
        let fn = desc.value;
        desc.value = function (...args) {
            let self = this;
            for (let key of params) {
                args[0][key] = params[key];
            }
            return fn.apply(self, args);
        };
        return desc;
    };
}
exports.addFuncParams = addFuncParams;
/**
 * 判断不为空
 * @param params
 * @constructor
 */
function modelNotNull(modname, keyName) {
    return function (target, key, desc) {
        let fn = desc.value;
        desc.value = function (...args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let self = this;
                keyName = keyName || 'id';
                let entity = yield Models[modname].get(args[0][keyName]);
                if (!entity) {
                    throw language_1.default.ERR.NOT_FOUND();
                }
                return fn.apply(self, args);
            });
        };
        return desc;
    };
}
exports.modelNotNull = modelNotNull;
function conditionDecorator(checkFnList) {
    return function (target, key, desc) {
        let fn = desc.value;
        desc.value = function (...args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                //在这里才能拿到参数
                let self = this;
                let thenFn;
                for (let checkFn of checkFnList) {
                    let ret = yield checkFn.if(fn, self, args);
                    //如果返回true,执行then函数
                    if (!!ret) {
                        thenFn = checkFn.then;
                        if (!thenFn) {
                            //如果then不存在,直接处理原函数
                            return fn.apply(self, args);
                        }
                        //判断完if后,将desc还原为原来的函数,否则将引起死循环
                        desc.value = fn;
                        //self作用于也要一并传过去
                        return thenFn(target, key, desc).value.apply(self, args);
                    }
                }
                throw language_1.default.ERR.PERMISSION_DENY();
            });
        };
        return desc;
    };
}
exports.conditionDecorator = conditionDecorator;
exports.condition = {
    isMySelf: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let session = index_1.getSession();
                let id = _.get(args, idpath);
                return id && session.accountId && id == session.accountId;
            });
        };
    },
    isMyCompany: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let id = _.get(args, idpath);
                let staff = yield staff_1.Staff.getCurrent();
                return id && staff && staff.company && staff.company.id == id;
            });
        };
    },
    isMyCompanyAgency: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let id = _.get(args, idpath);
                let staff = yield staff_1.Staff.getCurrent();
                return id && staff && staff.company && staff.company["agencyId"] == id;
            });
        };
    },
    isMyAgency: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let id = _.get(args, idpath);
                let agencyUser = yield agency_1.AgencyUser.getCurrent();
                return id && agencyUser && agencyUser.agency.id == id;
            });
        };
    },
    isStaffsAgency: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let id = _.get(args, idpath);
                let staff = yield Models.staff.get(id);
                // let company = staff.company;
                if (staff && staff["companyId"]) {
                    let company = yield Models.company.get(staff["companyId"]);
                    let agencyUser = yield agency_1.AgencyUser.getCurrent();
                    return staff && company && agencyUser && agencyUser["agencyId"] == company["agencyId"];
                }
                return false;
            });
        };
    },
    isSameCompany: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let id = _.get(args, idpath);
                let staff = yield staff_1.Staff.getCurrent();
                let other = yield Models.staff.get(id);
                return id && staff && other && staff["companyId"] == other["companyId"];
            });
        };
    },
    isSameAgency: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let id = _.get(args, idpath);
                let user = yield agency_1.AgencyUser.getCurrent();
                let other = yield Models.agencyUser.get(id);
                if (!other) {
                    throw language_1.default.ERR.AGENCY_USER_NOT_EXIST();
                }
                return id && user && other && user["agencyId"] == other.agencyId;
            });
        };
    },
    isTravelPolicyAdminOrOwner: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let id = _.get(args, idpath);
                if (id == 'dc6f4e50-a9f2-11e5-a9a3-9ff0188d1c1a') {
                    return true;
                }
                else {
                    let staff = yield staff_1.Staff.getCurrent();
                    let tp = yield Models.travelPolicy.get(id);
                    return id && staff && tp && tp["companyId"] == staff["companyId"] && (staff["roleId"] == staff_1.EStaffRole.ADMIN || staff["roleId"] == staff_1.EStaffRole.OWNER);
                }
            });
        };
    },
    isSupplierAdminOrOwner: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let id = _.get(args, idpath);
                let staff = yield staff_1.Staff.getCurrent();
                let sp = yield Models.supplier.get(id);
                return id && staff && sp && sp["companyId"] == staff["companyId"] && (staff["roleId"] == staff_1.EStaffRole.ADMIN || staff["roleId"] == staff_1.EStaffRole.OWNER);
            });
        };
    },
    isStaffSupplierInfoOwner: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let id = _.get(args, idpath);
                let staff = yield staff_1.Staff.getCurrent();
                let sp = yield Models.staffSupplierInfo.get(id);
                return id && staff && sp && sp["staffId"] == staff["id"];
            });
        };
    },
    isAccordHotelAdminOrOwner: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let id = _.get(args, idpath);
                let staff = yield staff_1.Staff.getCurrent();
                let ah = yield Models.accordHotel.get(id);
                return id && staff && ah && ah["companyId"] == staff["companyId"] && (staff["roleId"] == staff_1.EStaffRole.ADMIN || staff["roleId"] == staff_1.EStaffRole.OWNER);
            });
        };
    },
    isSelfTravelPolicy: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let id = _.get(args, idpath);
                let staff = yield staff_1.Staff.getCurrent();
                return id && staff && (staff["travelPolicyId"] == id || !staff["travelPolicyId"]);
            });
        };
    },
    isTravelPolicyCompany: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let id = _.get(args, idpath);
                let tp = yield Models.travelPolicy.get(id);
                let staff = yield staff_1.Staff.getCurrent();
                return tp && staff && staff["companyId"] == tp["companyId"];
            });
        };
    },
    isTravelPolicyAgency: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let id = _.get(args, idpath);
                let user = yield agency_1.AgencyUser.getCurrent();
                let tp = yield Models.travelPolicy.get(id);
                let company = yield Models.company.get(tp["companyId"]); //此处为什么不能用tp.company
                return id && user && company && user["agencyId"] == company["agencyId"];
            });
        };
    },
    isAccordHotelAgency: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let id = _.get(args, idpath);
                let user = yield agency_1.AgencyUser.getCurrent();
                let ah = yield Models.accordHotel.get(id);
                let company = yield Models.company.get(ah["companyId"]);
                return id && user && company && user["agencyId"] == company["agencyId"];
            });
        };
    },
    isDepartmentAdminOrOwner: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let id = _.get(args, idpath);
                let staff = yield staff_1.Staff.getCurrent();
                let dept = yield Models.department.get(id);
                return id && staff && dept && dept["companyId"] == staff["companyId"] && (staff["roleId"] == staff_1.EStaffRole.ADMIN || staff["roleId"] == staff_1.EStaffRole.OWNER);
            });
        };
    },
    isDepartmentCompany: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let id = _.get(args, idpath);
                let staff = yield staff_1.Staff.getCurrent();
                let dept = yield Models.department.get(id);
                return id && staff && dept && dept["companyId"] == staff["companyId"];
            });
        };
    },
    isSelfDepartment: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let id = _.get(args, idpath);
                let staff = yield staff_1.Staff.getCurrent();
                return id && staff && (staff["departmentId"] == id || !staff["departmentId"]);
            });
        };
    },
    isDepartmentAgency: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let id = _.get(args, idpath);
                let user = yield agency_1.AgencyUser.getCurrent();
                let dept = yield Models.department.get(id);
                let company = yield Models.company.get(dept["companyId"]);
                return id && user && company && user["agencyId"] == company["agencyId"];
            });
        };
    },
    isSelfLink: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let id = _.get(args, idpath);
                let staff = yield staff_1.Staff.getCurrent();
                let link = yield Models.invitedLink.get(id);
                return link && staff && (link["staffId"] == staff.id);
            });
        };
    },
    isCompanyAgency: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let id = _.get(args, idpath);
                let user = yield agency_1.AgencyUser.getCurrent();
                let company = yield Models.company.get(id);
                return id && user && company && user["agencyId"] == company["agencyId"];
            });
        };
    },
    isCompanyStaff: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let companyId = _.get(args, idpath);
                let staff = yield staff_1.Staff.getCurrent();
                return companyId && staff && staff["companyId"] == companyId;
            });
        };
    },
    isCompanyAdminOrOwner: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let companyId = _.get(args, idpath);
                let staff = yield staff_1.Staff.getCurrent();
                if (companyId) {
                    let company = yield Models.company.get(companyId);
                    return companyId && staff && company && staff["companyId"] == company["id"] && (staff["roleId"] == staff_1.EStaffRole.ADMIN || staff["roleId"] == staff_1.EStaffRole.OWNER);
                }
                else {
                    return staff && staff.company && (staff["roleId"] == staff_1.EStaffRole.ADMIN || staff["roleId"] == staff_1.EStaffRole.OWNER);
                }
            });
        };
    },
    isCompanyDepartment: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let parentId = _.get(args, idpath);
                let department = yield Models.department.get(parentId);
                let staff = yield staff_1.Staff.getCurrent();
                let company = staff.company;
                return staff && company && company.id == department.companyId;
            });
        };
    },
    isMyTripPlan: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let id = _.get(args, idpath);
                let staff = yield staff_1.Staff.getCurrent();
                let tripPlan = yield Models.tripPlan.get(id);
                return id && staff && tripPlan && staff.id == tripPlan.accountId;
            });
        };
    },
    isAgencyTripPlan: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let id = _.get(args, idpath);
                let user = yield agency_1.AgencyUser.getCurrent();
                let tripPlan = yield Models.tripPlan.get(id);
                if (!user) {
                    throw language_1.default.ERR.AGENCY_USER_NOT_EXIST();
                }
                if (!tripPlan) {
                    throw language_1.default.ERR.TRIP_PLAN_NOT_EXIST();
                }
                let company = yield tripPlan.getCompany();
                return id && user && tripPlan && user.agency.id == company['agencyId'];
            });
        };
    },
    isAgencyTripDetail: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let id = _.get(args, idpath);
                let user = yield agency_1.AgencyUser.getCurrent();
                let tripDetail = yield Models.tripDetail.get(id);
                if (!tripDetail) {
                    throw language_1.default.ERR.TRIP_PLAN_NOT_EXIST();
                }
                let tripPlan = tripDetail.tripPlan;
                if (!user) {
                    throw language_1.default.ERR.AGENCY_USER_NOT_EXIST();
                }
                let company = yield tripPlan.getCompany();
                return id && user && tripPlan && user.agency.id == company['agencyId'];
            });
        };
    },
    canGetTripPlan: function (idpath) {
        return function (fn, self, args) {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                let id = _.get(args, idpath);
                let session = Zone.current.get('session');
                if (!session || !session.accountId) {
                    throw language_1.default.ERR.PERMISSION_DENY();
                }
                let account = yield Models.account.get(session.accountId);
                let tripPlan = yield Models.tripPlan.get(id);
                let acc_type = account.type;
                if (acc_type == _types_1.EAccountType.STAFF) {
                    let staff = yield Models.staff.get(account.id);
                    return staff.roleId == staff_1.EStaffRole.ADMIN || staff.roleId == staff_1.EStaffRole.OWNER || tripPlan.accountId == account.id || tripPlan.auditUser == account.id;
                }
                else if (acc_type == _types_1.EAccountType.AGENCY) {
                    let user = yield agency_1.AgencyUser.getCurrent();
                    let company = yield tripPlan.getCompany();
                    let agency = yield company.getAgency();
                    if (!agency) {
                        return true;
                    }
                    return agency.id == user.agency.id;
                }
                else {
                    throw language_1.default.ERR.PERMISSION_DENY();
                }
            });
        };
    }
};

//# sourceMappingURL=_decorator.js.map
