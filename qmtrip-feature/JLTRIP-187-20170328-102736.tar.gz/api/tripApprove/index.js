/**
 * Created by wlh on 2016/11/14.
 */
'use strict';
const tslib_1 = require("tslib");
const helper_1 = require("common/api/helper");
const _decorator_1 = require("../_decorator");
const index_1 = require("_types/index");
const tripPlan_1 = require("_types/tripPlan/tripPlan");
const moment = require("moment/moment");
const staff_1 = require("_types/staff/staff");
const index_2 = require("libs/oa/index");
const TripPlanModule = require("../tripPlan/index");
let systemNoticeEmails = require('config/config').system_notice_emails;
const L = require('common/language');
var API = require('common/api');
var config = require("config");
const _ = require("lodash");
const notice_1 = require("_types/notice/notice");
class TripApproveModule {
    static getDetailsFromApprove(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let approve = yield index_1.Models.tripApprove.get(params.approveId);
            let account = approve.account;
            let budgets = approve.budgetInfo;
            return budgets.map(function (budget) {
                if (typeof budget == 'string') {
                    budget = JSON.parse(budget);
                }
                let tripType = budget.tripType;
                let price = Number(budget.price);
                let detail;
                let data = {};
                switch (tripType) {
                    case tripPlan_1.ETripType.OUT_TRIP:
                        detail = index_1.Models.tripDetailTraffic.create(data);
                        detail.deptCity = budget.originPlace.id;
                        detail.arrivalCity = budget.destination.id;
                        detail.deptDateTime = budget.leaveDate;
                        // detail.arrivalDateTime = budget.arrivalDateTime;
                        detail.cabin = budget.cabinClass;
                        break;
                    case tripPlan_1.ETripType.BACK_TRIP:
                        detail = index_1.Models.tripDetailTraffic.create(data);
                        detail.deptCity = budget.originPlace.id;
                        detail.arrivalCity = budget.destination.id;
                        detail.deptDateTime = budget.leaveDate;
                        // detail.arrivalDateTime = budget.arrivalDateTime;
                        detail.cabin = budget.cabinClass;
                        break;
                    case tripPlan_1.ETripType.HOTEL:
                        detail = index_1.Models.tripDetailHotel.create(data);
                        detail.type = tripPlan_1.ETripType.HOTEL;
                        detail.city = budget.cityName;
                        // detail.position = budget.businessDistrict;
                        detail.placeName = budget.hotelName;
                        detail.checkInDate = budget.checkInDate || approve.startAt;
                        detail.checkOutDate = budget.checkOutDate || approve.backAt;
                        break;
                    case tripPlan_1.ETripType.SUBSIDY:
                        detail = index_1.Models.tripDetailSubsidy.create(data);
                        detail.type = tripPlan_1.ETripType.SUBSIDY;
                        // detail.deptCity = approve.deptCityCode;
                        // detail.arrivalCity = approve.arrivalCityCode;
                        detail.startDateTime = budget.fromDate;
                        detail.endDateTime = budget.endDate;
                        detail.hasFirstDaySubsidy = budget.hasFirstDaySubsidy || true;
                        detail.hasLastDaySubsidy = budget.hasLastDaySubsidy || true;
                        detail.expenditure = budget.price;
                        detail.status = tripPlan_1.EPlanStatus.COMPLETE;
                        break;
                    case tripPlan_1.ETripType.SPECIAL_APPROVE:
                        detail = index_1.Models.tripDetailSpecial.create(data);
                        detail.type = tripPlan_1.ETripType.SPECIAL_APPROVE;
                        detail.deptCity = approve.deptCityCode;
                        detail.arrivalCity = approve.arrivalCityCode;
                        detail.startDateTime = approve.startAt;
                        detail.endDateTime = approve.backAt;
                        break;
                    default:
                        throw new Error("not support tripDetail type!");
                }
                detail.type = tripType;
                detail.budget = price;
                detail.accountId = account.id;
                detail.tripPlanId = approve.id;
                return detail;
            });
        });
    }
    static sendTripApproveNoticeToSystem(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let tripApprove = yield index_1.Models.tripApprove.get(params.approveId);
            let staff = tripApprove.account;
            let company = staff.company;
            if (company.name != "鲸力智享") {
                let details = yield TripApproveModule.getDetailsFromApprove({ approveId: tripApprove.id });
                let { go, back, hotel, subsidy } = yield TripPlanModule.getEmailInfoFromDetails(details);
                let timeFormat = 'YYYY-MM-DD HH:mm:ss';
                let values = {
                    time: moment(tripApprove.createdAt).format(timeFormat),
                    projectName: tripApprove.title,
                    goTrafficBudget: go,
                    backTrafficBudget: back,
                    hotelBudget: hotel,
                    otherBudget: subsidy,
                    totalBudget: '￥' + tripApprove.budget,
                    userName: staff.name,
                    email: staff.email,
                    companyName: staff.company.name,
                };
                try {
                    yield Promise.all(systemNoticeEmails.map(function (s) {
                        return tslib_1.__awaiter(this, void 0, void 0, function* () {
                            values.name = s.name;
                            try {
                                yield API.notify.submitNotify({
                                    key: 'qm_notify_system_new_travelbudget',
                                    email: s.email,
                                    values: values
                                });
                            }
                            catch (err) {
                                console.error(err);
                            }
                        });
                    }));
                }
                catch (err) {
                    console.error('发送系统通知失败', err);
                }
            }
            return true;
        });
    }
    static sendTripApproveNotice(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let tripApprove = yield index_1.Models.tripApprove.get(params.approveId);
            let staff = tripApprove.account;
            let company = staff.company;
            let nextApprove = params.nextApprove || false;
            let details = yield TripApproveModule.getDetailsFromApprove({ approveId: tripApprove.id });
            let { go, back, hotel, subsidy } = yield TripPlanModule.getEmailInfoFromDetails(details);
            let timeFormat = 'YYYY-MM-DD HH:mm:ss';
            //给员工发送邮件
            let self_url = `${config.host}/index.html#/trip-approval/detail?approveId=${tripApprove.id}`;
            let appMessageUrl = `#/trip-approval/detail?approveId=${tripApprove.id}`;
            let openid = yield API.auth.getOpenIdByAccount({ accountId: staff.id });
            let values = {
                staffName: staff.name,
                time: moment(tripApprove.createdAt).format(timeFormat),
                projectName: tripApprove.title,
                goTrafficBudget: go,
                backTrafficBudget: back,
                hotelBudget: hotel,
                otherBudget: subsidy,
                totalBudget: '￥' + tripApprove.budget,
                url: self_url,
                detailUrl: self_url,
                appMessageUrl: appMessageUrl,
                startAt: moment(tripApprove.startAt).format('MM.DD'),
                backAt: moment(tripApprove.backAt).format('MM.DD'),
                deptCity: tripApprove.deptCity,
                arrivalCity: tripApprove.arrivalCity
            };
            if (!nextApprove) {
                try {
                    values.noticeType = notice_1.ENoticeType.SYSTEM_NOTICE;
                    //给员工自己发送通知
                    yield API.notify.submitNotify({
                        key: 'qm_notify_self_travelbudget',
                        accountId: staff.id,
                        values: values
                    });
                }
                catch (err) {
                    console.error(`发送通知失败`, err);
                }
                try {
                    yield API.ddtalk.sendLinkMsg({ accountId: staff.id, text: `您的出差申请已经生成`, url: self_url });
                }
                catch (err) {
                    console.error(`发送钉钉消息失败`, err);
                }
            }
            if (company.isApproveOpen) {
                //给审核人发审核邮件
                let approveUser = yield index_1.Models.staff.get(tripApprove['approveUserId']);
                let approve_url = `${config.host}/index.html#/trip-approval/detail?approveId=${tripApprove.id}`;
                let appMessageUrl = `#/trip-approval/detail?approveId=${tripApprove.id}`;
                let approve_values = _.cloneDeep(values);
                let shortUrl = approve_url;
                try {
                    shortUrl = yield API.wechat.shorturl({ longurl: approve_url });
                }
                catch (err) {
                    console.warn(`转换短链接失败`, err);
                }
                let openId = yield API.auth.getOpenIdByAccount({ accountId: approveUser.id });
                approve_values.managerName = approveUser.name;
                approve_values.username = staff.name;
                approve_values.email = staff.email;
                approve_values.url = shortUrl;
                approve_values.detailUrl = shortUrl;
                approve_values.appMessageUrl = appMessageUrl;
                approve_values.name = staff.name;
                approve_values.destination = tripApprove.arrivalCity;
                approve_values.startDate = moment(tripApprove.startAt).format('YYYY.MM.DD');
                if (openId) {
                    approve_values.approveUser = approveUser.name;
                    approve_values.content = `员工${staff.name}${moment(tripApprove.startAt).format('YYYY-MM-DD')}到${tripApprove.arrivalCity}的出差计划已经发送给您，预算：￥${tripApprove.budget}，等待您审批！`;
                    approve_values.autoApproveTime = moment(tripApprove.autoApproveTime).format(timeFormat);
                    approve_values.staffName = staff.name;
                    approve_values.startDate = moment(tripApprove.startAt).format('YYYY.MM.DD');
                    approve_values.endDate = moment(tripApprove.backAt).format('YYYY.MM.DD');
                    approve_values.createdAt = moment(tripApprove.createdAt).format(timeFormat);
                    let travelLine = "";
                    if (!tripApprove.deptCity) {
                        travelLine = tripApprove.arrivalCity;
                    }
                    else {
                        travelLine = tripApprove.deptCity + ' - ' + tripApprove.arrivalCity;
                    }
                    if (tripApprove.isRoundTrip) {
                        travelLine += ' - ' + tripApprove.deptCity;
                    }
                    approve_values.travelLine = travelLine;
                    approve_values.reason = tripApprove.title;
                    approve_values.budget = tripApprove.budget;
                    // approve_values.autoApproveTime = moment(tripApprove.autoApproveTime).format(timeFormat)
                }
                try {
                    approve_values.noticeType = notice_1.ENoticeType.TRIP_APPLY_NOTICE;
                    yield API.notify.submitNotify({
                        key: 'qm_notify_new_travelbudget',
                        accountId: approveUser.id,
                        values: approve_values
                    });
                }
                catch (err) {
                    console.error('发送通知失败', err.stack ? err.stack : err);
                }
                try {
                    yield API.ddtalk.sendLinkMsg({ accountId: approveUser.id, text: '有新的出差申请需要您审批', url: shortUrl });
                }
                catch (err) {
                    console.error(`发送钉钉通知失败`, err);
                }
            }
            else {
                let admins = yield index_1.Models.staff.find({ where: { companyId: tripApprove['companyId'], roleId: [staff_1.EStaffRole.OWNER,
                            staff_1.EStaffRole.ADMIN], staffStatus: staff_1.EStaffStatus.ON_JOB, id: { $ne: staff.id } } }); //获取激活状态的管理员
                //给所有的管理员发送邮件
                yield Promise.all(admins.map(function (s) {
                    return tslib_1.__awaiter(this, void 0, void 0, function* () {
                        let vals = _.cloneDeep(values);
                        vals.managerName = s.name;
                        vals.email = staff.email;
                        vals.projectName = tripApprove.title;
                        vals.username = s.name;
                        vals.noticeType = notice_1.ENoticeType.TRIP_APPLY_NOTICE;
                        try {
                            yield API.notify.submitNotify({
                                key: 'qm_notify_new_travelbudget',
                                accountId: s.id,
                                values: vals
                            });
                        }
                        catch (err) {
                            console.error(err);
                        }
                    });
                }));
            }
            return true;
        });
    }
    static sendApprovePassNoticeToCompany(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let tripApprove = yield index_1.Models.tripApprove.get(params.approveId);
            let staff = tripApprove.account;
            let company = staff.company;
            let approveUser = yield index_1.Models.staff.get(tripApprove['approveUserId']);
            let details = yield TripApproveModule.getDetailsFromApprove({ approveId: tripApprove.id });
            let { go, back, hotel, subsidy } = yield TripPlanModule.getEmailInfoFromDetails(details);
            let timeFormat = 'YYYY-MM-DD HH:mm:ss';
            let values = {
                projectName: tripApprove.title,
                goTrafficBudget: go,
                backTrafficBudget: back,
                hotelBudget: hotel,
                otherBudget: subsidy,
                totalBudget: '￥' + tripApprove.budget,
                userName: staff.name || "",
                approveTime: moment(new Date()).format(timeFormat),
                approveUser: approveUser.name || ""
            };
            try {
                if (company.getNoticeEmail) {
                    yield API.notify.submitNotify({
                        key: 'qm_notify_company_approve_pass',
                        email: company.getNoticeEmail,
                        values: values
                    });
                }
            }
            catch (err) {
                console.error('发送行政通知失败', err);
            }
            return true;
        });
    }
    /* 企业管理员审批员工预算
    * @param params
    * @returns {boolean}
    */
    static approveTripPlan(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let isNextApprove = params.isNextApprove;
            let staff = yield staff_1.Staff.getCurrent();
            let tripApprove = yield index_1.Models.tripApprove.get(params.id);
            let approveResult = params.approveResult;
            let budgetId = params.budgetId;
            let approveUser = yield index_1.Models.staff.get(tripApprove['approveUserId']);
            let approveCompany = approveUser.company;
            if (isNextApprove && !params.nextApproveUserId)
                throw new Error("审批人不能为空");
            if (!tripApprove.isSpecialApprove && !budgetId) {
                throw new Error(`预算信息已失效请重新生成`);
            }
            else if (approveResult != tripPlan_1.EApproveResult.PASS && approveResult != tripPlan_1.EApproveResult.REJECT) {
                throw L.ERR.PERMISSION_DENY(); //只能审批待审批的出差记录
            }
            else if (tripApprove.status != tripPlan_1.QMEApproveStatus.WAIT_APPROVE) {
                throw L.ERR.TRIP_PLAN_STATUS_ERR(); //只能审批待审批的出差记录
            }
            else if (approveUser.id != staff.id) {
                throw L.ERR.PERMISSION_DENY();
            }
            let budgetInfo;
            let number = 0;
            /*if(tripApprove.isSpecialApprove){
                number = 1;
            }*/
            if (!tripApprove.isSpecialApprove) {
                budgetInfo = yield API.client.travelBudget.getBudgetInfo({ id: budgetId, accountId: tripApprove.account.id });
                if (!budgetInfo || !budgetInfo.budgets)
                    throw new Error(`预算信息已失效请重新生成`);
                let finalBudget = 0;
                budgetInfo.budgets.forEach((v) => {
                    if (v.tripType != tripPlan_1.ETripType.SUBSIDY) {
                        number = number + 1;
                    }
                    if (v.price <= 0) {
                        finalBudget = -1;
                        return;
                    }
                    finalBudget += Number(v.price);
                });
                tripApprove.budget = finalBudget;
                tripApprove.budgetInfo = budgetInfo.budgets;
            }
            // 特殊审批和非当月提交的审批不记录行程点数
            if (!tripApprove.isSpecialApprove) {
                if (typeof tripApprove.query == 'string') {
                    tripApprove.query = JSON.parse(tripApprove.query);
                }
                let query = tripApprove.query;
                let frozenNum = query.frozenNum;
                let content = tripApprove.deptCity + "-" + tripApprove.arrivalCity;
                if (tripApprove.createdAt.getMonth() == new Date().getMonth()) {
                    //审批本月记录审批通过
                    if (approveResult == tripPlan_1.EApproveResult.PASS && !isNextApprove) {
                        yield approveCompany.beforeApproveTrip({ number: number });
                        yield approveCompany.approvePassReduceTripPlanNum({ accountId: tripApprove.account.id, tripPlanId: tripApprove.id,
                            remark: "审批通过消耗行程点数", content: content, isShowToUser: false, frozenNum: frozenNum });
                    }
                    //审批本月记录审批驳回
                    if (approveResult == tripPlan_1.EApproveResult.REJECT) {
                        yield approveCompany.approveRejectFreeTripPlanNum({ accountId: tripApprove.account.id, tripPlanId: tripApprove.id,
                            remark: "审批驳回释放冻结行程点数", content: content, frozenNum: frozenNum });
                    }
                }
                else {
                    //审批上月记录审批通过
                    if (approveResult == tripPlan_1.EApproveResult.PASS && !isNextApprove) {
                        yield approveCompany.beforeApproveTrip({ number: number });
                        yield approveCompany.approvePassReduceBeforeNum({ accountId: tripApprove.account.id, tripPlanId: tripApprove.id,
                            remark: "审批通过上月申请消耗行程点数", content: content, isShowToUser: false, frozenNum: frozenNum });
                    }
                    //审批上月记录审批驳回
                    if (approveResult == tripPlan_1.EApproveResult.REJECT) {
                        yield approveCompany.approveRejectFreeBeforeNum({ accountId: tripApprove.account.id, tripPlanId: tripApprove.id,
                            remark: "审批驳回上月申请释放冻结行程点数", content: content, frozenNum: frozenNum });
                    }
                }
            }
            // let tripPlan: TripPlan;
            let notifyRemark = '';
            let tplName = '';
            let log = tripPlan_1.TripPlanLog.create({ tripPlanId: tripApprove.id, userId: staff.id });
            if (approveResult == tripPlan_1.EApproveResult.PASS && !isNextApprove) {
                notifyRemark = `审批通过，审批人：${staff.name}`;
                tplName = 'qm_notify_approve_pass';
                log.approveStatus = tripPlan_1.EApproveResult.PASS;
                log.remark = `审批通过`;
                log.save();
                tripApprove.status = tripPlan_1.QMEApproveStatus.PASS;
                tripApprove.approveRemark = '审批通过';
                tripApprove.approvedUsers += `,${staff.id}`;
                //tripPlan = await TripPlanModule.saveTripPlanByApprove({tripApproveId: params.id});
            }
            else if (isNextApprove) {
                log.approveStatus = tripPlan_1.EApproveResult.PASS;
                log.save();
                let nextApproveUser = yield index_1.Models.staff.get(params.nextApproveUserId);
                tripApprove.approvedUsers += `,${staff.id}`;
                tripApprove.approveUser = nextApproveUser;
            }
            else if (approveResult == tripPlan_1.EApproveResult.REJECT) {
                let approveRemark = params.approveRemark;
                if (!approveRemark) {
                    yield tripApprove.reload();
                    throw { code: -2, msg: '拒绝原因不能为空' };
                }
                notifyRemark = `审批未通过，原因：${approveRemark}`;
                tplName = 'qm_notify_approve_not_pass';
                log.approveStatus = tripPlan_1.EApproveResult.REJECT;
                log.remark = approveRemark;
                log.save();
                tripApprove.approveRemark = approveRemark;
                tripApprove.status = tripPlan_1.QMEApproveStatus.REJECT;
            }
            yield tripApprove.save();
            if (isNextApprove) {
                yield TripApproveModule.sendTripApproveNotice({ approveId: tripApprove.id, nextApprove: true });
            }
            else {
                //发送审核结果邮件
                let self_url;
                let appMessageUrl;
                self_url = config.host + '/index.html#/trip-approval/detail?approveId=' + tripApprove.id;
                appMessageUrl = '#/trip-approval/detail?approveId=' + tripApprove.id;
                let user = tripApprove.account;
                if (!user)
                    user = yield index_1.Models.staff.get(tripApprove['accountId']);
                let go = {}, back = {}, hotel = {}, subsidy = {};
                let self_values = {};
                try {
                    self_url = yield API.wechat.shorturl({ longurl: self_url });
                }
                catch (err) {
                    console.error(err);
                }
                let openId = yield API.auth.getOpenIdByAccount({ accountId: user.id });
                if (approveResult == tripPlan_1.EApproveResult.REJECT) {
                    let details = yield TripApproveModule.getDetailsFromApprove({ approveId: tripApprove.id });
                    let data = yield TripPlanModule.getEmailInfoFromDetails(details);
                    go = data.go;
                    back = data.back;
                    hotel = data.hotel;
                    subsidy = data.subsidy;
                    self_values = {
                        noticeType: notice_1.ENoticeType.TRIP_APPROVE_NOTICE,
                        username: user.name,
                        planNo: "无",
                        approveTime: moment(new Date()).format('YYYY-MM-DD HH:mm:ss'),
                        approveUser: staff.name,
                        projectName: tripApprove.title,
                        goTrafficBudget: go,
                        backTrafficBudget: back,
                        hotelBudget: hotel,
                        otherBudget: subsidy,
                        totalBudget: '￥' + tripApprove.budget,
                        url: self_url,
                        detailUrl: self_url,
                        appMessageUrl: appMessageUrl,
                        time: moment(tripApprove.startAt).format('YYYY-MM-DD'),
                        destination: tripApprove.arrivalCity,
                        staffName: user.name,
                        startTime: moment(tripApprove.startAt).format('YYYY-MM-DD'),
                        arrivalCity: tripApprove.arrivalCity,
                        budget: tripApprove.budget,
                        approveResult: tripPlan_1.EApproveResult2Text[approveResult],
                        reason: approveResult,
                        emailReason: params.approveRemark,
                        startAt: moment(tripApprove.startAt).format('MM.DD'),
                        backAt: moment(tripApprove.backAt).format('MM.DD'),
                        deptCity: tripApprove.deptCity,
                    };
                }
                try {
                    yield API.notify.submitNotify({ accountId: user.id, key: tplName, values: self_values });
                }
                catch (err) {
                    console.error(err);
                }
                try {
                    yield API.ddtalk.sendLinkMsg({ accountId: user.id, text: '您的预算已审批完成', url: self_url });
                }
                catch (err) {
                    console.error(err);
                }
            }
            //发送通知给监听程序
            index_2.plugins.qm.tripApproveUpdateNotify(null, {
                approveNo: tripApprove.id,
                status: tripApprove.status,
                approveUser: staff.id,
                outerId: tripApprove.id,
                data: budgetInfo,
                oa: 'qm'
            });
            return true;
        });
    }
    /**
     * 撤销tripApprove
     * @param params
     * @returns {boolean}
     */
    static cancelTripApprove(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let tripApprove = yield index_1.Models.tripApprove.get(params.id);
            if (tripApprove.status != tripPlan_1.QMEApproveStatus.WAIT_APPROVE && tripApprove.approvedUsers && tripApprove.approvedUsers.indexOf(",") != -1) {
                throw { code: -2, msg: "审批单状态不正确，该审批单不能撤销！" };
            }
            tripApprove.status = tripPlan_1.QMEApproveStatus.CANCEL;
            tripApprove.cancelRemark = params.remark || "";
            let staff = yield staff_1.Staff.getCurrent();
            let log = index_1.Models.tripPlanLog.create({ tripPlanId: tripApprove.id, userId: staff.id, remark: `撤销行程审批单` });
            yield Promise.all([tripApprove.save(), log.save()]);
            return true;
        });
    }
    static saveTripApprove(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let staff = yield staff_1.Staff.getCurrent();
            let company = staff.company;
            if (company.isApproveOpen && !params.approveUserId) {
                throw { code: -2, msg: '审批人不能为空' };
            }
            let budgetInfo = yield API.travelBudget.getBudgetInfo({ id: params.budgetId });
            if (!budgetInfo) {
                throw L.ERR.TRAVEL_BUDGET_NOT_FOUND();
            }
            let { budgets, query } = budgetInfo;
            let totalBudget = 0;
            budgets.forEach((b) => { totalBudget += Number(b.price); });
            budgets = budgets.map((v) => {
                if (v.type == tripPlan_1.ETripType.HOTEL) {
                    v.placeName = budgetInfo.query.hotelName;
                }
                return v;
            });
            let project = yield API.tripPlan.getProjectByName({ companyId: company.id, name: params.title, userId: staff.id, isCreate: true });
            let tripApprove = tripPlan_1.TripApprove.create(params);
            if (params.approveUserId) {
                let approveUser = yield index_1.Models.staff.get(params.approveUserId);
                if (!approveUser)
                    throw { code: -3, msg: '审批人不存在' };
                // if(tripApprove.approveUser && tripApprove['approveUser'].id == staff.id)
                //     throw {code: -4, msg: '审批人不能是自己'};
                tripApprove.approveUser = approveUser;
            }
            tripApprove.status = tripPlan_1.QMEApproveStatus.WAIT_APPROVE;
            tripApprove.account = staff;
            tripApprove['companyId'] = company.id;
            tripApprove.project = project;
            tripApprove.startAt = query.leaveDate;
            tripApprove.backAt = query.goBackDate;
            tripApprove.query = JSON.stringify(query);
            let arrivalInfo = (yield API.place.getCityInfo({ cityCode: query.destinationPlace.id || query.destinationPlace })) || { name: null };
            if (query.originPlace) {
                let deptInfo = (yield API.place.getCityInfo({ cityCode: query.originPlace.id || query.originPlace })) || { name: null };
                tripApprove.deptCityCode = deptInfo.id;
                tripApprove.deptCity = deptInfo.name;
            }
            tripApprove.arrivalCityCode = arrivalInfo.id;
            tripApprove.arrivalCity = arrivalInfo.name;
            tripApprove.isNeedTraffic = query.isNeedTraffic;
            tripApprove.isNeedHotel = query.isNeedHotel;
            tripApprove.isRoundTrip = query.isRoundTrip;
            tripApprove.budgetInfo = budgets;
            tripApprove.budget = totalBudget;
            tripApprove.status = totalBudget < 0 ? tripPlan_1.QMEApproveStatus.NO_BUDGET : tripPlan_1.QMEApproveStatus.WAIT_APPROVE;
            let tripPlanLog = index_1.Models.tripPlanLog.create({ tripPlanId: tripApprove.id, userId: staff.id, approveStatus: tripPlan_1.EApproveResult.WAIT_APPROVE, remark: '提交审批单，等待审批' });
            //如果出差计划是待审批状态，增加自动审批时间
            if (tripApprove.status == tripPlan_1.QMEApproveStatus.WAIT_APPROVE) {
                var days = moment(tripApprove.startAt).diff(moment(), 'days');
                let format = 'YYYY-MM-DD HH:mm:ss';
                if (days <= 0) {
                    tripApprove.autoApproveTime = moment(tripApprove.createdAt).add(1, 'hours').toDate();
                }
                else {
                    //出发前一天18点
                    let autoApproveTime = moment(tripApprove.startAt).subtract(6, 'hours').toDate();
                    //当天18点以后申请的出差计划，一个小时后自动审批
                    if (moment(autoApproveTime).diff(moment()) <= 0) {
                        autoApproveTime = (moment(tripApprove.createdAt).add(1, 'hours').toDate());
                    }
                    tripApprove.autoApproveTime = autoApproveTime;
                }
            }
            yield Promise.all([tripApprove.save(), tripPlanLog.save()]);
            yield TripApproveModule.sendTripApproveNotice({ approveId: tripApprove.id, nextApprove: false });
            yield TripApproveModule.sendTripApproveNoticeToSystem({ approveId: tripApprove.id });
            return tripApprove;
        });
    }
    static saveSpecialTripApprove(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let staff = yield staff_1.Staff.getCurrent();
            let company = staff.company;
            if (company.isApproveOpen && !params.approveUserId) {
                throw { code: -2, msg: '审批人不能为空' };
            }
            let query = params.query;
            let project = yield API.tripPlan.getProjectByName({ companyId: company.id, name: params.title, userId: staff.id, isCreate: true });
            let tripApprove = tripPlan_1.TripApprove.create(params);
            tripApprove.isSpecialApprove = true;
            if (params.approveUserId) {
                let approveUser = yield index_1.Models.staff.get(params.approveUserId);
                if (!approveUser)
                    throw { code: -3, msg: '审批人不存在' };
                if (tripApprove.approveUser && tripApprove['approveUser'].id == staff.id)
                    throw { code: -4, msg: '审批人不能是自己' };
                tripApprove.approveUser = approveUser;
            }
            tripApprove.status = tripPlan_1.QMEApproveStatus.WAIT_APPROVE;
            tripApprove.account = staff;
            tripApprove['companyId'] = company.id;
            tripApprove.project = project;
            tripApprove.startAt = query.leaveDate;
            tripApprove.backAt = query.goBackDate;
            tripApprove.query = JSON.stringify(query);
            let arrivalInfo = (yield API.place.getCityInfo({ cityCode: query.destinationPlace.id || query.destinationPlace })) || { name: null };
            if (query.originPlace) {
                let deptInfo = (yield API.place.getCityInfo({ cityCode: query.originPlace.id || query.originPlace })) || { name: null };
                tripApprove.deptCityCode = deptInfo.id;
                tripApprove.deptCity = deptInfo.name;
            }
            tripApprove.arrivalCityCode = arrivalInfo.id;
            tripApprove.arrivalCity = arrivalInfo.name;
            tripApprove.isNeedTraffic = query.isNeedTraffic;
            tripApprove.isNeedHotel = query.isNeedHotel;
            tripApprove.isRoundTrip = query.isRoundTrip;
            let tripPlanLog = index_1.Models.tripPlanLog.create({ tripPlanId: tripApprove.id, userId: staff.id, approveStatus: tripPlan_1.EApproveResult.WAIT_APPROVE, remark: '特别审批提交审批单，等待审批' });
            //如果出差计划是待审批状态，增加自动审批时间
            if (tripApprove.status == tripPlan_1.QMEApproveStatus.WAIT_APPROVE) {
                var days = moment(tripApprove.startAt).diff(moment(), 'days');
                let format = 'YYYY-MM-DD HH:mm:ss';
                if (days <= 0) {
                    tripApprove.autoApproveTime = moment(tripApprove.createdAt).add(1, 'hours').toDate();
                }
                else {
                    //出发前一天18点
                    let autoApproveTime = moment(tripApprove.startAt).subtract(6, 'hours').toDate();
                    //当天18点以后申请的出差计划，一个小时后自动审批
                    if (moment(autoApproveTime).diff(moment()) <= 0) {
                        autoApproveTime = moment(tripApprove.createdAt).add(1, 'hours').toDate();
                    }
                    tripApprove.autoApproveTime = autoApproveTime;
                }
            }
            yield Promise.all([tripApprove.save(), tripPlanLog.save()]);
            yield TripApproveModule.sendTripApproveNotice({ approveId: tripApprove.id, nextApprove: false });
            yield TripApproveModule.sendTripApproveNoticeToSystem({ approveId: tripApprove.id });
            return tripApprove;
        });
    }
    static getTripApprove(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let staff = yield staff_1.Staff.getCurrent();
            let staffId = staff.id;
            let approve = yield index_1.Models.tripApprove.get(params.id);
            if (approve.account.id != staffId && approve.approveUser.id != staffId && approve.approvedUsers.indexOf(staffId) < 0)
                throw L.ERR.PERMISSION_DENY();
            return approve;
        });
    }
    static updateTripApprove(params) {
        return index_1.Models.tripApprove.update(params);
    }
    static getTripApproves(options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            //let staff = await Staff.getCurrent();
            if (!options.where)
                options.where = {};
            options.order = options.order || [['start_at', 'desc'], ['created_at', 'desc']];
            let paginate = yield index_1.Models.tripApprove.find(options);
            return { ids: paginate.map((approve) => { return approve.id; }), count: paginate["total"] };
        });
    }
    static deleteTripApprove(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let tripApprove = yield index_1.Models.tripApprove.get(params.id);
            yield tripApprove.destroy();
            return true;
        });
    }
}
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id', 'approveResult', 'isNextApprove'], ['approveRemark', "budgetId", 'nextApproveUserId']),
    _decorator_1.modelNotNull('tripApprove')
], TripApproveModule, "approveTripPlan", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id'], ['remark'])
], TripApproveModule, "cancelTripApprove", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['budgetId', 'title'], ['description', 'remark', 'approveUserId'])
], TripApproveModule, "saveTripApprove", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['query', 'title', 'budget', 'specialApproveRemark'], ['description', 'remark', 'approveUserId'])
], TripApproveModule, "saveSpecialTripApprove", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id'])
], TripApproveModule, "getTripApprove", null);
tslib_1.__decorate([
    helper_1.clientExport
], TripApproveModule, "updateTripApprove", null);
tslib_1.__decorate([
    helper_1.clientExport
], TripApproveModule, "getTripApproves", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id']),
    _decorator_1.modelNotNull('tripApprove')
], TripApproveModule, "deleteTripApprove", null);
module.exports = TripApproveModule;

//# sourceMappingURL=index.js.map
