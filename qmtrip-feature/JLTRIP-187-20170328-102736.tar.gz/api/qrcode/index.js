/**
 * Created by wlh on 2016/10/10.
 */
'use strict';
const tslib_1 = require("tslib");
const qr = require('qr-image');
class QrcodeModule {
    static makeQrcode(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let { content } = params;
            let bfs = qr.imageSync(content, { type: 'png', ec_level: 'L' });
            return bfs.toString('base64');
        });
    }
}
module.exports = QrcodeModule;

//# sourceMappingURL=index.js.map
