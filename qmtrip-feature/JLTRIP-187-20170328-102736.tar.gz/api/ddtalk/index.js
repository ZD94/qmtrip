/**
 * Created by wlh on 16/9/7.
 */
'use strict';
const tslib_1 = require("tslib");
const API = require('common/api');
let dingSuiteCallback = require("dingtalk_suite_callback");
const cache_1 = require("common/cache");
const config = {
    token: 'jingli2016',
    encodingAESKey: '8nf2df6n0hiifsgg521mmjl6euyxoy3y6d9d3mt1laq',
    suiteid: 'suitezutlhpvgyvgakcdo',
    secret: 'pV--T2FZj-3QCjJzcQd5OnzDBAe6rRKRQGEmc8iVCvdtc2FUOS5icq1gVfkbqiTx',
    appid: '2156',
};
const isvApi_1 = require("./lib/isvApi");
const index_1 = require("_types/index");
const helper_1 = require("common/api/helper");
const index_2 = require("./lib/msg-template/index");
const DealEvent = require("./lib/dealEvent");
const CACHE_KEY = `ddtalk:ticket:${config.suiteid}`;
let ddTalkMsgHandle = {
    /* * * * 临时授权码* * * * */
    tmp_auth_code: function (msg) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            DealEvent.tmpAuthCode(msg);
        });
    },
    /* * * * * 授权变更* * * * * * */
    change_auth: function (msg) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            return msg;
        });
    },
    check_url: function (msg) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            return msg;
        });
    },
    /* * * * 解除授权信息 * * * */
    suite_relieve: function (msg) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            DealEvent.suiteRelieve(msg);
        });
    },
    /* * * 保存授权信息 , 每20分钟钉钉会请求一次 * * */
    suite_ticket: function (msg) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let ticket = msg.SuiteTicket;
            yield cache_1.default.write(CACHE_KEY, JSON.stringify({
                ticket: ticket, timestamp: msg.TimeStamp
            }));
        });
    },
    /* * * 企业增加员工 * * */
    user_add_org: function (msg) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            DealEvent.userAddOrg(msg);
        });
    },
    /* * 通讯录用户更改 * */
    user_modify_org: function (msg) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            DealEvent.userAddOrg(msg);
        });
    },
    /* * 通讯录用户离职 * */
    user_leave_org: function (msg) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            return msg;
        });
    },
    /* * 通讯录用户被设为管理员 * */
    // org_admin_add : async function(msg){
    //     return msg;
    // },
    /* * 通讯录用户被取消设置管理员 * */
    // org_admin_remove : async function(msg){
    //     return msg;
    // },
    /* * *  通讯录企业部门创建 * * */
    org_dept_create: function (msg) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            DealEvent.orgDeptCreate(msg);
        });
    },
    /* * *  通讯录企业部门修改 * * */
    org_dept_modify: function (msg) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            DealEvent.orgDeptModify(msg);
        });
    },
    /* * *  通讯录企业部门删除 * * */
    org_dept_remove: function (msg) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            DealEvent.orgDeptRemove(msg);
            return msg;
        });
    },
    /* * *  企业被解散 * * */
    org_remove: function (msg) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            DealEvent.orgDeptRemove(msg);
            return msg;
        });
    }
};
class DDTalk {
    static __initHttpApp(app) {
        app.post("/ddtalk/isv/receive", dingSuiteCallback(config, function (msg, req, res, next) {
            console.info(msg);
            if (!ddTalkMsgHandle[msg.EventType]) {
                return res.reply();
            }
            return ddTalkMsgHandle[msg.EventType](msg)
                .then((ret) => {
                res.reply();
            })
                .catch((err) => {
                console.error(err.stack);
                next(err);
            });
        }));
    }
    static getJSAPIConfig(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let { orgid, agentid, url } = params;
            let timestamp = Math.floor(Date.now() / 1000);
            let noncestr = getRndStr(6);
            //查询企业永久授权码
            let corps = yield index_1.Models.ddtalkCorp.find({ where: { corpId: orgid }, limit: 1 });
            if (corps && corps.length) {
                let corp = corps[0];
                if (corp.isSuiteRelieve) {
                    let err = new Error(`企业还未授权或者已取消授权`);
                    throw err;
                }
                let tokenObj = yield DealEvent._getSuiteToken();
                let suiteToken = tokenObj['suite_access_token'];
                let isvApi = new isvApi_1.default(config.suiteid, suiteToken, orgid, corp.permanentCode);
                let corpApi = yield isvApi.getCorpApi();
                let ticketObj = yield corpApi.getTicket(); //获取到了ticket
                let arr = [];
                arr.push('noncestr=' + noncestr);
                arr.push('jsapi_ticket=' + ticketObj.ticket);
                arr.push('url=' + url);
                arr.push('timestamp=' + timestamp);
                arr.sort();
                let originStr = arr.join('&');
                let signature = require("crypto").createHash('sha1').update(originStr, 'utf8').digest('hex');
                return {
                    agentId: agentid,
                    corpId: orgid,
                    timeStamp: timestamp,
                    nonceStr: noncestr,
                    signature: signature,
                };
            }
            throw new Error(`企业不存在`);
        });
    }
    static loginByDdTalkCode(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let { corpid, code } = params;
            let corps = yield index_1.Models.ddtalkCorp.find({ where: { corpId: corpid }, limit: 1 });
            if (corps && corps.length) {
                let corp = corps[0];
                if (corp.isSuiteRelieve) {
                    let err = new Error(`企业还未授权或者已取消授权`);
                    throw err;
                }
                let tokenObj = yield DealEvent._getSuiteToken();
                let suiteToken = tokenObj['suite_access_token'];
                let isvApi = new isvApi_1.default(config.suiteid, suiteToken, corpid, corp.permanentCode);
                let corpApi = yield isvApi.getCorpApi();
                let dingTalkUser = yield corpApi.getUserInfoByOAuth(code);
                //查找是否已经绑定账号
                let ddtalkUsers = yield index_1.Models.ddtalkUser.find({ where: { corpid: corpid, ddUserId: dingTalkUser.userId } });
                if (ddtalkUsers && ddtalkUsers.length) {
                    let ddtalkUser = ddtalkUsers[0];
                    // //自动登录
                    let ret = yield API.auth.makeAuthenticateToken(ddtalkUser.id, 'ddtalk');
                    return ret;
                }
                throw new Error(`{"code":-1, "msg": "用户还未绑定账户"}`);
            }
            else {
                throw new Error(`企业不存在`);
            }
        });
    }
    static sendLinkMsg(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let { accountId, text, url, picurl } = params;
            text = text || '您有一条新消息';
            url = url || '#';
            picurl = picurl || 'http://j.jingli365.com/ionic/images/dingtalk-shareicon.png';
            let staff = yield index_1.Models.staff.get(accountId);
            let company = staff.company;
            let corp = yield index_1.Models.ddtalkCorp.get(company.id);
            let ddtalkUser = yield index_1.Models.ddtalkUser.get(staff.id);
            if (corp && ddtalkUser) {
                let tokenObj = yield DealEvent._getSuiteToken();
                let isvApi = new isvApi_1.default(config.suiteid, tokenObj['suite_access_token'], corp.corpId, corp.permanentCode);
                let corpApi = yield isvApi.getCorpApi();
                let msg = yield index_2.get_msg({
                    touser: ddtalkUser.ddUserId,
                    content: text,
                    agentid: corp.agentid,
                    picurl: picurl,
                    title: '鲸力商旅',
                    url: url,
                }, 'link');
                let ret = yield corpApi.sendNotifyMsg(msg);
                return ret;
            }
            console.warn(`企业不存在或者不是从钉钉导入`);
            return null;
        });
    }
    /*
    *  同步钉钉组织架构
    */
    static synchroDDorganization() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            return DealEvent.synchroDDorganization();
        });
    }
}
DDTalk.__public = true;
tslib_1.__decorate([
    helper_1.clientExport
], DDTalk, "getJSAPIConfig", null);
tslib_1.__decorate([
    helper_1.clientExport
], DDTalk, "loginByDdTalkCode", null);
tslib_1.__decorate([
    helper_1.clientExport
], DDTalk, "synchroDDorganization", null);
function getRndStr(length) {
    let ret = '';
    for (var i = 0, ii = length; i < ii; i++) {
        ret += Math.ceil(Math.random() * 9);
    }
    return ret;
}
module.exports = DDTalk;

//# sourceMappingURL=index.js.map
