/**
 * Created by wyl on 16-11-11.
 */
'use strict';
const tslib_1 = require("tslib");
const helper_1 = require("common/api/helper");
const staff_1 = require("_types/staff");
const notice_1 = require("_types/notice");
const _types_1 = require("_types");
let sequelize = require("common/model").DB;
var JPush = require("jpush-sdk");
var API = require("common/api");
const noticeCols = notice_1.Notice['$fieldnames'];
const noticeAccountCols = notice_1.NoticeAccount['$fieldnames'];
class NoticeModule {
    /**
     * 创建通知通告
     * @param data
     * @returns {*}
     */
    static createNotice(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var notice = notice_1.Notice.create(params);
            result = yield notice.save();
            var result;
            var link = '#/notice/detail?noticeId=' + result.id;
            if (params.sendType == notice_1.ESendType.ONE_ACCOUNT) {
                var noticeAccount = notice_1.NoticeAccount.create();
                noticeAccount.noticeId = result.id;
                noticeAccount.accountId = params.staffId;
                yield noticeAccount.save();
                var jpushId = yield API.auth.getJpushIdByAccount({ accountId: params.staffId });
                if (result.content.startsWith("skipLink@")) {
                    link = result.content.substring(9);
                }
                if (jpushId) {
                    yield API.jpush.pushAppMessage({ content: result.description, title: result.title, link: link, jpushId: jpushId });
                }
            }
            else if (params.sendType == notice_1.ESendType.MORE_ACCOUNT) {
                var accountIds = params.toUsers;
                accountIds = JSON.parse(accountIds);
                var jpushIds = [];
                yield Promise.all(accountIds.map(function (item) {
                    return tslib_1.__awaiter(this, void 0, void 0, function* () {
                        var noticeAccount = notice_1.NoticeAccount.create();
                        noticeAccount.noticeId = result.id;
                        noticeAccount.accountId = item;
                        yield noticeAccount.save();
                        var jId = yield API.auth.getJpushIdByAccount({ accountId: item });
                        // jId 为数组 可能是一个或多个
                        if (jId) {
                            jpushIds = jpushIds.concat(jId);
                        }
                    });
                }));
                yield API.jpush.pushAppMessage({ content: result.description, title: result.title, link: link, jpushId: jpushIds });
            }
            else if (params.sendType == notice_1.ESendType.ALL_ACCOUNT) {
                var jpushId = JPush.ALL;
                yield API.jpush.pushAppMessage({ content: result.description, title: result.title, link: link, jpushId: jpushId });
            }
            return result;
        });
    }
    /**
     * 删除通知通告
     * @param params
     * @returns {*}
     */
    static deleteNotice(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var id = params.id;
            var ah_delete = yield _types_1.Models.notice.get(id);
            var noticeAccounts = yield _types_1.Models.noticeAccount.find({ where: { noticeId: ah_delete.id } });
            if (noticeAccounts && noticeAccounts.length > 0) {
                yield Promise.all(noticeAccounts.map((item) => tslib_1.__awaiter(this, void 0, void 0, function* () {
                    yield item.destroy();
                })));
            }
            yield ah_delete.destroy();
            return true;
        });
    }
    /**
     * 更新通知通告
     * @param id
     * @param data
     * @returns {*}
     */
    static updateNotice(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var id = params.id;
            var ah = yield _types_1.Models.notice.get(id);
            for (var key in params) {
                ah[key] = params[key];
            }
            return ah.save();
        });
    }
    /**
     * 根据id查询通知通告
     * @param {String} params.id
     * @param {Boolean} params.isReturnDefault 如果不存在返回默认 default true,
     * @returns {*}
     */
    static getNotice(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let id = params.id;
            var ah = yield _types_1.Models.notice.get(id);
            return ah;
        });
    }
    ;
    /**
     * 根据属性查找通知通告
     * @param params
     * @returns {*}
     */
    static getNotices(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var staff = yield staff_1.Staff.getCurrent();
            params.order = params.order || [['createdAt', 'desc']];
            let paginate = yield _types_1.Models.notice.find(params);
            let ids = paginate.map(function (t) {
                return t.id;
            });
            return { ids: ids, count: paginate['total'] };
        });
    }
    /**
     * 根据属性查找通知通告
     * @param params
     * @returns {*}
     */
    static statisticNoticeByType() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var staff = yield staff_1.Staff.getCurrent();
            var sql1 = `select b.type, count(b.id) from notice.notice_accounts a right join notice.notices b " +
            "on a.notice_id = b.id where (a.account_id='${staff.id}' or b.send_type = ${notice_1.ESendType.ALL_ACCOUNT}) " +
            "and a.is_read <> true and a.deleted_at is null group by b.type`;
            var unReadCountInfo = yield sequelize.query(sql1);
            return unReadCountInfo;
        });
    }
    /****************************************NoticeAccount begin************************************************/
    /**
     * 创建用户读取通知记录
     * @param data
     * @returns {*}
     */
    static createNoticeAccount(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var noticeAccount = notice_1.NoticeAccount.create(params);
            var already = yield _types_1.Models.noticeAccount.find({ where: { noticeId: params.noticeId, accountId: params.accountId } });
            if (already && already.length > 0) {
                return already[0];
            }
            var result = yield noticeAccount.save();
            return result;
        });
    }
    /**
     * 删除用户读取通知记录
     * @param params
     * @returns {*}
     */
    static deleteNoticeAccount(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var id = params.id;
            var ah_delete = yield _types_1.Models.noticeAccount.get(id);
            var notice = yield _types_1.Models.notice.get(ah_delete.noticeId);
            if (notice && notice.sendType == notice_1.ESendType.ONE_ACCOUNT) {
                yield notice.destroy();
            }
            yield ah_delete.destroy();
            return true;
        });
    }
    /**
     * 更新用户读取通知记录
     * @param id
     * @param data
     * @returns {*}
     */
    static updateNoticeAccount(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var id = params.id;
            var ah = yield _types_1.Models.noticeAccount.get(id);
            for (var key in params) {
                ah[key] = params[key];
            }
            return ah.save();
        });
    }
    /**
     * 根据id查询用户读取通知记录
     * @param {String} params.id
     * @returns {*}
     */
    static getNoticeAccount(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let id = params.id;
            var ah = yield _types_1.Models.noticeAccount.get(id);
            return ah;
        });
    }
    ;
    /**
     * 根据属性查找用户读取通知记录
     * @param params
     * @returns {*}
     */
    static getNoticeAccounts(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var staff = yield staff_1.Staff.getCurrent();
            let paginate = yield _types_1.Models.noticeAccount.find(params);
            let ids = paginate.map(function (t) {
                return t.id;
            });
            return { ids: ids, count: paginate['total'] };
        });
    }
}
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["title", "content", "description", "sendType"], noticeCols)
], NoticeModule, "createNotice", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"])
], NoticeModule, "deleteNotice", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"], noticeCols)
], NoticeModule, "updateNotice", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"])
], NoticeModule, "getNotice", null);
tslib_1.__decorate([
    helper_1.clientExport
], NoticeModule, "getNotices", null);
tslib_1.__decorate([
    helper_1.clientExport
], NoticeModule, "statisticNoticeByType", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["accountId", "noticeId",], noticeAccountCols)
], NoticeModule, "createNoticeAccount", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"])
], NoticeModule, "deleteNoticeAccount", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"], noticeAccountCols)
], NoticeModule, "updateNoticeAccount", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(["id"])
], NoticeModule, "getNoticeAccount", null);
tslib_1.__decorate([
    helper_1.clientExport
], NoticeModule, "getNoticeAccounts", null);
module.exports = NoticeModule;

//# sourceMappingURL=index.js.map
