update notice.notices set type = 1 where title like '%成功%';
update notice.notices set type = 2 where title like '%通过%';
update notice.notices set type = 3 where title like '%出差请示%';