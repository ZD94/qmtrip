update notice.notices set title = theme;
ALTER TABLE notice.notices DROP COLUMN theme;