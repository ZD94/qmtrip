ALTER TABLE notice.notices DROP COLUMN IF EXISTS  staff_id;
ALTER TABLE notice.notices DROP COLUMN IF EXISTS  is_read;
ALTER TABLE notice.notices DROP COLUMN IF EXISTS  from_where;