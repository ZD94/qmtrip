/**
 * Created by yumiao on 15-12-9.
 */
"use strict";
const tslib_1 = require("tslib");
let sequelize = require("common/model").DB;
let DBM = sequelize.models;
let API = require("common/api");
const language_1 = require("common/language");
const Logger = require("common/logger");
const helper_1 = require("common/api/helper");
const agency_1 = require("_types/agency");
const _decorator_1 = require("../_decorator");
const index_1 = require("_types/index");
const utils_1 = require("common/utils");
let logger = new Logger("agency");
class AgencyModule {
    /**
     * @method createAgency
     * 创建代理商
     * @param params
     * @returns {Promise<Agency>}
     */
    static createAgency(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let _agency = yield index_1.Models.agency.find({ where: { $or: [{ email: params.email }, { mobile: params.mobile }] } });
            if (_agency && _agency.length > 0) {
                throw { code: -2, msg: '邮箱或手机号已经注册代理商' };
            }
            return index_1.Models.agency.create(params).save();
        });
    }
    ;
    /**
     * @method registerAgency
     *
     * 注册代理商
     *
     * @param {Object} params 参数
     * @param {string} params.name 代理商名称 必填
     * @param {string} params.userName 用户姓名 必填
     * @param {string} params.mobile 手机号 必填
     * @param {string} params.email 邮箱 必填
     * @param {string} params.pwd 密码 选
     * 填，如果手机号和邮箱在全麦注册过，则密码还是以前的密码
     * @returns {Promise<Agency>}
     */
    static registerAgency(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let email = params.email;
            let mobile = params.mobile;
            let password = params.pwd || "123456";
            let ACCOUNT_TYPE = 2; //账号类型，2为代理商账号
            let agency = agency_1.Agency.create(params);
            let agencyUser = agency_1.AgencyUser.create({ name: params.userName, pwd: utils_1.md5(password), status: agency_1.EAgencyStatus.ACTIVE,
                roleId: agency_1.EAgencyUserRole.OWNER, type: ACCOUNT_TYPE, email: email, mobile: mobile });
            agency.status = agency_1.EAgencyStatus.ACTIVE;
            agency.createUser = agencyUser.id;
            agencyUser.agency = agency;
            agencyUser.isValidateEmail = true;
            yield Promise.all([agency.save(), agencyUser.save()]);
            return agency;
        });
    }
    /**
     * @method getAgencyById
     *
     * 获取代理商信息
     *
     * @param {object} params
     * @param params.agencyId 代理商id
     * @returns {Promise<Agency>}
     */
    static getAgencyById(params) {
        return index_1.Models.agency.get(params.id);
    }
    /**
     * @method updateAgency
     *
     * 更新代理商信息
     * @param params
     * @returns {Promsie<Agency>}
     */
    static updateAgency(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let agency = yield index_1.Models.agency.get(params.id);
            for (let key in params) {
                agency[key] = params[key];
            }
            return agency.save();
        });
    }
    /**
     * @method listAgency
     * 查询代理商列表
     * @param params
     * @returns {Promise<string[]>}
     */
    static listAgency() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let agencies = yield index_1.Models.agency.find({});
            let ids = agencies.map((agency) => agency.id);
            return { ids: ids, count: agencies['total'] };
        });
    }
    /**
     * @method deleteAgency
     * 删除代理商
     * @param params
     * @returns {*}
     */
    static deleteAgency(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let agency = yield index_1.Models.agency.get(params.id);
            yield agency.destroy();
            return true;
        });
    }
    /**
     * @method createAgencyUser
     * 创建代理商用户
     * @param params
     * @returns {Promise<AgencyUser>}
     */
    static createAgencyUser(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let curUser = yield agency_1.AgencyUser.getCurrent();
            if (!curUser) {
                throw language_1.default.ERR.AGENCY_USER_NOT_EXIST();
            }
            let user = yield index_1.Models.agencyUser.create(params);
            user.agency = curUser.agency;
            return user.save();
        });
    }
    /**
     * @method getAgencyUser
     * 获取代理商用户
     * @param params
     * @returns {Promise<AgencyUser>}
     */
    static getAgencyUser(params) {
        return index_1.Models.agencyUser.get(params.id);
    }
    /**
     * @method updateAgencyUser
     *
     * 更新代理商用户
     * @param {Object} params
     * @param {string} params.id 需要修改的代理商用户id
     * @param {number} params.status 代理商用户状态
     * @param {string} params.name 代理商名称
     * @param {string} params.mobile 代理商用户手机号
     * @returns {Promise<AgencyUser>}
     */
    static updateAgencyUser(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let target = yield index_1.Models.agencyUser.get(params.id);
            for (let key in params) {
                target[key] = params[key];
            }
            return yield target.save();
            ;
        });
    }
    /**
     * @method deleteAgencyUser
     * 删除代理商
     * @param params
     * @returns {Promise<boolean>}
     */
    static deleteAgencyUser(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let target = yield index_1.Models.agencyUser.get(params.id);
            yield target.destroy();
            return true;
        });
    }
    /**
     * @method agencyByEmail
     *
     * 通过邮箱获取代理商信息
     * @param params.email 邮箱
     */
    static agencyByEmail(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let agencies = yield index_1.Models.agency.find({ where: params });
            return agencies[0];
        });
    }
    /**
     * 分页查询代理商集合
     * @param params 查询条件 params.company_id 企业id
     * @param options options.perPage 每页条数 options.page当前页
     */
    static listAgencyUser(options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let curUser = yield agency_1.AgencyUser.getCurrent();
            if (!options.where) {
                options.where = {};
            }
            options.where.agencyId = curUser.agency.id;
            let agencyUsers = yield index_1.Models.agencyUser.find(options);
            let ids = agencyUsers.map((user) => user.id);
            return { ids: ids, count: agencyUsers['total'] };
        });
    }
    /**
     * 测试用例使用删除代理商和用户的操作，不在client里调用
     * @param params
     */
    static deleteAgencyByTest(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let email = params.email;
            let mobile = params.mobile;
            let name = params.name;
            yield API.auth.removeByTest({ email: email, mobile: mobile, type: 2 });
            yield DBM.Agency.destroy({ where: { $or: [{ email: email }, { mobile: mobile }, { name: name }] } });
            yield DBM.AgencyUser.destroy({ where: { name: name } });
            return true;
        });
    }
    static __initOnce() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            logger.info("init default agency...");
            let default_agency = require('config/config').default_agency;
            let email = default_agency.email;
            let mobile = default_agency.mobile;
            let pwd = default_agency.pwd;
            let user_name = default_agency.user_name;
            try {
                let agency = yield API.agency.agencyByEmail({ email: email });
                if (!agency || !agency.target) {
                    let _agency = { name: default_agency.name, email: email, mobile: mobile, pwd: pwd || '123456', status: 1, userName: user_name, remark: '系统默认代理商' };
                    agency = yield API.agency.registerAgency(_agency);
                }
                let agencyId = agency.id;
                let myZome = Zone.current.fork({ name: 'updateCompany', properties: { session: { accountId: agencyId, tokenId: 'tokenId' } } });
                agency_1.Agency.__defaultAgencyId = agencyId;
                let companies = yield API.company.getCompanyNoAgency();
                if (!companies || companies.length <= 0) {
                    return;
                }
                yield Promise.all(companies.map(function (c) {
                    return tslib_1.__awaiter(this, void 0, void 0, function* () {
                        return myZome.run(API.company.updateCompany.bind(this, { id: c.id, agencyId: agencyId }));
                    });
                }));
            }
            catch (err) {
                logger.error("初始化系统默认代理商失败...");
                logger.error(err.stack);
            }
        });
    }
    static getAgencyOperateLogs(options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let { limit, offset } = options;
            let agencyUser = yield agency_1.AgencyUser.getCurrent();
            let agency = agencyUser.agency;
            let pager = yield index_1.Models.agencyOperateLog.find({
                where: { agencyId: agency.id },
                order: "created_at desc",
                limit: limit,
                offset: offset
            });
            let ids = pager.map((v) => {
                return v.id;
            });
            return { ids: ids, count: pager.total };
        });
    }
    static getAgencyOperateLog(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let agencyUser = yield agency_1.AgencyUser.getCurrent();
            let { id } = params;
            let log = yield index_1.Models.agencyOperateLog.get(id);
            if (log.agencyId != agencyUser.agency.id) {
                return null;
            }
            return log;
        });
    }
}
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['name', 'email', 'mobile', 'userName'], ['description', 'remark', 'pwd', 'sex'])
], AgencyModule, "registerAgency", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id']),
    _decorator_1.requirePermit('user.query', 2),
    _decorator_1.modelNotNull('agency'),
    _decorator_1.conditionDecorator([{ if: _decorator_1.condition.isMyAgency('0.id') }])
], AgencyModule, "getAgencyById", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id'], ['name', 'description', 'status', 'email', 'mobile', 'remark']),
    _decorator_1.conditionDecorator([{ if: _decorator_1.condition.isMyAgency('0.id') }]),
    _decorator_1.requirePermit('user.edit', 2),
    _decorator_1.modelNotNull('agency')
], AgencyModule, "updateAgency", null);
tslib_1.__decorate([
    helper_1.clientExport
], AgencyModule, "listAgency", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id']),
    _decorator_1.requirePermit('user.delete', 2),
    _decorator_1.conditionDecorator([{ if: _decorator_1.condition.isMyAgency('0.id') }]),
    _decorator_1.modelNotNull('agency')
], AgencyModule, "deleteAgency", null);
tslib_1.__decorate([
    helper_1.clientExport,
    _decorator_1.requirePermit('user.add', 2),
    helper_1.requireParams(['email', 'name'], ['mobile', 'sex', 'avatar', 'roleId'])
], AgencyModule, "createAgencyUser", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id']),
    _decorator_1.requirePermit('user.query', 2),
    _decorator_1.modelNotNull('agencyUser'),
    _decorator_1.conditionDecorator([{ if: _decorator_1.condition.isSameAgency('0.id') }])
], AgencyModule, "getAgencyUser", null);
tslib_1.__decorate([
    helper_1.clientExport,
    _decorator_1.requirePermit('user.edit', 2),
    _decorator_1.conditionDecorator([{ if: _decorator_1.condition.isSameAgency('0.id') }]),
    helper_1.requireParams(['id'], ['status', 'name', 'sex', 'mobile', 'avatar', 'roleId']),
    _decorator_1.modelNotNull('agencyUser')
], AgencyModule, "updateAgencyUser", null);
tslib_1.__decorate([
    helper_1.clientExport,
    helper_1.requireParams(['id']),
    _decorator_1.requirePermit("user.delete", 2),
    _decorator_1.conditionDecorator([{ if: _decorator_1.condition.isSameAgency('0.id') }]),
    _decorator_1.modelNotNull('agencyUser')
], AgencyModule, "deleteAgencyUser", null);
tslib_1.__decorate([
    helper_1.requireParams(['email'])
], AgencyModule, "agencyByEmail", null);
tslib_1.__decorate([
    helper_1.clientExport
], AgencyModule, "listAgencyUser", null);
tslib_1.__decorate([
    helper_1.clientExport
], AgencyModule, "getAgencyOperateLogs", null);
tslib_1.__decorate([
    helper_1.clientExport
], AgencyModule, "getAgencyOperateLog", null);
module.exports = AgencyModule;

//# sourceMappingURL=index.js.map
