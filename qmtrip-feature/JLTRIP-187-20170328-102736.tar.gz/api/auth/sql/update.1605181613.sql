
alter table auth.tokens add updated_at timestamp;
alter table auth.tokens add deleted_at timestamp;