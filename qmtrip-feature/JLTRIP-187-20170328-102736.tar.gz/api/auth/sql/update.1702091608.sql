DROP INDEX IF EXISTS auth.accounts_mobile;
DROP INDEX IF EXISTS auth.accounts_email;
