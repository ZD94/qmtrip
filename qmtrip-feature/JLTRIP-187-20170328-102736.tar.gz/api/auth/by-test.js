"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const index_1 = require("_types/index");
/**
 * @method removeByTest 删除账号
 *
 * @param {Object} data
 * @param {UUID} data.accountId 账号ID
 * @return {Promise}
 * @public
 */
function removeByTest(data) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        var accountId = data.accountId;
        var email = data.email;
        var mobile = data.mobile;
        var type = data.type || 1;
        var where = { $or: [{ id: accountId }, { email: email }, { mobile: mobile }] };
        if (!accountId) {
            where.type = type;
        }
        var accounts = yield index_1.Models.account.find({ where });
        do {
            for (let i = 0; i < accounts.length; i++) {
                accounts[i].destroy();
            }
        } while (yield accounts.nextPage());
    });
}
exports.removeByTest = removeByTest;

//# sourceMappingURL=by-test.js.map
