"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const cache_1 = require("common/cache");
const index_1 = require("./index");
const authentication_1 = require("./authentication");
const staff_1 = require("_types/staff/staff");
const index_2 = require("_types/index");
var C = require("config");
var API = require("common/api");
function __initHttpApp(app) {
    //微信自动登录
    app.all("/auth/wx-login", function (req, res, next) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let query = req.query;
            let redirect_url = query.redirect_url;
            redirect_url += redirect_url.indexOf('?') > 0 ? '&' : '?';
            redirect_url += 'wxauthcode=' + query.code + '&wxauthstate=' + query.state;
            res.redirect(redirect_url);
        });
    });
    //获取微信code
    app.all("/auth/get-wx-code", function (req, res, next) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let query = req.query;
            let redirect_url = query.redirect_url;
            //如果是登录页，直接跳转
            if (/^https?\:\/\/\w*\.jingli365\.com\/(index\.html)?\#\/login\/(index)?/.test(redirect_url)) {
                redirect_url += redirect_url.indexOf('?') > 0 ? '&' : '?';
                redirect_url += 'wxauthcode=' + query.code + '&wxauthstate=' + query.state;
                res.redirect(redirect_url);
            }
            else {
                if (!query.code) {
                    return res.redirect('/#/login/index');
                }
                redirect_url = encodeURIComponent(redirect_url);
                let url = `${C.host}/#/login/?backurl=${redirect_url}&wxauthcode=${query.code}&wxauthstate=${query.state}`;
                res.redirect(url);
            }
        });
    });
}
exports.__initHttpApp = __initHttpApp;
function authWeChatLogin(params) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        let openid = yield API.wechat.requestOpenIdByCode({ code: params.code }); //获取微信openId;
        yield cache_1.default.write(`wechat:${params.code}`, JSON.stringify({ openid: openid }));
        let accountId = yield index_1.default.getAccountIdByOpenId({ openId: openid });
        if (!accountId) {
            return false;
        }
        return authentication_1.makeAuthenticateToken(accountId, 'weChat');
    });
}
exports.authWeChatLogin = authWeChatLogin;
function getWeChatLoginUrl(params) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        let redirectUrl = encodeURIComponent(params.redirectUrl);
        let backUrl = C.host + "/auth/get-wx-code?redirect_url=" + redirectUrl;
        // backUrl = "https://t.jingli365.com/auth/wx-login?redirect_url=" + redirectUrl; //微信公众号测使用
        // backUrl = "https://t.jingli365.com/auth/get-wx-code?redirect_url=" + redirectUrl; //微信公众号测使用
        return API.wechat.getOAuthUrl({ backUrl: backUrl });
    });
}
exports.getWeChatLoginUrl = getWeChatLoginUrl;
function destroyWechatOpenId(params) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        let staff = yield staff_1.Staff.getCurrent();
        let tokens = yield index_2.Models.token.find({ where: { accountId: staff.id, type: 'wx_openid' } });
        if (!tokens || tokens.length <= 0) {
            return false;
        }
        yield Promise.all(tokens.map((token) => token.destroy()));
        return true;
    });
}
exports.destroyWechatOpenId = destroyWechatOpenId;
/**
 * 保存openId关联的accountId
 * @type {saveOrUpdateOpenId}
 */
function saveOrUpdateOpenId(params) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        let { code } = params;
        let val = yield cache_1.default.readAs(`wechat:${code}`);
        let openid = val ? val.openid : '';
        if (!openid)
            return;
        let staff = yield staff_1.Staff.getCurrent();
        let list = yield index_2.Models.token.find({ where: { token: openid, type: 'wx_openid' } });
        if (list && list.length > 0) {
            yield Promise.all(list.map((op) => op.destroy()));
        }
        let obj = index_2.Models.token.create({ token: openid, accountId: staff.id, type: 'wx_openid' });
        obj.save();
    });
}
exports.saveOrUpdateOpenId = saveOrUpdateOpenId;
/**
 * 获取数据库中openId关联的accountId
 * @type {getAccountIdByOpenId}
 */
function getAccountIdByOpenId(params) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        let list = yield index_2.Models.token.find({ where: { token: params.openId, type: 'wx_openid' } });
        if (!list || list.length <= 0) {
            return null;
        }
        let obj = list[0];
        return obj.accountId;
    });
}
exports.getAccountIdByOpenId = getAccountIdByOpenId;
/**
 * 获取数据库中accountId关联的openId
 * @type {getOpenIdByAccount}
 */
function getOpenIdByAccount(params) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        let list = yield index_2.Models.token.find({ where: { accountId: params.accountId, type: 'wx_openid' } });
        if (!list || list.length <= 0) {
            return null;
        }
        let obj = list[0];
        return obj.token;
    });
}
exports.getOpenIdByAccount = getOpenIdByAccount;

//# sourceMappingURL=wechat.js.map
