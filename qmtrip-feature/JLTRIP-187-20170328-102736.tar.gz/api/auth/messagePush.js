"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const index_1 = require("_types/index");
const staff_1 = require("_types/staff/staff");
/**
 * 删除绑定的设备id
 * @param params
 * @returns {boolean}
 */
function destroyJpushId(params) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        let staff = yield staff_1.Staff.getCurrent();
        let tokens = yield index_1.Models.token.find({ where: { accountId: staff.id, type: 'jpush_id' } });
        if (!tokens || tokens.length <= 0) {
            return false;
        }
        yield Promise.all(tokens.map((token) => token.destroy()));
        return true;
    });
}
exports.destroyJpushId = destroyJpushId;
/**
 * 用户绑定设备id
 * @type {saveOrUpdateJpushId}
 */
function saveOrUpdateJpushId(params) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        let staff = yield staff_1.Staff.getCurrent();
        let list = yield index_1.Models.token.find({ where: { token: params.jpushId, type: 'jpush_id', accountId: { $ne: staff.id } } });
        if (list && list.length > 0) {
            yield Promise.all(list.map((op) => op.destroy()));
        }
        let selfList = yield index_1.Models.token.find({ where: { token: params.jpushId, type: 'jpush_id', accountId: staff.id } });
        if (selfList && selfList.length > 0) {
            return selfList[0];
        }
        let obj = index_1.Models.token.create({ token: params.jpushId, accountId: staff.id, type: 'jpush_id' });
        return obj.save();
    });
}
exports.saveOrUpdateJpushId = saveOrUpdateJpushId;
/**
 * 获取绑定的设备id
 * @type {getJpushIdByAccount}
 * @param params
 * @returns {null}
 */
function getJpushIdByAccount(params) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        let list = yield index_1.Models.token.find({ where: { accountId: params.accountId, type: 'jpush_id' } });
        if (!list || list.length <= 0) {
            return null;
        }
        var result = [];
        list.forEach(function (item) {
            result.push(item.token);
        });
        return result;
    });
}
exports.getJpushIdByAccount = getJpushIdByAccount;

//# sourceMappingURL=messagePush.js.map
