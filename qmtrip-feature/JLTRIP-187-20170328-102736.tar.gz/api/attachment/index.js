/**
 * Created by wyl on 15-12-26.
 */
'use strict';
const tslib_1 = require("tslib");
var sequelize = require("common/model").importModel("./models");
var Owner = sequelize.models.Owner;
var API = require("common/api");
var config = require('config');
let Logger = require('common/logger');
let logger = new Logger("attachment");
const fs = require("fs");
const path = require("path");
function fs_exists(file) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        try {
            yield fs.statAsync(file);
            return true;
        }
        catch (e) {
            if (e.code != 'ENOENT')
                throw e;
            return false;
        }
    });
}
class ApiAttachment {
    /**
     * 绑定拥有者
     *
     * @param {Object} params
     * @param {String} params.fileId
     * @param {UUID} params.accountId
     */
    static bindOwner(params) {
        var fileId = params.fileId;
        var accountId = params.accountId;
        return Owner.create({
            fileId: fileId,
            accountId: accountId
        });
    }
    static getOwner(params) {
        var fileId = params.fileId;
        var accountId = params.user_id;
        return Owner.findOne({ where: { accountId: accountId, fileId: fileId } })
            .then(function (owner) {
            if (owner) {
                return true;
            }
            else {
                return false;
            }
        });
    }
    /**
     * 获取自己上传的附件
     *
     * @param {Object} params
     * @param {String} params.fileId
     * @param {UUID} params.accountId
     */
    static getSelfAttachment(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var fileId = params.fileId;
            var accountId = params.accountId;
            // var owner = await Owner.findOne({where: {fileId: fileId, accountId: accountId}});
            // if (!owner) {
            //     throw L.ERR.PERMISSION_DENY();
            // }
            var attachment = yield API.attachments.getAttachment({ id: fileId, isZoom: 'off' });
            // var filepath = path.join('tmp', attachment.id);
            // fs.writeFile(filepath, attachment.content, {encoding: "binary"});
            return attachment;
        });
    }
    static getFileCache(params) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            try {
                var id = params.id;
                var isPublic = params.isPublic;
                var cachePath = config.upload.privateDir;
                if (isPublic)
                    cachePath = config.upload.publicDir;
                if (!id) {
                    return null;
                }
                var contentType = 'image/png';
                var filepath = path.join(cachePath, id);
                var cache_exist = yield fs_exists(filepath);
                if (!cache_exist) {
                    var attachment = yield API.attachments.getAttachment({ id: id });
                    if (!attachment) {
                        return null;
                    }
                    if (attachment.isPublic !== isPublic)
                        return null;
                    contentType = attachment.contentType;
                    var dir_exist = yield fs_exists(cachePath);
                    if (!dir_exist) {
                        yield fs.mkdirAsync(cachePath, '755');
                    }
                    var content = new Buffer(attachment.content, "base64");
                    yield fs.writeFileAsync(filepath + '.type', contentType, 'utf8');
                    yield fs.writeFileAsync(filepath, content, { encoding: "binary" });
                }
                else {
                    try {
                        contentType = yield fs.readFileAsync(filepath + '.type', 'utf8');
                    }
                    catch (e) { }
                }
                return { file: filepath, type: contentType };
            }
            catch (e) {
                logger.error(e.stack || e);
                return null;
            }
        });
    }
}
ApiAttachment.__initHttpApp = require('./upload');
module.exports = ApiAttachment;

//# sourceMappingURL=index.js.map
