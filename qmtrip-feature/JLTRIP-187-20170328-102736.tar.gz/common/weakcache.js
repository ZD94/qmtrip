"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var weak = require('weak');
var caches = {};
class WeakCache {
    constructor(id) {
        this.id = id;
        this.cache = new Map();
    }
    put(key, value) {
        if (value == undefined) {
            this.remove(key);
            return value;
        }
        var ref = weak(value, () => {
            var ref2 = this.cache.get(key);
            if (ref === ref2) {
                this.remove(key);
            }
        });
        this.cache.set(key, ref);
        return value;
    }
    get(key) {
        var ref = this.cache.get(key);
        if (ref == undefined)
            return undefined;
        return weak.get(ref);
    }
    remove(key) {
        this.cache.delete(key);
    }
    removeAll() {
        this.cache.clear();
    }
    destroy() {
    }
}
exports.WeakCache = WeakCache;
function createCache(cacheId) {
    if (cacheId in caches) {
        throw new Error('cache id is used.');
    }
    caches[cacheId] = new WeakCache(cacheId);
    return caches[cacheId];
}
exports.createCache = createCache;

//# sourceMappingURL=weakcache.js.map
