'use strict';

var request = require('request');

function topromise (req){
    var res = {};
    var buf = [];
    var length = 0;
    return new Promise(function(resolve, reject){
        req
            .on('error', function (e) {
                reject(e);
            })
            .on('response', function (incomingMsg) {
                res = incomingMsg;
            })
            .on('data', function (data) {
                buf.push(data);
                length += data.length;
            })
            .on('end', function () {
                res.body = Buffer.concat(buf, length).toString();
                resolve(res);
            });
    });
}

function requestp(){
    return topromise(request.apply(null, arguments));
}

function wrap_requestp_func(funcname){
    var func = request[funcname];
    requestp[funcname] = function(){
        return topromise(func.apply(null, arguments));
    };
}
wrap_requestp_func('get');
wrap_requestp_func('post');
wrap_requestp_func('put');
wrap_requestp_func('patch');

module.exports = requestp;
