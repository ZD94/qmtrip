"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const cluster = require("cluster");
const node_schedule = require("node-schedule");
const Logger = require("./logger");
var logger = new Logger("schedule");
var tasks = {};
if (cluster.isMaster) {
    cluster.on('message', function (msg) {
        if (msg.cmd == 'schedule') {
            if (tasks[msg.id])
                return;
            scheduler(msg.timer, msg.id, function () {
                logger.warn('dummy scheduler function should not be called.');
            });
        }
    });
}
else {
    process.on("message", function (msg) {
        if (msg.cmd == 'schedule') {
            var func = tasks[msg.id];
            if (func) {
                //logger.info("%s 处理定时任务 %s", process.title, msg.id);
                func();
            }
            else {
                logger.error('scheduler function (%s) is not defined.', msg.id);
            }
        }
    });
}
/**
 * 添加定时任务
 *
 * @param {String} timer 触发条件
 * @param {String} id 任务ID
 * @param {Function} func 执行函数
 */
function scheduler(timer, id, func) {
    tasks[id] = func;
    if (cluster.isMaster) {
        node_schedule.scheduleJob(timer, function () {
            var keys = Object.keys(cluster.workers);
            if (keys.length) {
                var idx = Math.floor(Math.random() * keys.length);
                cluster.workers[keys[idx]].send({ cmd: "schedule", id: id });
            }
            else {
                //如果就一个进程,直接主进程执行,不用往外抛了
                func();
            }
        });
    }
    else {
        process.send({ cmd: 'schedule', timer: timer, id: id });
    }
}
module.exports = scheduler;

//# sourceMappingURL=scheduler.js.map
