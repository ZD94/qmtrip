"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const util = require("util");
var data = [];
var logcache = [];
var enabled = false;
var spaces = [];
for (var i = 0; i < 10; i++) {
    spaces[i] = ' '.repeat(i);
}
function perfnow() {
    var now = process.hrtime();
    return now[0] * 1e6 + now[1] / 1e3;
}
;
class PerfData {
    constructor(desc, indent) {
        this.desc = desc;
        this.begin = perfnow();
        indent = indent ? indent : 1;
        this.indent = '>'.repeat(indent);
    }
    stat(desc) {
        var now = perfnow();
        var diff = (Math.round(now - this.begin) / 1e3).toString();
        this.begin = now;
        if (diff.length < 10) {
            diff = spaces[10 - diff.length] + diff;
        }
        logcache.push({ indent: this.indent, time: diff, desc: this.desc });
        this.desc = desc;
    }
}
function init(desc) {
    enabled = true;
    this.push(desc, 1);
}
exports.init = init;
function end() {
    if (!enabled)
        return;
    this.pop();
    data = [];
    var log = logcache
        .map(function (stat) {
        return util.format('%s perf%s%s ms: %s', process.title, stat.indent, stat.time, stat.desc);
    })
        .join('\n');
    console.log(log);
    logcache = [];
    if (data.length != 0) {
        console.log('perf end with datas.');
    }
}
exports.end = end;
function push(desc, indent) {
    if (!enabled)
        return;
    indent = indent ? indent : 2;
    if (data[0])
        indent = data[0].indent.length + indent;
    data.unshift(new PerfData(desc, indent));
}
exports.push = push;
function pop() {
    if (!enabled || !data[0])
        return;
    this.stat('end');
    data.shift();
}
exports.pop = pop;
function stat(desc) {
    if (!enabled || !data[0])
        return;
    data[0].stat(desc);
}
exports.stat = stat;

//# sourceMappingURL=perf.js.map
