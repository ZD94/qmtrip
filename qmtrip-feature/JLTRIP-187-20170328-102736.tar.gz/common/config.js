"use strict";

/**
 * 组建配置文件，并将配置文件信息写入到全局C变量中
 *
 * 根据 config中 env变量加载不同配置文件，config.all.json中加载通用配置信息
 * test,dev,product根据不同环境加载差异配置
 */

var fs = require('fs');
var path = require('path');
var _ = require('lodash');
var traverse = require('traverse');

var ROOT_DIR = path.normalize(path.join(__dirname, '..'));

function loadConfig(confdir, root_dir) {
    if (root_dir)
        ROOT_DIR = root_dir;
    //通用配置
    var config_file = path.join(confdir, "config.json");
    var config = require(config_file);
    //本地配置
    var local_file = path.join(confdir, "config.local.json");
    if (fs.existsSync(local_file)) {
        var localConfig = {};
        localConfig = require(local_file);

        _.merge(config, localConfig);
    }
    config.ROOT_DIR = ROOT_DIR;

    //替换变量
    var regVar = /\$\{\{([\w\.]+)}}/g;
    traverse(config).forEach(function(value){
        if(typeof value != 'string')
            return;
        var result = value.replace(regVar, function (match, varname) {
            var value = _.get(config, varname);
            if (value == undefined)
                throw new Error('Variable not found:'+varname);
            return value;
        });
        this.update(result);
    });
    //替换环境变量
    var regEnvVar = /\$\{(JL_APP_[A-Z_]+)}/g;
    traverse(config).forEach(function(value){
        if(typeof value != 'string')
            return;
        var result = value.replace(regEnvVar, function (match, varname) {
            var value = process.env[varname];
            if (value == undefined)
                throw new Error('Enviroment rariable not found:'+varname);
            return value;
        });
        this.update(result);
    });
    Object.freeze(config);  //对象设置为只读

    return config;
}

module.exports = loadConfig;
