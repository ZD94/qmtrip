"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const MAX_SIGNED_INT_VALUE = Math.pow(2, 32) - 1;
function ToUint32(value) {
    return value >>> 0;
}
function getMaxIndexProperty(object) {
    var maxIndex = -1;
    for (var prop in object) {
        let index = ToUint32(prop);
        let isValidProperty = (String(index) === prop &&
            index !== MAX_SIGNED_INT_VALUE &&
            object.hasOwnProperty(prop));
        if (isValidProperty && index > maxIndex) {
            maxIndex = index;
        }
    }
    return maxIndex;
}
function fixArraySubclass(subclass) {
    if (!(subclass.prototype instanceof Array)) {
        throw new TypeError('fixArraySubclass must called with subclass of Array');
    }
    var constructorOld = subclass;
    subclass = (new Function('cls', 'return function ' + constructorOld.name + ' (){' +
        ' var self = this; ' +
        ' var args = [].slice.call(arguments); ' +
        ' args.unshift(null); ' +
        ' var f = cls.bind.apply(cls, args); ' +
        ' arr = new f(); ' +
        ' Object.keys(arr).forEach(function(k){ ' +
        ' self[k] = arr[k]; ' +
        ' }); }'))(constructorOld);
    Object.defineProperty(constructorOld.prototype, 'length', {
        get: function () {
            var maxIndexProperty = +getMaxIndexProperty(this);
            return Math.max(this._length, maxIndexProperty + 1);
        },
        set: function (value) {
            var constrainedValue = ToUint32(value);
            if (constrainedValue !== +value) {
                throw new RangeError();
            }
            for (var i = constrainedValue, len = this._length; i < len; i++) {
                delete this[i];
            }
            this._length = constrainedValue;
        }
    });
    subclass.prototype = constructorOld.prototype;
    Object.setPrototypeOf(subclass, constructorOld);
    //subclass.__proto__ = constructorOld;
    return subclass;
}
exports.fixArraySubclass = fixArraySubclass;
/**
 * @class 分页类 Paginate
 * @constructor
 * @param page {Number} 当前页
 * @param perPage {Number} 每页记录数
 * @param total {Number} 总记录数
 * @param items {Array} 当前页记录列表
 *
 * @example
 *  ```
 *  var Paginate = require(REAL_PATH+'/paginator')
 *  var paginate = new Paginate(1, 20, 100, users);
 *  //总页数
 *  var pages = paginate.pages;
 *  //是否有下一页
 *  if (paginate.hasNextPage() === true){}
 *  //是否有上一页
 *  if (paginate.hasPrevPage() === true){}
 *  //上一页
 *  paginate.prevPage()
 *  //下一页
 *  paginate.nextPage()
 *  //总条数
 *  paginate.total()
 *  //当前页条数
 *  paginate.currentPageTotal()
 *  //当前页所有数据
 *  paginate.items()
 *  ```
 */
class Paginate {
    constructor(page, perPage, total, items) {
        if (!page || page < 1) {
            page = 1;
        }
        else {
            page = Math.floor(page);
        }
        if (!perPage || perPage < 1) {
            perPage = 20;
        }
        else {
            perPage = Math.floor(perPage);
        }
        if (!total || total < 0) {
            total = 0;
        }
        else {
            total = Math.floor(total);
        }
        if (!items) {
            items = [];
        }
        this.page = page;
        this.perPage = perPage;
        this.total = total;
        this.items = items;
        this.currentPageTotal = items.length;
        this.pages = 0;
        if (this.total % this.perPage === 0) {
            this.pages = Math.floor(this.total / this.perPage);
        }
        else {
            this.pages = Math.floor(this.total / this.perPage) + 1;
        }
    }
    /**
     * 设置当前页数
     * @method setPage
     * @param page {Number}
     */
    setPage(page) {
        this.page = page;
    }
    /**
     * 设置每页条数
     * @method setPerPage
     * @param perPage {Number}
     */
    setPerPage(perPage) {
        this.perPage = perPage;
    }
    /**
     * 是否有上一页
     * @method hasPrevPage
     * @returns {Boolean}
     */
    hasPrevPage() {
        if (this.page > 1) {
            return true;
        }
        return false;
    }
    /**
     * 上一页
     * @method prevPage
     * @returns {Number}
     */
    prevPage() {
        if (this.page <= 1) {
            return 1;
        }
        return this.page - 1;
    }
    /**
     * 是否有下一页
     * @method hasNextPage
     * @returns {Boolean}
     */
    hasNextPage() {
        if (this.page < this.pages) {
            return true;
        }
        return false;
    }
    /**
     * 下一页
     * @method nextPage
     * @returns {Number}
     */
    nextPage() {
        if (this.page < this.pages) {
            return this.page + 1;
        }
        return this.pages;
    }
}
exports.Paginate = Paginate;

//# sourceMappingURL=paginate.js.map
