"use strict";

var fs = require('fs');
var path = require('path');

var patch_require_default = require('./node_es6mod');

var cwd = process.cwd();

require('./ts_helper');

var installed = false;

function register_ts_node(){
    if(installed)
        return;
    installed = true;
    require('ts-node').register({
        compiler: 'typescript',
        fast: true,
    });
    patch_require_default('.ts');
}

function register_ts(){
    if(installed)
        return;
    installed = true;
    var tsfiles = {};

    var tsconfig = require(path.join(process.cwd(), 'tsconfig.json'));
    var tmp_dir = path.normalize(path.join(cwd, tsconfig.compilerOptions.outDir));

    var convert = require('convert-source-map');
    require.extensions['.ts'] = ts_req;
    function ts_req(module, filename) {
        tsfiles[filename] = true;
        var jsfile = ts_to_js(filename, cwd, tmp_dir);
        var content = fs.readFileSync(jsfile, 'utf8');
        content = content.replace(convert.mapFileCommentRegex, '//# sourceMappingURL='+jsfile+'.map');
        module._compile(content, filename);
    }
    patch_require_default('.ts');

    var sourceMapSupport = require('source-map-support');
    sourceMapSupport.install({
        environment: 'node',
        retrieveSourceMap: retrieveSourceMap
    });
    function retrieveSourceMap(filename) {
        if (tsfiles[filename]) {
            var file = dest(filename) + '.map';
            return {
                url: file,
                map: fs.readFileSync(file, 'utf8')
            };
        }
    }
    function dest(filename) {
        var rel_dir = path.dirname(path.relative(cwd, filename));
        var basename = path.basename(filename, '.ts');
        return path.join(tmp_dir, rel_dir, basename + '.js');
    }
}

function ts_to_js(filename, base, tsOut) {
    filename = path.relative(base, filename);
    var dirname = path.dirname(filename);
    var basename = path.basename(filename, '.ts');
    return path.join(tsOut, dirname, basename + '.js');
}

function install(use_ts_node, initdir){
    if(installed)
        return;
    cwd = initdir || cwd;
    if(!fs.existsSync(path.join(cwd, 'tsconfig.json'))){
        return;
    }
    if(use_ts_node === undefined){
        var config = require('../config');
        use_ts_node = config.ts_node;
    }
    if(use_ts_node){
        register_ts_node();
    }else{
        register_ts();
    }
}
install.install = install;

module.exports = install;
