

function fix_export_default(module){
    if(module.exports.__esModule && module.exports.default){
        var m = module.exports;
        var def = m.default;
        Object.keys(m).forEach(function(k){
            if (k in def) {
                if(def[k] === m[k])
                    return;
                throw new SyntaxError('default export and export has same name but not same value:' + k);
            }
            def[k] = m[k];
        });
        module.exports = def;
    }
}

function patch_require_default(ext){
    ext = ext || '.js';
    var old_loader = require.extensions[ext];
    require.extensions[ext] = function(module, file){
        old_loader.apply(this, arguments);
        fix_export_default(module);
    }
}

patch_require_default('.js');

module.exports = patch_require_default;
