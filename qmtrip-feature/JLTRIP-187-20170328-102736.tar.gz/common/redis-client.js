/**
 * Created by wlh on 16/7/21.
 */
'use strict';
const redis = require("redis");
class SimpleRedisClient {
    //初始化redis连接参数
    static init(connectStr) {
        if (connectStr) {
            SimpleRedisClient._connectStr = connectStr;
        }
    }
    //获取客户端
    static getClient() {
        if (SimpleRedisClient._client) {
            SimpleRedisClient._client;
        }
        return redis.createClient(SimpleRedisClient._connectStr);
    }
    //获取值
    static simpleGet(key) {
        var client = SimpleRedisClient.getClient();
        return new Promise(function (resolve, reject) {
            client.get(key, function (err, result) {
                if (err)
                    return reject(err);
                if (!result)
                    return resolve(null);
                return resolve(JSON.parse(result));
            });
        });
    }
    //设置值
    static simpleSet(key, value, options) {
        var client = SimpleRedisClient.getClient();
        var ex = options.ex || 20 * 60;
        if (typeof value == 'object') {
            value = JSON.stringify(value);
        }
        return new Promise(function (resolve, reject) {
            client.set(key, value, "ex", ex, function (err) {
                if (err)
                    return reject(err);
                return resolve(value);
            });
        });
    }
    //删除值
    static simpleDel(key) {
        var client = SimpleRedisClient.getClient();
        return new Promise(function (resolve, reject) {
            return client.del(key, function (err) {
                if (err)
                    return reject(err);
                return resolve(true);
            });
        });
    }
    //广播
    static simplePublish(key, value) {
        var client = SimpleRedisClient.getClient();
        if (typeof value == 'object') {
            value = JSON.stringify(value);
        }
        return new Promise(function (resolve, reject) {
            client.publish(key, value, function (err) {
                if (err)
                    return reject(err);
                return resolve(value);
            });
        });
    }
}
SimpleRedisClient._connectStr = "redis://localhost:6379";
module.exports = SimpleRedisClient;

//# sourceMappingURL=redis-client.js.map
