'use strict';

var shimmer = require('shimmer');

var oldPromise = global.Promise;

var Bluebird;
try{
    Bluebird = require('bluebird');
    Bluebird.noConflict();
} catch (e){
    //...
}

require('zone.js');
require('zone.js/dist/long-stack-trace-zone.js');

var path = require('path');

var regSectionSep = /^\s+-+/;
var regSystemLine = /\(module.js:.*\)$/;
var replacePath = function(line){ return line; };
var pathIgnored = [
    '/zone.js/dist/',
    '/bluebird/js/(release|debug|instrumented|browser)/',
    '/common/ts_helper.js',
    '/common/zone.js'
];
if((typeof window !== 'undefined' && window['HTMLElement'])){
    //regIgnored = /\/script\/libs\/bundle\.(preload|base|angular|jquery|ionic)\.js/;
    pathIgnored.push('/babel-regenerator-runtime/');
}else{
    pathIgnored.push('/sequelize/lib/promise.js');
    pathIgnored.push('\\(module.js:\\d+:\\d+\\)');
    pathIgnored.push('\\(?node.js:\\d+:\\d+\\)?');
    pathIgnored.push('\\[object Generator\\].next \\(native\\)');
    pathIgnored.push('processImmediate \\[as _immediateCallback\\] \\(timers.js:\\d+:\\d+\\)');
    var projectDir = path.normalize(path.join(__dirname, '..'));
    replacePath = function(line){ return line.replace(/(\.\.[\\\/])+(common|api)/, projectDir+'/$2'); };
}
var regIgnored = '(('
    + pathIgnored
        .map(function(s){ return s.replace(/([\.])/g, '\\$1'); })
        .join(')|(')
    +'))';
regIgnored = regIgnored.replace(/\//g, '[\\\\/]');
regIgnored = new RegExp(regIgnored);

//regIgnored = /^$/;

function trimStackTrace(stack){
    //return stack;
    var lines = stack.split('\n');
    var sections = [[]];
    lines.forEach(function(line){
        if(regSectionSep.test(line)){
            sections.push([]);
        }
        sections[sections.length-1].push(line);
    })
    sections.forEach(function(section){
        for(var i=section.length-1; i>=0; i--){
            if(regSystemLine.test(section[i])){
                section.pop();
            }else{
                break;
            }
        }
    })
    for(var sec=0; sec<sections.length-1; sec++){
        var cur = sections[sec];
        var next = sections[sec+1];
        for(var i=cur.length-1, j=next.length-1; i>=0 && j>=0; i--, j--){
            if(cur[i] != next[j]){
                cur.splice(i+1);
                break;
            }
        }
    }
    return [].concat.apply([], sections)
        .filter(function(line){
            return !regIgnored.test(line);
        })
        .map(replacePath)
        .join('\n');
}

var trimStackTraceZoneSpec = {
    name: 'trim-stack-trace',
    onHandleError: function(parentZoneDelegate, currentZone, targetZone, error)
    {
        var parentTask = Zone.currentTask;
        if (error instanceof Error && parentTask) {
            var descriptor = Object.getOwnPropertyDescriptor(error, 'stack');
            if (descriptor) {
                var delegateGet = descriptor.get;
                var value = descriptor.value;
                descriptor = {
                    get: function() {
                        return trimStackTrace(delegateGet ? delegateGet.apply(this): value);
                    }
                };
                Object.defineProperty(error, 'stack', descriptor);
            } else {
                error.stack = trimStackTrace(error.stack);
            }
        }
        return parentZoneDelegate.handleError(targetZone, error);
    }
}

function forkStackTrace(){
    return Zone.current
        .fork(trimStackTraceZoneSpec)
        .fork(Zone['longStackTraceZoneSpec']);
}

module.exports = {
    forkStackTrace: forkStackTrace,
    shimCLS: shimCLS
};

var lendesc = Object.getOwnPropertyDescriptor(scheduleTask, 'length');
var length_configurable = lendesc.configurable;
function scheduleTask(tasks, args, argIndex){
    var zone = Zone.current;
    return function(task) {
        var arglen = args[argIndex].length;
        args[argIndex] = function invokeTask(){
            try {
                return task.invoke.apply(this, arguments);
            } finally {
                tasks.forEach(function(t){
                    if(t !== task)
                        zone.cancelTask(t);
                });
            }
        }
        if(length_configurable){
            Object.defineProperty(args[argIndex], 'length', {
                get: function(){ return arglen; }
            })
        }
    };
}

var cancelTask = function(task){
    //console.log('cancel task');
}
// functionName: The Promise function that should be shimmed
// fnArgs: The arguments index that should be CLS enabled (typically all callbacks). Offset from last if negative
function shimCLS(object, functionName, fnArgs){
    shimmer.wrap(object, functionName, function(fn) {
        return function () {
            var args = arguments;
            var tasks = [];
            for (var x = 0; x < fnArgs.length; x++) {
                var i = fnArgs[x] < 0 ? args.length + fnArgs[x] : fnArgs[x];
                if (i < args.length && typeof args[i] === 'function') {
                    tasks.push(
                        Zone.current.scheduleMacroTask(functionName, args[i],
                            {},
                            scheduleTask(tasks, args, i),
                            cancelTask
                        )
                    );
                }
            }
            return fn.apply(this, args);
        };
    });
}

if(process){
    shimCLS(process, 'nextTick', [0]);
}

if(Bluebird){
    if(oldPromise === Bluebird){
        global.Promise = Bluebird;
    }
    
    // Core
    shimCLS(Bluebird, 'join', [-1]);
    shimCLS(Bluebird.prototype, 'then', [0, 1]);
    shimCLS(Bluebird.prototype, 'spread', [0, 1]);
    shimCLS(Bluebird.prototype, 'catch', [-1]);
    shimCLS(Bluebird.prototype, 'error', [0]);
    shimCLS(Bluebird.prototype, 'finally', [0]);

    // Collections
    shimCLS(Bluebird, 'map', [1]);
    shimCLS(Bluebird, 'reduce', [1]);
    shimCLS(Bluebird, 'filter', [1]);
    shimCLS(Bluebird, 'each', [1]);
    shimCLS(Bluebird.prototype, 'map', [0]);
    shimCLS(Bluebird.prototype, 'reduce', [0]);
    shimCLS(Bluebird.prototype, 'filter', [0]);
    shimCLS(Bluebird.prototype, 'each', [0]);

    // Promisification
    shimCLS(Bluebird.prototype, 'nodeify', [0]);

    // Utility
    shimCLS(Bluebird.prototype, 'tap', [0]);

    // Error management configuration
    shimCLS(Bluebird.prototype, 'done', [0, 1]);
}

//patch XMLHttpRequest for synchronous request
if((typeof window !== 'undefined' && window['XMLHttpRequest'])) {
    shimmer.wrap(window.XMLHttpRequest.prototype, 'open', function(fn){
        return function(method, url, async){
            if(arguments.length >= 3 && async == false){
                this.__sync = true;
            }
            return fn.apply(this, arguments);
        }
    })
    shimmer.wrap(window.XMLHttpRequest.prototype, 'send', function(fn){
        return function(){
            if(this.__sync){
                return this[Zone['__symbol__']('send')].apply(this, arguments);
            }
            return fn.apply(this, arguments);
        }
    })
}
