/**
 * Created by wlh on 15/12/9.
 */
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var regEmail = /^[\w\.\-]+@\w[\w\-\.]+\w$/;
function isEmail(str) {
    return regEmail.test(str);
}
exports.isEmail = isEmail;
;
var regMobile = /^1\d{10}$/;
function isMobile(str) {
    return regMobile.test(str);
}
exports.isMobile = isMobile;
;
var regMoney = /^\d+(\.\d{1,2})?$/;
function isMoney(str) {
    return regMoney.test(str);
}
exports.isMoney = isMoney;
;
var regHanZi = /^[\u4e00-\u9fa5]+$/;
function isHanZi(str) {
    return regHanZi.test(str);
}
exports.isHanZi = isHanZi;
;
var regUrl = /^http(s)?:\/\/[\w\-\.]+$/;
function isUrl(str) {
    return regUrl.test(str);
}
exports.isUrl = isUrl;
;
var regDate = /^\d{4}-\d{1,2}-\d{1,2}$/;
function isDate(str) {
    return regDate.test(str);
}
exports.isDate = isDate;
;
var regDateTime = /^\d{4}-\d{1,2}-\d{1,2}\s\d{1,2}:\d{1,2}(:\d{1,2})?$/;
function isDateTime(str) {
    return regDateTime.test(str);
}
exports.isDateTime = isDateTime;
;
var regTime = /^\d{1,2}:\d{1,2}(:\d{1,2})?$/;
function isTime(str) {
    return regTime.test(str);
}
exports.isTime = isTime;
;

//# sourceMappingURL=validate.js.map
