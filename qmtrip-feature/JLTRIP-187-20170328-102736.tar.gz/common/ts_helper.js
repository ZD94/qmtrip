
(function(g){
    "use strict";
    var tslib = require("tslib");

    g.__assign = tslib.__assign;
    g.__awaiter = tslib.__awaiter;
    g.__decorate = tslib.__decorate;
    g.__extends = tslib.__extends;
    g.__generator = tslib.__generator;
    g.__metadata = tslib.__metadata;
    g.__param = tslib.__param;
    g.__rest = tslib.__rest;

})(global || window);
