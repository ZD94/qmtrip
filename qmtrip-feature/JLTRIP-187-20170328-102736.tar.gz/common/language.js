/**
 * Created by wlh on 15/8/17.
 */
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const util = require("util");
const moment = require("moment");
var relativeTime = {
    "future": "%s之后",
    "past": "%s之前",
    "s": "1秒钟",
    "m": "1分钟",
    "mm": "%d分钟",
    "h": "1小时",
    "hh": "%d小时",
    "d": "1天",
    "dd": "%d天",
    "M": "1个月",
    "MM": "%d月",
    "y": "1年",
    "yy": "%d年"
};
//格式化时间插件
moment.locale('cn', { relativeTime: relativeTime });
var L;
(function (L) {
    class ERROR_CODE_C extends Error {
        constructor(code, msg) {
            super(msg);
            this.code = code;
            this.msg = msg;
        }
        format(...args) {
            args.unshift(this.msg);
            return util.format.apply(null, args);
        }
        toJSON() {
            return { code: this.code, msg: this.msg };
        }
    }
    L.ERROR_CODE_C = ERROR_CODE_C;
    function ERROR_CODE(code, msg) {
        var err = function (...args) {
            args.unshift(err.msg);
            var msg = util.format.apply(null, args);
            return new ERROR_CODE_C(err.code, msg);
        };
        err.code = code;
        err.msg = msg;
        return err;
    }
    L.ERROR_CODE = ERROR_CODE;
    L.ERR = {
        "SUCCESS": ERROR_CODE(0, "SUCCESS"),
        //通用错误
        "DATA_NOT_EXIST": ERROR_CODE(-1, "data参数为空"),
        "FORMAT_NOT_SUPPORT": ERROR_CODE(-2, "只支持xml或json格式"),
        "VERSION_NOT_EXIST": ERROR_CODE(-3, "版本号不存在"),
        "APP_ID_NOT_EXIST": ERROR_CODE(-4, "APP_ID 不存在或为空"),
        "SIGN_TYPE_NOT_SUPPORT": ERROR_CODE(-5, "不支持的签名类型"),
        "SIGN_TYPE_EMPTY": ERROR_CODE(-6, "签名类型为空"),
        "SIGN_EMPTY": ERROR_CODE(-7, "签名不存在"),
        "SIGN_ERROR": ERROR_CODE(-8, "签名错误"),
        "TIMESTAMP_EMPTY": ERROR_CODE(-9, "请求超时"),
        "TIMESTAMP_TIMEOUT": ERROR_CODE(-10, "请求超时"),
        "DATA_FORMAT_ERROR": ERROR_CODE(-11, "不是正确的XML或JSON"),
        "METHOD_NOT_EXIST": ERROR_CODE(-12, "method不存在"),
        "METHOD_NOT_SUPPORT": ERROR_CODE(-13, "接口不存在或已停止服务"),
        "MOBILE_EMPTY": ERROR_CODE(-14, "手机号不能为空"),
        "PWD_EMPTY": ERROR_CODE(-15, "密码不能为空"),
        "APP_FORBIDDEN": ERROR_CODE(-16, "应用已被禁用"),
        "IP_FORBIDDEN": ERROR_CODE(-17, "IP不在白名单中"),
        "HOST_FORBIDDEN": ERROR_CODE(-18, "域名不再白名单中"),
        "ACCOUNT_NOT_EXIST": ERROR_CODE(-19, "账号不存在"),
        "ACCOUNT_FORBIDDEN": ERROR_CODE(-20, "账号已被禁用,请联系鲸力科技官方客服"),
        "PASSWORD_NOT_MATCH": ERROR_CODE(-21, "账号与密码不匹配"),
        "TOKEN_EXPIRE": ERROR_CODE(-22, "TOKEN已失效或者不存在"),
        "REDIRECT_EMPTY": ERROR_CODE(-23, "跳转地址不存在"),
        "NEED_LOGIN": ERROR_CODE(-24, "登录已失效"),
        "ACCOUNT_TEMP_FORBIDDEN": ERROR_CODE(-25, "登录错误次数太多,1小时后重试"),
        "EMAIL_EMPTY": ERROR_CODE(-26, "邮箱不能为空"),
        "ACTIVE_URL_INVALID": ERROR_CODE(-27, "激活链接已经失效"),
        "INVITED_URL_INVALID": ERROR_CODE(-39, "邀请链接已经失效"),
        "INVITED_URL_FORBIDDEN": ERROR_CODE(-40, "邀请链接已经禁用"),
        "ACCOUNT_NOT_ACTIVE": ERROR_CODE(-28, "您的账号还未激活"),
        "EMAIL_HAS_REGISTRY": ERROR_CODE(-29, "邮箱已注册"),
        "EMAIL_FORMAT_INVALID": ERROR_CODE(-30, "邮件格式不正确"),
        "EMAIL_SUFFIX_INVALID": ERROR_CODE(-36, "请输入本公司域名的邮箱"),
        "EMAIL_NOT_REGISTRY": ERROR_CODE(-31, "邮箱还未注册"),
        "PWD_ERROR": ERROR_CODE(-32, "密码错误"),
        "DOMAIN_HAS_EXIST": ERROR_CODE(-33, "邮箱后缀已注册"),
        "EMAIL_IS_PUBLIC": ERROR_CODE(-34, "暂未开通公共邮箱注册"),
        "NOP_METHOD": ERROR_CODE(-35, "不可操作方法"),
        "NOTALLOWED_MODIFY_EMAIL": ERROR_CODE(-36, "邮箱不允许被修改"),
        "NO_VALIDATE_MOBILE": ERROR_CODE(-37, "您的手机号还未验证"),
        "NO_VALIDATE_EMAIL": ERROR_CODE(-38, "您的邮箱还未验证"),
        "USERNAME_EMPTY": ERROR_CODE(-39, "登录账号不能为空"),
        "USERNAME_ERR_FORMAT": ERROR_CODE(-40, "登录账号格式不正确"),
        "INVALID_PROMO_CODE": ERROR_CODE(-41, "无效优惠码"),
        "TRAVEL_POLICY_NOT_EXIST": ERROR_CODE(-50, "差旅标准没有设置或不存在"),
        "CITY_NOT_EXIST": ERROR_CODE(-51, "城市信息不存在"),
        "CHECK_IN_DATE_FORMAT_ERROR": ERROR_CODE(-52, "入住日期格式不正确"),
        "CHECK_OUT_DATE_FORMAT_ERROR": ERROR_CODE(-53, "离开日期格式不正确"),
        "LEAVE_DATE_FORMAT_ERROR": ERROR_CODE(-54, "出发日期格式不正确"),
        "GO_BACK_DATE_FORMAT_ERROR": ERROR_CODE(-55, "返程日期格式不正确"),
        "ABROAD_TRAVEL_POLICY_NOT_EXIST": ERROR_CODE(-56, "没有开启或者设置国外差旅标准"),
        "TRAVEL_POLICY_NAME_REPEAT": ERROR_CODE(-57, "该标准名称已存在，请重新设置"),
        "ERROR_CODE_REDIFINE": ERROR_CODE(-99, "错误码重复定义: %j, %s, %d, %s"),
        "MOBILE_HAS_REGISTRY": ERROR_CODE(-100, "手机号已注册"),
        "MOBILE_NOT_CORRECT": ERROR_CODE(-101, "手机号格式不正确"),
        "PASSWORD_EMPTY": ERROR_CODE(-102, "密码为空"),
        "USER_NOT_EXIST": ERROR_CODE(-103, "用户不存在"),
        "USER_FORBIDDEN": ERROR_CODE(-104, "账号已被禁用"),
        "PASSWORD_ERROR": ERROR_CODE(-105, "密码错误"),
        "APP_ID_EMPTY": ERROR_CODE(-106, "APP_ID为空"),
        "APP_NOT_EXIST": ERROR_CODE(-107, "APP不存在"),
        "TIME_EXPIRE": ERROR_CODE(-109, "请求已超时"),
        "NOT_SUPPORT_METHOD": ERROR_CODE(403, "不支持的请求方式"),
        "CODE_EMPTY": ERROR_CODE(-110, "验证码为空"),
        "NICKNAME_EMPTY": ERROR_CODE(-111, "昵称为空"),
        "CODE_ERROR": ERROR_CODE(-112, "验证码错误"),
        "IP_EMPTY": ERROR_CODE(-113, "IP地址为空"),
        "PAYMENT_PWD_FORMAT_ERROR": ERROR_CODE(-120, "支付密码格式不正确"),
        "PAYMENT_PWD_ERROR": ERROR_CODE(-121, "支付密码不正确"),
        "PAYMENT_PWD_NOT_SET": ERROR_CODE(-122, "支付密码还未设置"),
        "BALANCE_NOT_ENOUGH": ERROR_CODE(-122, "余额不足"),
        "MONEY_FORMAT_ERROR": ERROR_CODE(-123, "金额格式不正确"),
        "MONEY_CHANGE_CHANNEL_EMPTY": ERROR_CODE(-124, "金额变动渠道为空"),
        "PAYMENT_PWD_HAS_SET": ERROR_CODE(-124, "支付密码已经设置，如需修改请调用修改接口"),
        "PAYMENT_PWD_EQUAL_LOGIN_PWD": ERROR_CODE(-125, "支付密码不能与登录密码一致"),
        "BANK_CARD_TYPE_EMPTY": ERROR_CODE(-126, "银行卡类型不能为空"),
        "BANK_CARD_NO_EMPTY": ERROR_CODE(-127, "银行卡号不能为空"),
        "BANK_BELONG_EMPTY": ERROR_CODE(-128, "所属银行不能为空"),
        "MONEY_CHANGE": ERROR_CODE(-129, "变动金额不能为空"),
        "CHANGE_STATUS": ERROR_CODE(-130, "变动类型不能为空"),
        "PAYMENT_PWD_EMPTY": ERROR_CODE(-131, "支付密码为空"),
        "WITHDRAW_ACCOUNTID_EMPTY": ERROR_CODE(-132, "提现账号为空"),
        "ISLANDER_ID_EMPTY": ERROR_CODE(-133, "用户id为空"),
        "ORDERNO_EMPTY": ERROR_CODE(-134, "订单编号不能为空"),
        "MOBILE_MSG_SEND_OUT_LIMIT": ERROR_CODE(-135, "手机发送短信次数超过上限"),
        "IP_MSG_SEND_OUT_LIMIT": ERROR_CODE(-136, "IP发送短信次数超过上限"),
        "OPEN_ID_INVALID": ERROR_CODE(-137, "OPEN_ID无效"),
        "COMPANY_NOT_EXIST": ERROR_CODE(137, "该企业不存在"),
        "TRIP_PLAN_NOT_EXIST": ERROR_CODE(-138, "计划单/预算单不存在"),
        "CONSUME_DETAIL_NOT_EXIST": ERROR_CODE(-139, "差旅消费明细记录不存在"),
        "AGENCY_NOT_EXIST": ERROR_CODE(-140, "代理商不存在"),
        "AGENCY_USER_NOT_EXIST": ERROR_CODE(-141, "代理商用户不存在"),
        "INVALID_ARGUMENT": ERROR_CODE(-150, "参数 %s 不正确"),
        "INVALID_FORMAT": ERROR_CODE(-151, "参数 %s 格式不正确"),
        "TRAVEL_BUDGET_NOT_FOUND": ERROR_CODE(-152, "预算结果不存在"),
        "TRIP_DETAIL_FOUND": ERROR_CODE(-153, "出差详情不存在"),
        "TRIP_PLAN_STATUS_ERR": ERROR_CODE(-154, "出差计划状态不正确"),
        "LINE_ID_EMPTY": ERROR_CODE(-200, "线路ID为空"),
        "LINE_NOT_EXIST": ERROR_CODE(-201, "线路不存在"),
        "TEAM_NOT_EXIST": ERROR_CODE(-202, "工作团队不存在"),
        "MONEY_STATUS_ERROR": ERROR_CODE(-203, "资金变动不明确"),
        "MONEY_CHANGE_REASON_EMPTY": ERROR_CODE(-204, "资金变动原因不能为空"),
        "ORDER_ID_EMPTY": ERROR_CODE(-300, "订单号不存在"),
        "ORDER_HAS_PAYED": ERROR_CODE(-301, "重复支付订单"),
        "ORDER_NOT_EXIST": ERROR_CODE(-302, "订单不存在"),
        "ORDER_HAS_APPLIED_REFUND": ERROR_CODE(-302, "订单已申请退款"),
        "ORDER_REFUND_NOT_EXIST": ERROR_CODE(-303, "退款申请不存在"),
        "SCORE_ERROR": ERROR_CODE(-304, "积分格式不正确"),
        "TRANSFORM_TARGET_EQUAL_SELF": ERROR_CODE(-305, "转账双方是同一账户"),
        "ORDER_HAS_CONFIRM": ERROR_CODE(-306, "订单已确认"),
        "ORDER_HAS_RELATED": ERROR_CODE(-307, "您已关联过该订单"),
        "ORDER_NOT_YOURS": ERROR_CODE(-308, "只能使用自己的订单"),
        "HAS_NOT_BIND": ERROR_CODE(-309, "您还未绑定账号"),
        "BIND_ACCOUNT_ERR": ERROR_CODE(-310, "绑定账号验证失败"),
        "SHORT_OF_POINT": ERROR_CODE(-311, "积分不足"),
        "COMPANY_SHORT_OF_MONEY_FUND": ERROR_CODE(-312, "企业账户余额不足"),
        "BAD_REQUEST": ERROR_CODE(400, "错误的请求"),
        "UNAUTHORIZED": ERROR_CODE(401, "未授权"),
        "PAYMENT_REQUIRED": ERROR_CODE(402, "需要支付"),
        "FORBIDDEN": ERROR_CODE(403, "没有权限访问"),
        "PERMISSION_DENY": ERROR_CODE(403, "没有权限访问: %s"),
        "NOT_FOUND": ERROR_CODE(404, "资源 %s 不存在"),
        //"BAD_REQUEST": ERROR_CODE(405, "错误的请求"),
        "NOT_ACCEPTABLE": ERROR_CODE(406, "请求不可接受"),
        "REQUEST_TIMED_OUT": ERROR_CODE(408, "请求已超时"),
        "SYSTEM_ERROR": ERROR_CODE(-500, "系统错误,请稍后重试"),
        "INTERNAL_ERROR": ERROR_CODE(500, "服务器内部错误"),
        "NOT_IMPLEMENTED": ERROR_CODE(501, "功能未实现"),
        "SERVER_UNAVAILABLE": ERROR_CODE(503, "服务器不可用"),
        "VERSION_NOT_SUPPORTED": ERROR_CODE(505, "不支持此版本"),
        "BEYOND_LIMIT_NUM": ERROR_CODE(506, "%s个数已超过您企业的限额")
    };
    L.MSG = {
        "NEED_REFRESH_LOGIN": "密码修改成功，您需要重新登录",
        "SUCCESS_FIND_PASSWORD": "密码修改成功",
        "CHECK_CODE_ERROR": "验证码不正确",
        "MOBILE_FORMAT_ERROR": "手机号格式不正确",
        "SUCCESS_CREATE_TEAM": "恭喜您,工作团队已经创建成功!",
        "PASSWORD_EMPTY": "密码不能为空"
    };
    function DefineErrorCode(name, code, msg) {
        if (L.ERR[name]) {
            throw new Error(L.ERR['ERROR_CODE_REDIFINE'].format(L.ERR[name], name, code, msg));
        }
        for (var n in L.ERR) {
            if (L.ERR[n].code == code) {
                throw new Error(L.ERR['ERROR_CODE_REDIFINE'].format(L.ERR[n], name, code, msg));
            }
        }
        L.ERR[name] = ERROR_CODE(code, msg);
    }
    L.DefineErrorCode = DefineErrorCode;
})(L = exports.L || (exports.L = {}));
exports.default = L;
exports.ERROR_CODE_C = L.ERROR_CODE_C;
exports.ERROR_CODE = L.ERROR_CODE;
exports.ERR = L.ERR;
exports.MSG = L.MSG;
exports.DefineErrorCode = L.DefineErrorCode;

//# sourceMappingURL=language.js.map
