/**
 * Created by wlh on 16/4/12.
 */
'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const redis_1 = require("redis");
let redis = require("redis");
let Bluebird = require("bluebird");
Bluebird.promisifyAll(redis.RedisClient.prototype);
class RedisCache {
    constructor() {
        this._redis_conf = 'redis://localhost';
        this._prefix = 'cache';
    }
    get_redis() {
        if (!this._client) {
            this._client = redis_1.createClient(this._redis_conf);
            this._client.on('error', function (err) {
                console.error(err);
            });
        }
        return this._client;
    }
    init(conf) {
        if (conf.redis_conf) {
            this._redis_conf = conf.redis_conf;
        }
        if (conf.prefix) {
            this._prefix = conf.prefix;
        }
    }
    readAs(key) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            key = self._prefix + ':' + key;
            var client = self.get_redis();
            let value = yield client.getAsync(key);
            var result = null;
            try {
                result = JSON.parse(value);
            }
            catch (ex) {
                result = value;
            }
            return result;
        });
    }
    read(key) {
        return this.readAs(key);
    }
    write(key, content, ex) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let self = this;
            key = self._prefix + ':' + key;
            var client = self.get_redis();
            var _content;
            if (typeof content == 'object') {
                _content = JSON.stringify(content);
            }
            else {
                _content = content;
            }
            if (!ex) {
                return client.setAsync(key, content);
            }
            else {
                return client.set(key, _content, 'ex', ex);
            }
        });
    }
    remove(key) {
        var client = this.get_redis();
        key = this._prefix + ':' + key;
        return client.delAsync(key);
    }
}
exports.RedisCache = RedisCache;
let cache = new RedisCache();
exports.default = cache;

//# sourceMappingURL=cache.js.map
