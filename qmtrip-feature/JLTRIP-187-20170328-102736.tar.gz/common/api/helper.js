"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const scrubber = require("common/api/scrubber");
var scrubber_1 = require("common/api/scrubber");
exports.registerClass = scrubber_1.registerClass;
function scrubApiType(name) {
    return function (obj) {
        Object.keys(obj)
            .filter((k) => k.match(/^\$/))
            .forEach((k) => {
            delete obj[k];
        });
        obj['__class'] = name;
        return obj;
    };
}
function regApiType(constructor) {
    var name;
    function registerAPIType(constructor) {
        name = name ? (name.endsWith('.') ? name + constructor.name : name) : constructor.name;
        scrubber.registerClass(constructor, name, scrubApiType(name));
    }
    ;
    if (typeof constructor == 'string') {
        name = constructor;
        return registerAPIType;
    }
    registerAPIType(constructor);
}
exports.regApiType = regApiType;
function validateApi(func, required, optional) {
    func['required_params'] = required;
    if (optional)
        func['optional_params'] = optional;
}
exports.validateApi = validateApi;
function requireParams(required, optional) {
    return function (target, key, desc) {
        let fn;
        if (desc) {
            fn = desc.value;
        }
        else {
            fn = target[key];
        }
        fn["required_params"] = required;
        if (optional) {
            fn["optional_params"] = optional;
        }
    };
}
exports.requireParams = requireParams;
function clientExport(target, propertyKey, descriptor) {
    target['__clientExported'] = true;
    if (descriptor)
        descriptor.enumerable = true;
}
exports.clientExport = clientExport;

//# sourceMappingURL=helper.js.map
