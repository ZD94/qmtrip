"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const fs = require("fs");
const path = require("path");
function requiredir(dir) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        var files = yield fs.readdirAsync(dir);
        files
            .filter(function (file) {
            return /.*\.[jt]s/.test(file);
        })
            .forEach(function (file) {
            require(path.join(dir, file));
        });
    });
}
function require_test(dir) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        var stats = yield fs.statAsync(dir);
        if (!stats.isDirectory()) {
            return;
        }
        var files = yield fs.readdirAsync(dir);
        files
            .filter(function (file) {
            return /.+\.test\.[jt]s/.test(file);
        })
            .forEach(function (file) {
            require(path.join(dir, file));
        });
        if (files.indexOf('test') == -1)
            return;
        return requiredir(path.join(dir, 'test'));
    });
}
function loadTests(dir) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        var files = [];
        try {
            files = yield fs.readdirAsync(dir);
        }
        catch (e) {
            if (e.code != 'ENOENT')
                throw e;
        }
        var ps = files
            .filter(function (file) {
            return file != 'client' && file != 'sql';
        })
            .map(function (file) {
            return require_test(path.join(dir, file));
        });
        return Promise.all(ps);
    });
}
exports.loadTests = loadTests;

//# sourceMappingURL=loadtests.js.map
