"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const net = require("net");
const Logger = require("../logger");
var logger = new Logger('api');
const perf = require("../perf");
var dnode = require("dnode");
const wrap_1 = require("./wrap");
var inject = require('reconnect-core');
var reconnect = inject(function () {
    return net.connect.apply(null, arguments);
});
function importSvc(api, connect, modnames) {
    if (!modnames) {
        modnames = ['*'];
    }
    if (typeof modnames == 'string') {
        modnames = [modnames];
    }
    if (modnames.length == 0)
        return Promise.resolve();
    if (api[modnames[0]] != undefined)
        return Promise.resolve();
    var defer = Promise.defer();
    var is_reconnect = false;
    var modnames_saved = [];
    reconnect(function (stream) {
        var d = dnode();
        d.on('error', function (err) {
            logger.error('dnode error:', err.stack || err);
        });
        d.on('remote', function (remote) {
            remote.getModuleListAsync = Promise.promisify(remote.getModuleList);
            remote.requireAsync = Promise.promisify(remote.require);
            var step;
            if (modnames[0] == '*')
                step = remote.getModuleListAsync();
            else
                step = Promise.resolve(modnames);
            step
                .then(function (modnames) {
                var list = modnames
                    .map(function (modname) {
                    return remote.requireAsync(modname)
                        .then(function (mod) {
                        var mod_wrap = wrap_1.wrapRemoteModule(mod, modname, api._.emitter, 'RpcCall');
                        api[modname] = mod_wrap;
                        modnames_saved.push(modname);
                    })
                        .catch(function (err) {
                        logger.error('module %s is not loaded.', modname);
                    });
                });
                return Promise.all(list);
            })
                .then(function () {
                if (is_reconnect)
                    return;
                is_reconnect = true;
                defer.resolve();
            })
                .catch(function (err) {
                defer.reject(err);
            });
        });
        d.pipe(stream).pipe(d);
    })
        .on('connect', function (con) {
        logger.info('connected to ' + connect.host + ':' + connect.port);
    })
        .on('reconnect', function (n, delay) {
        if (n > 0)
            logger.info('reconnect(' + n + ',' + delay + ') to ' + connect.host + ':' + connect.port);
    })
        .on('disconnect', function (err) {
        for (var modname of modnames_saved)
            delete api[modname];
        modnames_saved = [];
        if (is_reconnect)
            logger.warn('disconnect from ' + connect.host + ':' + connect.port);
    })
        .on('error', function (err) {
        if (is_reconnect)
            logger.warn('error connect to ' + connect.host + ':' + connect.port);
        else
            defer.reject(err);
    }).connect(connect);
    return defer.promise;
}
function importSvcs(api) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        perf.stat('importRemoteSvcs');
        var remotes = api._.config.remotes
            .map(function (svc) {
            return importSvc(api, svc.connect, svc.modules);
        });
        return Promise.all(remotes);
    });
}
exports.importSvcs = importSvcs;

//# sourceMappingURL=remote.js.map
