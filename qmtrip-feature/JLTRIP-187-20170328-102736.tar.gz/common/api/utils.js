"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function callForEach(modules, funcname, ...args) {
    var ret = Object.keys(modules)
        .map(function (modname) {
        var mod = modules[modname];
        if (mod && mod[funcname] && typeof mod[funcname] == 'function')
            return mod[funcname].apply(mod, args);
    })
        .filter((v) => v);
    if (ret.length > 0 && ret[0].then)
        return Promise.all(ret);
}
exports.callForEach = callForEach;

//# sourceMappingURL=utils.js.map
