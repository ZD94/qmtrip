"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const path = require("path");
const fs = require("fs");
const _ = require("lodash");
const Sequelize = require("sequelize");
const model_1 = require("common/model");
var Logger = require('../logger');
var logger = new Logger('db');
function InitDB(sqlpath, DB, t) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        let initfile = path.join(sqlpath, 'init.sql');
        let buf = yield fs.readFileAsync(initfile);
        let initsql = buf.toString();
        yield DB.query(initsql, { transaction: t });
        let initjs = path.join(sqlpath, 'init.ts');
        if (!fs.existsSync(initjs)) {
            initjs = path.join(sqlpath, 'init.js');
            if (!fs.existsSync(initjs)) {
                initjs = undefined;
            }
        }
        if (initjs) {
            let func = require(initjs);
            let ret = func(DB, t);
            if (ret && typeof ret.then == 'function')
                yield ret;
        }
    });
}
function UpdateDB(file, DB, t) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        logger.info('update db for file:', file);
        if (file.match(/\.(js|ts)$/)) {
            let mod = require(file);
            let ret = mod(DB, t);
            if (ret && typeof ret.then == 'function')
                yield ret;
        }
        else {
            let sql = fs.readFileSync(file).toString();
            try {
                yield DB.query(sql, { transaction: t });
            }
            catch (err) {
                logger.error(`Error when InitSql for $(file}.`);
                throw err;
            }
        }
    });
}
function InitSql(sqlpath) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        let initfile = path.join(sqlpath, 'init.sql');
        if (!fs.existsSync(initfile))
            return;
        let initsql = fs.readFileSync(initfile).toString();
        let re = /^\s*\-\-\s*schema\s*\=\s*(\w+)/;
        let result = re.exec(initsql);
        if (result == null) {
            throw new Error('init.sql must begin with --schema={schema}');
        }
        let schema = result[1];
        //console.info(schema)
        let updatefiles = [];
        for (let f of fs.readdirSync(sqlpath)) {
            if (f.match(/update\..*\.(sql|js|ts)$/)) {
                updatefiles.push(f);
            }
        }
        let sql = "SELECT count(1) as total FROM information_schema.tables WHERE table_schema=:schema AND table_name='updatelog'";
        let data = yield model_1.DB.query(sql, { replacements: { schema: schema }, type: Sequelize.QueryTypes.SELECT });
        //logger.log(data);
        let exist = data[0]["total"];
        let t = yield model_1.DB.transaction();
        let options = {
            transaction: t,
        };
        try {
            //如果schema没有数据,进行初始化
            if (!exist || exist == 0) {
                logger.info('init db for schema:', schema);
                let sql = `CREATE SCHEMA IF NOT EXISTS ${schema}; CREATE TABLE IF NOT EXISTS ${schema}.updatelog (filename VARCHAR(50) NOT NULL);`;
                yield model_1.DB.query(sql, options);
                yield InitDB(sqlpath, model_1.DB, t);
                if (updatefiles.length > 0) {
                    let queries = [];
                    for (let f of updatefiles) {
                        queries.push(`INSERT INTO ${schema}.updatelog (filename) VALUES ('${f}');`);
                    }
                    sql = queries.join('');
                    yield model_1.DB.query(sql, options);
                }
            }
            else {
                //logger.info('check updatelog for schema:', schema);
                let res = yield model_1.DB.query(`SELECT filename FROM ${schema}.updatelog`, _.assign({}, options, { type: Sequelize.QueryTypes.SELECT }));
                //logger.log(res);
                let updated = {};
                for (let r of res) {
                    updated[r.filename] = true;
                }
                let notupdated = [];
                for (let f of updatefiles) {
                    if (updated[f])
                        continue;
                    notupdated.push(f);
                }
                if (notupdated.length > 0) {
                    logger.info('update db for schema:', schema);
                    let files = [];
                    let queries = [];
                    for (let f of notupdated) {
                        let file = path.join(sqlpath, f);
                        yield UpdateDB(file, model_1.DB, t);
                        yield model_1.DB.query(`INSERT INTO ${schema}.updatelog (filename) VALUES ('${f}')`, options);
                    }
                }
            }
            yield t.commit();
        }
        catch (err) {
            yield t.rollback();
            throw err;
        }
    });
}
exports.default = InitSql;

//# sourceMappingURL=sql_update.js.map
