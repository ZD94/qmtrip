"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const language_1 = require("common/language");
let exclude_keys = [
    'length',
    'name',
    'prototype',
    '$origin',
    'toJSON'
];
function filterKeys(name) {
    return name.substr(0, 2) == '__' || exclude_keys.indexOf(name) >= 0;
}
function fixErrorType(debug, ctxt) {
    var err = ctxt.__returns[0];
    if (err && !(err instanceof Error)) {
        var prefix = "";
        if (debug) {
            prefix = ctxt.__through + ':' + ctxt.__modname + '.' + ctxt.__funcname + ': ';
        }
        if (err.code && err.msg) {
            err = new language_1.default.ERROR_CODE_C(err.code, prefix + err.msg);
        }
        else if (err.message) {
            err = new Error(prefix + err.message);
        }
        else {
            err = new Error(prefix + (typeof err == 'string' ? err : JSON.stringify(err)));
        }
        ctxt.__returns[0] = err;
    }
}
exports.fixErrorType = fixErrorType;
function filterModule(onlyEnumerable) {
    var mod = this;
    var ret = {};
    var keys = onlyEnumerable ? Object.keys(mod) : Object.getOwnPropertyNames(mod);
    keys
        .forEach(function (funcname) {
        var func = mod[funcname];
        if (typeof func != 'function' || filterKeys(funcname)) {
            return;
        }
        ret[funcname] = func;
    });
    return ret;
}
exports.filterModule = filterModule;
function callForPromise(listener, context, args) {
    try {
        listener.emit('before' + context.__through, context);
        var ret = context.__function.apply(context.__this, args);
        if (typeof ret != 'object' || typeof ret.then != 'function')
            ret = Promise.resolve(ret);
        return ret
            .then(function (value) {
            //console.log('callForPromise callback then:', value);
            context.__returns = [null, value];
            listener.emit('after' + context.__through, context);
            return value;
        })
            .catch(function (err) {
            context.__returns = [err];
            listener.emit('after' + context.__through, context);
            throw context.__returns[0];
        });
    }
    catch (err) {
        //console.log('callForPromise callback catch:', err);
        context.__returns = [err];
        listener.emit('after' + context.__through, context);
        return Promise.reject(context.__returns[0]);
    }
}
function callWithCallback(listener, context, args) {
    var cb = args.pop();
    callForPromise(listener, context, args)
        .then(function (value) {
        cb(null, value);
    })
        .catch(function (err) {
        cb(err);
    });
}
function wrapAPIModule(mod, modname, listener, eventname, stream) {
    if (!mod)
        return mod;
    let proto = Object.getPrototypeOf(mod);
    if (typeof mod === 'object' && proto.constructor.name !== 'Object' && !mod['__objectTranslated']) {
        for (let k in mod) {
            if (mod[k] === proto.constructor)
                delete mod[k];
        }
        let keys = Object.getOwnPropertyNames(proto);
        for (let k of keys) {
            if (k == 'constructor')
                continue;
            let desc = Object.getOwnPropertyDescriptor(proto, k);
            if (desc.value && typeof desc.value == 'function')
                desc.value = desc.value.bind(mod);
            Object.defineProperty(mod, k, desc);
        }
        mod['__objectTranslated'] = true;
    }
    var origin = {};
    Object.defineProperty(mod, '$origin', {
        enumerable: false,
        configurable: false,
        writable: false,
        value: origin
    });
    Object.defineProperty(mod, 'toJSON', {
        enumerable: false,
        configurable: false,
        writable: false,
        value: filterModule
    });
    Object.getOwnPropertyNames(mod)
        .forEach(function (funcname) {
        var func = mod[funcname];
        var desc = Object.getOwnPropertyDescriptor(mod, funcname);
        Object.defineProperty(origin, funcname, desc);
        if (typeof func != 'function' || filterKeys(funcname)) {
            return;
        }
        mod[funcname] = wrapMethod(funcname, func);
    });
    return mod;
    function wrapMethod(funcname, func) {
        return function () {
            var args = [].slice.apply(arguments);
            var context = {
                __module: mod,
                __function: func,
                __modname: modname,
                __funcname: funcname,
                __arguments: args,
                __through: eventname,
                __this: stream ? stream : this
            };
            var zone = Zone.current;
            if (stream) {
                var session = {
                    accountId: stream['accountId'],
                    tokenId: stream['tokenId']
                };
                zone = zone.fork({
                    name: eventname + ':' + modname + '.' + funcname,
                    properties: {
                        stream: stream,
                        context: context,
                        clientType: context.__through,
                        session: session
                    }
                });
            }
            if (args.length > 0 && typeof args[args.length - 1] == 'function') {
                return zone.run(callWithCallback, this, [listener, context, args]);
            }
            else {
                return zone.run(callForPromise, this, [listener, context, args]);
            }
        };
    }
}
exports.wrapAPIModule = wrapAPIModule;
function callRemoteWithCallback(listener, context, args) {
    var cb = args.pop();
    function cb_wrap(err, value, wait) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (wait && wait['then'] && typeof wait['then'] === "function") {
                try {
                    yield wait;
                }
                catch (e) {
                    err = e;
                }
            }
            context.__returns = [err, value];
            listener.emit('after' + context.__through, context);
            cb.apply(this, context.__returns);
        });
    }
    Zone.current.scheduleMacroTask(context.__through + ':' + context.__modname + '.' + context.__funcname, cb_wrap, {}, (task) => { args.push(task.invoke); }, (task) => { });
    try {
        listener.emit('before' + context.__through, context);
        context.__function.apply(context.__this, args);
    }
    catch (err) {
        cb_wrap(err);
    }
}
function callRemoteForPromise(listener, context, args) {
    return new Promise(function (resolve, reject) {
        args.push(function (err, value) {
            if (err)
                reject(err);
            else
                resolve(value);
        });
        callRemoteWithCallback(listener, context, args);
    });
}
function wrapRemoteModule(mod, modname, listener, eventname) {
    if (!mod)
        return mod;
    var origin = {};
    Object.defineProperty(mod, '$origin', {
        enumerable: false,
        configurable: false,
        writable: false,
        value: origin
    });
    Object.keys(mod)
        .forEach(function (funcname) {
        var func = mod[funcname];
        origin[funcname] = func;
        if (funcname.substr(0, 2) == '__' || typeof func != 'function') {
            return;
        }
        mod[funcname] = wrapMethod(funcname, func);
    });
    return mod;
    function wrapMethod(funcname, func) {
        return function () {
            var args = [].slice.apply(arguments);
            var context = {
                __module: mod,
                __function: func,
                __modname: modname,
                __funcname: funcname,
                __arguments: args,
                __through: eventname,
                __this: this
            };
            if (args.length > 0 && typeof args[args.length - 1] == 'function') {
                return callRemoteWithCallback(listener, context, args);
            }
            else {
                return callRemoteForPromise(listener, context, args);
            }
        };
    }
}
exports.wrapRemoteModule = wrapRemoteModule;

//# sourceMappingURL=wrap.js.map
