"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const fs = require("fs");
const path = require("path");
const _ = require("lodash");
const Logger = require("../logger");
var logger = new Logger('api');
const perf = require("../perf");
const utils_1 = require("./utils");
const wrap_1 = require("./wrap");
function getModuleNames(dir) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        var files = [];
        try {
            files = yield fs.readdirAsync(dir);
        }
        catch (e) {
            if (e.code != 'ENOENT')
                throw e;
        }
        files = files.filter((f) => {
            return f != 'client' && f != 'sql' && !/^[_\.]/.test(f) && !/\.test\.js$/.test(f);
        });
        return files.map(function (f) {
            f = f.replace(/\.js$/, '');
            return { name: f, path: path.join(dir, f) };
        });
    });
}
function loadModules(modules, infos) {
    for (var info of infos) {
        perf.stat('loadModules ' + info.name);
        if (modules[info.name])
            logger.warn('module loaded twice:', info.name);
        var mod;
        try {
            mod = require(info.path);
        }
        catch (e) {
            console.error('Error when load', e, info.path);
            throw e;
        }
        if (mod.default) {
            mod = mod.default;
        }
        for (var funcname in mod) {
            var func = mod[funcname];
            if (typeof func == 'function' && func.required_params) {
                if (func.optional_params && func.optional_params != '*')
                    func.optional_params = _.union(func.optional_params, func.required_params);
                else
                    func.optional_params = func.required_params;
            }
        }
        modules[info.name] = mod;
    }
}
function wrapModules(api, modules, modprefix) {
    var wraped = {};
    for (var modname in modules) {
        perf.stat('wrapModules ' + modname);
        wraped[modname] = wrap_1.wrapAPIModule(modules[modname], modprefix + modname, api._.emitter, 'Call', null);
    }
    return wraped;
}
const model_1 = require("common/model");
function preloadSvcs(api) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        var modules = yield getModuleNames(api._.api_path);
        loadModules({}, modules);
    });
}
function importSvcs(api) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        perf.stat('importLocalSvcs');
        require('api/_service');
        model_1.initDefines();
        var modules = yield getModuleNames(api._.api_path);
        perf.stat('getModuleNames(api_path/client)');
        var api_client = path.join(api._.api_path, 'client');
        var webmodules = yield getModuleNames(api_client);
        perf.stat('importLocalModules');
        perf.push('importLocalModules');
        loadModules(api._.local_module, modules);
        _.extend(api, wrapModules(api, api._.local_module, ''));
        for (let modname in api._.local_module) {
            let mod = api._.local_module[modname];
            if (!mod.__clientExported) {
                continue;
            }
            let clientmod = {};
            for (let funcname in mod.$origin) {
                clientmod[funcname] = mod.$origin[funcname];
            }
            api._.web_module[modname] = clientmod;
        }
        loadModules(api._.web_module, webmodules);
        _.extend(api.client, wrapModules(api, api._.web_module, 'client.'));
        yield utils_1.callForEach(api, '__init');
        yield utils_1.callForEach(api.client, '__init');
        perf.pop();
    });
}
exports.importSvcs = importSvcs;
const sql_update_1 = require("./sql_update");
function initSqlFor(dir) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        var stats = yield fs.statAsync(dir);
        if (!stats.isDirectory())
            return;
        var sqldir = path.join(dir, 'sql');
        try {
            stats = yield fs.statAsync(sqldir);
        }
        catch (e) {
            if (e.code != 'ENOENT')
                throw e;
            return;
        }
        if (!stats.isDirectory())
            return;
        yield sql_update_1.default(sqldir);
    });
}
function initSql(api) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        yield preloadSvcs(api);
        require(path.join(api._.api_path, '_service'));
        model_1.initDefines();
        yield model_1.databaseSync();
        //首先初始化api/sql文件下文件
        yield initSqlFor(api._.api_path);
        //执行初始化数据库脚本
        var files = yield fs.readdirAsync(api._.api_path);
        var dirs = files
            .filter(function (file) {
            return file != 'client' && file != 'sql';
        })
            .map(function (file) {
            return path.join(api._.api_path, file);
        });
        // dirs.unshift(api._.api_path);
        for (let dir of dirs) {
            yield initSqlFor(dir);
        }
    });
}
exports.initSql = initSql;
var loadtests_1 = require("./loadtests");
exports.loadTests = loadtests_1.loadTests;

//# sourceMappingURL=local.js.map
