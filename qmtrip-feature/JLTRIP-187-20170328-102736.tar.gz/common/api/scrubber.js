"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const _ = require("lodash");
const traverse = require("traverse");
var dnode = require("dnode");
var registered_scrub = new Map();
var registered_unscrub = new Map();
function setupClassName(clsname) {
    return function (obj) {
        obj.__class = clsname;
        return obj;
    };
}
function getClassCreator(cls) {
    return function (obj) {
        obj = _.create(cls.prototype, obj);
        delete obj.__class;
        return obj;
    };
}
function registerClass(cls, name, scrub, unscrub) {
    name = name ? (name.endsWith('.') ? name + cls.name : name) : cls.name;
    if (registered_scrub.has(cls.prototype))
        console.warn('class ' + cls.name + ' has already registered for API');
    registered_scrub.set(cls.prototype, scrub || setupClassName(name));
    if (registered_unscrub.has(name))
        console.warn('type ' + name + ' has already registered for API');
    registered_unscrub.set(name, unscrub || getClassCreator(cls));
}
exports.registerClass = registerClass;
registerClass(Date, null, function (obj) {
    return { __class: 'Date', value: obj.getTime() };
}, function (obj) {
    return new Date(obj.value);
});
function scrub(obj) {
    var self = this;
    var paths = {};
    var links = [];
    var args = traverse(obj).map(function (node) {
        if (typeof node === 'function') {
            var i = self.callbacks.indexOf(node);
            if (i >= 0 && !(i in paths)) {
                // Keep previous function IDs only for the first function
                // found. This is somewhat suboptimal but the alternatives
                // are worse.
                paths[i] = this.path;
            }
            else {
                var id = self.callbacks.length;
                self.callbacks.push(node);
                paths[id] = this.path;
            }
            this.update('[Function]');
        }
        else if (this.circular) {
            links.push({ from: this.circular.path, to: this.path });
            this.update('[Circular]');
        }
        else if (typeof node === 'object' && node != null) {
            let proto = Object.getPrototypeOf(node);
            while (proto) {
                var func = registered_scrub.get(proto);
                if (func) {
                    this.update(func(node));
                    return;
                }
                proto = Object.getPrototypeOf(proto);
            }
        }
    });
    return {
        arguments: args,
        callbacks: paths,
        links: links
    };
}
exports.scrub = scrub;
function unscrub(msg, f) {
    var args = msg.arguments || [];
    var wait_resolve = [];
    args = traverse(args).forEach(function (node) {
        if (!node || node === null || typeof node != 'object' || !node.__class)
            return;
        var createObject = registered_unscrub.get(node.__class);
        if (!createObject)
            return;
        var obj = createObject(node); //此处应该返回一个promise应该先等它执行完
        if (obj['$waitresolved'] && typeof obj['$waitresolved'] === 'object' && typeof obj['$waitresolved']['then'] === "function") {
            wait_resolve.push(obj['$waitresolved']);
        }
        //对象已经被替换,重新遍历一遍
        obj = traverse(obj).forEach(function (k) {
            if (!k || k === null || typeof node != 'object' || !k.__class)
                return;
            var createObject = registered_unscrub.get(k.__class);
            if (!createObject)
                return;
            this.update(createObject(k));
        });
        this.update(obj);
    });
    if (wait_resolve.length > 0) {
        args.push(Promise.all(wait_resolve));
    }
    var trav = traverse(args);
    if (msg.callbacks) {
        Object.keys(msg.callbacks).forEach(function (sid) {
            var id = parseInt(sid, 10);
            var path = msg.callbacks[id];
            trav.set(path, f(id));
        });
    }
    if (msg.links) {
        msg.links.forEach(function (link) {
            var value = trav.get(link.from);
            trav.set(link.to, value);
        });
    }
    return args;
}
exports.unscrub = unscrub;
//patch dnode for sequelize model instance.
function patch_dnode() {
    var d = dnode({});
    process.nextTick(function () {
        var Scrubber = Object.getPrototypeOf(d.proto.scrubber);
        Scrubber.scrub = scrub;
        Scrubber.unscrub = unscrub;
    });
}
patch_dnode();

//# sourceMappingURL=scrubber.js.map
