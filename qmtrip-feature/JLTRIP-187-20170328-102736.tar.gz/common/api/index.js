/**
 * Created by wlh on 15/8/23.
 */
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const fs = require("fs");
const path = require("path");
const net = require("net");
const language_1 = require("../language");
const perf = require("../perf");
const _ = require("lodash");
const events_1 = require("events");
const wrap_1 = require("./wrap");
const localModules = require("./local");
const remoteModules = require("./remote");
const utils_1 = require("./utils");
const Logger = require("../logger");
var logger = new Logger('api');
var dnode = require("dnode");
const scrubber = require("./scrubber");
const Sequelize = require("sequelize");
var through2 = require('through2');
var weak = require('weak');
scrubber.registerClass(Sequelize.Instance, 'Sqlize', function (obj) {
    return obj.toJSON();
}, function (obj) {
    return obj;
});
function initAPICallTime(ctxt) {
    //console.log('%s:%s.%s %j', ctxt.__through, ctxt.__modname, ctxt.__funcname, ctxt.__arguments);
    ctxt['begin_time'] = process.hrtime();
}
function logAPICallTime(ctxt) {
    //console.log('%s:%s.%s returned %j', ctxt.__through, ctxt.__modname, ctxt.__funcname, ctxt.__returns);
    var ts = process.hrtime(ctxt['begin_time']);
    var t = ts[0] * 1e6 + ts[1] / 1e3;
    if (t > 3e4) {
        t = Math.round(t) / 1e3;
        logger.warn('slow api %s: %s.%s in %d ms', ctxt.__through, ctxt.__modname, ctxt.__funcname, t);
    }
}
function checkAPICallArgs(ctxt) {
    var args = ctxt.__arguments;
    for (var i = 0; i < args.length - 1; i++) {
        if (typeof args[i] == 'function') {
            throw new TypeError('API call with argument of type Function at ' + (i + 1) + ' of ' + args.length);
        }
    }
    if (ctxt.__function['required_params']) {
        for (let key of ctxt.__function['required_params']) {
            if (!_.has(args[0], key)) {
                throw new Error(`"${ctxt.__modname}.${ctxt.__funcname}" required params "${key}" is undefined.`);
            }
        }
    }
    if (ctxt.__function['optional_params'] && ctxt.__function['optional_params'] != '*') {
        //console.info("funcname:", ctxt.__funcname)
        //console.log('accepted:', ctxt.__function['optional_params']);
        //console.log('arguments:', args[0]);
        //sequelizeFind options style
        ctxt.__function['optional_params'] = _.union(ctxt.__function['required_params'], ctxt.__function['optional_params']);
        if (args[0].where) {
            // args[0] = ctxt.__function['optional_params'];
        }
        else {
            args[0] = _.pick(args[0], ctxt.__function['optional_params']);
        }
    }
}
class API {
    constructor() {
        this.client = {};
        this._ = {
            api_path: path.normalize(path.join(__dirname, '../api')),
            config: {},
            local_module: {},
            web_module: {},
            server: null,
            websock: null,
            _authWeb: function () { return Promise.reject(false); },
            emitter: new events_1.EventEmitter(),
            servers: new Map(),
            clients: new Map()
        };
        var emitter = this._.emitter;
        emitter.on('beforeCall', initAPICallTime);
        emitter.on('afterCall', logAPICallTime);
        //emitter.on('afterCall', fixErrorType.bind(this, this._.config.debug));
        emitter.on('beforeRpcCall', emitter.emit.bind(emitter, 'beforeCall'));
        emitter.on('afterRpcCall', emitter.emit.bind(emitter, 'afterCall'));
        emitter.on('beforeCalled', initAPICallTime);
        emitter.on('afterCalled', logAPICallTime);
        emitter.on('beforeCalled', checkAPICallArgs);
        emitter.on('beforeRpcCalled', emitter.emit.bind(emitter, 'beforeCalled'));
        emitter.on('afterRpcCalled', emitter.emit.bind(emitter, 'afterCalled'));
        emitter.on('beforeWebCalled', emitter.emit.bind(emitter, 'beforeCalled'));
        emitter.on('afterWebCalled', emitter.emit.bind(emitter, 'afterCalled'));
        emitter.on('afterWebCalled', this.filterWebErrors.bind(this));
    }
    create() {
        return new API();
    }
    on() {
        this._.emitter.on.apply(this._.emitter, arguments);
    }
    initSql(apipath, apiconf) {
        perf.push('API.initSql');
        this._.api_path = apipath;
        this._.config = apiconf;
        return localModules.initSql(this)
            .then(function () {
            perf.pop();
        });
    }
    init(apipath, apiconf) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            perf.push('API.init');
            var self = this;
            self._.api_path = apipath;
            self._.config = apiconf;
            self._.emitter.on('afterCall', wrap_1.fixErrorType.bind(self, self._.config.debug));
            yield localModules.importSvcs(self);
            yield remoteModules.importSvcs(self);
            self.initTcpServer();
            self.initShoeServer();
            perf.pop();
        });
    }
    initTcpServer() {
        let self = this;
        var zone = Zone.current;
        self._.server = net.createServer(zone.wrap(OnServerConnection, 'OnServerConnection'));
        function OnServerConnection(stream) {
            var ds = {
                require: function (name, cb) {
                    var mod = self._.local_module[name];
                    if (mod == undefined)
                        return cb(language_1.default.ERR.NOT_FOUND());
                    mod = wrap_1.filterModule.call(mod.$origin);
                    var module_wrap = wrap_1.wrapAPIModule(mod, name, self._.emitter, 'RpcCalled', stream);
                    cb(null, module_wrap);
                },
                getModuleList: function (cb) {
                    return cb(null, Object.keys(self._.local_module));
                }
            };
            var d = dnode(ds);
            stream['__listeners'] = new events_1.EventEmitter();
            var key = stream.remoteAddress + ':' + stream.remotePort + '<=>' + stream.localAddress + ':' + stream.localPort;
            self._.clients.set(key, weak(stream, function () {
                self._.clients.delete(key);
            }));
            stream.on('error', function (e) {
                if (e.code == 'ECONNRESET')
                    return;
                logger.warn('API service error:', e.stack ? e.stack : e);
            });
            d.pipe(stream).pipe(d);
        }
    }
    initShoeServer() {
        let self = this;
        var zone = Zone.current;
        var shoe = require("shoe");
        self._.websock = shoe(zone.wrap(onWebConnection, 'onWebConnection'));
        function onWebConnection(stream) {
            logger.log('recv api connection:', stream.url);
            stream['__listeners'] = new events_1.EventEmitter();
            self._.clients.set(stream.id, weak(stream, function () {
                self._.clients.delete(stream.id);
            }));
            if (!stream.remoteAddress && stream.headers && stream.headers['x-real-ip']) {
                stream.remoteAddress = stream.headers['x-real-ip'];
            }
            var cs = genWebAPI(stream, false);
            var d = dnode(cs);
            d.pipe(stream).pipe(through2(zone.wrap(function (chunk, enc, cb) {
                cb(null, chunk);
            }, 'onWebData'))).pipe(d);
        }
        function genWebAPI(stream, authed) {
            var ret = {
                authenticated: authed,
                require: function (name) {
                    var mod = self._.web_module[name];
                    if (mod == undefined)
                        throw language_1.default.ERR.NOT_FOUND(name);
                    if (!authed && !mod.__public)
                        throw language_1.default.ERR.NEED_LOGIN();
                    mod = wrap_1.filterModule.call(mod.$origin);
                    mod = wrap_1.wrapAPIModule(mod, name, self._.emitter, 'WebCalled', stream);
                    return Promise.resolve(mod);
                },
                addEventListener: function ({ event, listener }) {
                    stream.__listeners.on(event, listener);
                }
            };
            if (!authed) {
                ret['authenticate'] = function () {
                    var args = [].slice.apply(arguments);
                    args.unshift(stream);
                    return self.authWeb.apply(self, args)
                        .then(function (res) {
                        return genWebAPI(stream, !!res);
                    });
                };
            }
            return wrap_1.wrapAPIModule(ret, '__init', self._.emitter, 'WebCalled', stream);
        }
    }
    initOnce() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var self = this;
            yield utils_1.callForEach(self, '__initOnce');
            yield utils_1.callForEach(self.client, '__initOnce');
        });
    }
    initHttpApp(app) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var self = this;
            yield utils_1.callForEach(self, '__initHttpApp', app);
            yield utils_1.callForEach(self.client, '__initHttpApp', app);
        });
    }
    broadcast(...args) {
        for (var [key, client] of this._.clients) {
            client.__listeners.emit.apply(client.__listeners, args);
        }
    }
    registerAuthWeb(authWeb) {
        this._._authWeb = authWeb;
    }
    authWeb() {
        var args = [].slice.apply(arguments);
        var stream = args.shift();
        return this._._authWeb.apply(stream, args)
            .then(function (ret) {
            if (!ret)
                return false;
            stream.accountId = ret.accountId;
            stream.tokenId = ret.tokenid;
            var session = Zone.current.get('session');
            session['accountId'] = ret.accountId;
            session['tokenId'] = ret.tokenid;
            return true;
        });
    }
    startServices(port) {
        var self = this;
        return new Promise(function (resolve, reject) {
            self._.server.on('error', function (e) {
                reject(e);
            });
            self._.server.on('listening', function () {
                if (/\//.test(port))
                    fs.chmod(port, '0777');
                resolve(self._.server);
            });
            self._.server.listen(port);
        });
    }
    startWebServices(server, path) {
        var self = this;
        self._.websock.install(server, path);
    }
    loadTests(api_path) {
        if (!api_path)
            api_path = this._.api_path;
        return Promise.all([
            localModules.loadTests(api_path),
            localModules.loadTests(path.join(api_path, 'client'))
        ]);
    }
    filterWebErrors(ctxt) {
        var err = ctxt.__returns[0];
        if (err instanceof language_1.default.ERROR_CODE_C) {
            if (this._.config.debug)
                logger.info(err.stack);
            err.msg = err.msg.replace(/^\S*Call:\w*\.\w+: /, '');
            err.message = err.msg;
        }
        else if (err instanceof Error) {
            logger.error(err.stack);
            if (!this._.config.debug)
                ctxt.__returns[0] = language_1.default.ERR.INTERNAL_ERROR();
        }
    }
}
module.exports = new API();

//# sourceMappingURL=index.js.map
