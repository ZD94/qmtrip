"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const _ = require("lodash");
try {
    var libcrypto = 'crypto';
    var crypto = require(libcrypto);
    exports.md5 = function (str) {
        var md5 = crypto.createHash("md5");
        if (/^v4/.test(process.version)) {
            var buf = new Buffer(str, "utf8");
            str = buf.toString("binary");
        }
        return md5.update(str).digest("hex");
    };
}
catch (e) {
    exports.md5 = require('md5');
}
var charsets = [
    "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ",
    "0123456789",
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
];
function getRndStr(length, type) {
    if (typeof type != 'number' || type < 0 || charsets.length <= type) {
        type = 0;
    }
    return _.times(length, _.constant(charsets[type]))
        .map(_.sample)
        .join("");
}
exports.getRndStr = getRndStr;

//# sourceMappingURL=utils.js.map
