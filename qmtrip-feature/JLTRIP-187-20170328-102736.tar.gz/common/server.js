'use strict';

require('common/node_ts').install(); //init typescript

const path = require('path');
const fs = require("fs");
const cluster = require('cluster');
const util = require('util');
const EventEmitter = require('events');
var Promise = require("bluebird");
Promise.promisifyAll(fs);

const perf = require('common/perf');

var API = require("common/api");

var Logger = require('common/logger');
var logger = new Logger('server');

require('./scheduler');

module.exports = Server;
function Server(name, pid_file){
    if(this == undefined)
        return new Server();
    var self = this;
    EventEmitter.call(self);
    self.name = name;
    self.pid_file = pid_file;
    self.cluster = false;
    self.http_port = null;
    self.http_handler = null;
    self.http_server = null;
    self.http_logtype = 'short';
    self.http_root = null;
    self.http_favicon = null;
    self.api_path = null;
    self.api_port = -1;
    self.api_config = {};
    self.api_server = null;
}
util.inherits(Server, EventEmitter);

Server.prototype.isApiEnabled = function () {
    return this.api_path && this.api_port != -1;
};
Server.prototype.isHttpEnabled = function () {
    return this.http_port != null;
};
Server.prototype.start = function(){
    perf.stat('server.start()');
    var self = this;
    return Promise.resolve()
        .then(function(){
            if (cluster.isWorker)
                return;
            logger.info('%s start.', self.name);
            process.once('SIGUSR2', function () {
                logger.info('%s receive quit from nodemon.', self.name);
                process.kill(process.pid, 'SIGUSR2');
            });
            process.on('uncaughtException', function(e){
                logger.error('uncaughtException:', e.stack || e);
            });
        })
        .then(checkListening.bind(self))
        .then(writePidFile.bind(self))
        .then(initAPISql.bind(self))
        .then(initAPI.bind(self))
        .then(initCluster.bind(self))
        .then(initHttp.bind(self))
        .then(startAPIServer.bind(self))
        .then(startHttpServer.bind(self))
        .then(function(){
            if(cluster.isWorker){
                process.send({cmd:'initialized'});
            }else{
                logger.info('SERVER INITIALIZED.');
            }
        })
        .catch(onError.bind(self))
        .then(function(){
            perf.end();
        });
};

function writePidFile(){
    perf.stat('writePidFile');
    if (cluster.isWorker)
        return;
    var self = this;
    if (!self.pid_file)
        return;
    var pid_dir = path.dirname(self.pid_file);
    return fs.statAsync(pid_dir)
        .then(function(stat){
            if(stat.isDirectory())
                return;
            throw new Error('Not directory:'+pid_dir, 'NotDir');
        }).catch(function(e){
            if(e.code != 'ENOENT')
                throw e;
            return fs.mkdirAsync(pid_dir, '777');
        }).then(function(){
            return fs.writeFileAsync(self.pid_file, process.pid);
        }).catch(function(e){
            logger.error('pid file write fail!');
            throw e;
        });
}

function checkListeningPort(path) {
    var fs = require('fs');
    var conn = {};
    if (/^\d+$/.test(path)){
        conn.port = path;
    } else {
        conn.path = path;
        if(!fs.existsSync(path)){
            return Promise.resolve();
        }
    }

    return new Promise(function(resolve, reject){
        var net = require('net');
        var client = net.connect(conn);
        client.on('error', function (e) {
            if (e.code == 'ECONNREFUSED') {
                if(conn.path){
                    fs.unlink(conn.path, function () {
                        resolve();
                    });
                }else{
                    resolve();
                }
            } else {
                logger.error(e);
                reject(e);
            }
        });
        client.on('connect', function () {
            reject(new Error('Address is in use: '+path));
            client.end();
        });
    });
}

function checkListening(){
    perf.stat('checkListening');
    if (cluster.isWorker)
        return;
    var self = this;
    var check_list = [];
    if(self.isApiEnabled())
        check_list.push(checkListeningPort(self.api_port));
    if(self.isHttpEnabled())
        check_list.push(checkListeningPort(self.http_port));
    return Promise.all(check_list);
}

function initMaster(self, numWorkers){
    perf.stat('initMaster');
    process.title = self.name + ' master';
    logger.info(process.title, process.pid, 'started');

    // master 进程忽略 SIGHUP 信号
    process.on('SIGHUP', function(){});

    var initialized = 0;
    cluster.on('fork', function(worker){
        worker.on('message', function(msg){
            if(msg.cmd == 'getpid'){
                worker.send({cmd:'getpid', pid:process.pid});
            }
            else if(msg.cmd == 'initialized'){
                initialized++;
                if(initialized == numWorkers)
                    logger.info('SERVER INITIALIZED.');
            }
        });
    });
    var listeners = {};
    cluster.on('listening', function(worker, address) {
        var port = address.port;
        if(address.addressType == -1)
            port = address.address;
        if(listeners[port] == undefined)
            listeners[port] = 0;
        listeners[port]++;
        if(listeners[port] == numWorkers){
            var service = '';
            if(port == self.http_port)
                service = 'Web';
            else if(port == self.api_port)
                service = 'API';
            logger.info("%s %s listen on %s...", self.name, service, port);
        }
    });
    cluster.on('exit', function(worker) {
        if(initialized < numWorkers){
            logger.error('%s worker #%d pid:%d died.', self.name, worker.id, worker.process.pid);
            logger.error('SERVER INITIALIZE FAILED.');
            process.exit(-1);
        }
        logger.warn('%s worker#%d pid:%d died.', self.name, worker.id, worker.process.pid);
        cluster.fork();
    });

    for (var i = 0; i < numWorkers; i++) {
        cluster.fork();
    }

    throw 'master';
}
function initWorker(self){
    perf.stat('initWorker');
    var title = self.name  + ' worker';
    if(title.length < 15){
        title = title + ' '.repeat(15-title.length);
    }
    process.title = title + '#' + cluster.worker.id;
    logger.info(process.title, process.pid, 'started');

    process.on('message', function(msg){
        if(msg.cmd == 'getpid'){
            process.master_pid = msg.pid;
        }
    });
    process.send({cmd:'getpid'});
    // 接收到 SIGHUP 信号时，关闭 worker
    process.on('SIGHUP', function () {
        process.exit(0);
    });
}
function initCluster() {
    perf.stat('initCluster');
    var self = this;
    if(!self.cluster)
        return;

    var numWorkers = self.cluster;
    if(typeof numWorkers != 'number' || numWorkers < 1) {
        // 根据 CPU 个数来启动相应数量的 worker
        var os = require('os');
        numWorkers = os.cpus().length;
    }

    var cluster = require('cluster');
    if (cluster.isMaster)
        return initMaster(self, numWorkers);
    else
        return initWorker(self);
}


function initAPISql(){
    perf.stat('initAPISql');
    if(cluster.isWorker)
        return;
    var self = this;
    if(!self.api_path)
        return;
    return API.initSql(self.api_path, self.api_config);
}
function initAPI(){
    perf.stat('initAPI');
    var self = this;
    if(!self.api_path)
        return;
    return API.init(self.api_path, self.api_config)
        .then(function(){
            self.emit('init.api', API);
            if(cluster.isWorker)
                return;
            return API.initOnce();
        });
}
function startAPIServer(){
    perf.stat('startAPIServer');
    var self = this;
    if(!self.isApiEnabled()){
        Promise.resolve();
    }
    return API.startServices(self.api_port)
        .then(function(server){
            self.api_server = server;
            self.emit('start.api', self.api_server);
            if(cluster.isMaster)
                logger.info("%s API listen on %s...", self.name, self.api_port);
        });
}

function createHttpHandler(self){
    perf.stat('initHttpHandler');
    var express = require('express');
    var app = express();
    app.use(Logger.httplog('http', self.http_logtype));

    app.disable('x-powered-by');
    app.enable('trust proxy');

    //设置请求默认超时时间
    var conn_timeout = require("connect-timeout");
    app.use(conn_timeout('6s'));

    var bodyParser = require('body-parser');
    app.use(bodyParser.json({limit:'8mb'}));
    app.use(bodyParser.urlencoded({limit:'8mb', extended:true}));

    var cookieParser = require('cookie-parser');
    app.use(cookieParser());

    if(self.http_favicon){
        var favicon = require('serve-favicon');
        app.use(favicon(self.http_favicon, {maxAge: 1}));
    }
    if(self.http_root){
        app.use(express.static(self.http_root));
    }

    var cluster = require('cluster');
    var VERSION = {VERSION:'dev', GITVERSION:'dev'};
    try{
        VERSION = require(path.join(__dirname, '../VERSION.json'));
    }catch(e){
        //do nothing
    }
    var start_time = new Date();
    app.use('/server_status', function(req, res, next){
        res.header('Access-Control-Allow-Origin', '*');
        res.json({
            app: self.name,
            pid: cluster.isMaster?process.pid:process.master_pid,
            start_time: new Date().getTime()-start_time.getTime(),
            ver: VERSION.VERSION,
            gitver: VERSION.GITVERSION
        });
    });
    return app;
}
var http_logger = new Logger('http');
function initHttpErrorHandler(app) {
    perf.stat('initHttpErrorHandler');
    function handle_http_error(err, req, res, next) {
        var message = (app.get('env') == 'development') ? err.message : '系统错误';
        var code = err.status || 500;
        if (req.xhr || req.ajax) {
            res.json({code: code, message: message, ret: code, errMsg: message});
        } else if((app.get('env') == 'development')) {
            var error = err.stack?err.stack:err;
            error = error.replace(/[\n ]/g, function(match){
                var rep = {'&':'&amp;', '<':'&lt;', '>':'&gt;', "'":'&#39;', '"':'&quot;', '\n':'<br>\n', ' ':'&nbsp;'};
                return rep[match];
            });
            res.status(code);
            res.send(error);
        } else if (err.status === 404) {
            res.redirect('/404');
        }else{
            res.status(code);
            res.render('error', {layout: false, message: message});
        }
        console.info("================="+app.get('env')+"===================");
        http_logger.error('HTTP error:', err.stack?err.stack:err);
        console.info("=================END===========================");
    }
    app.use(handle_http_error);
}
function initHttp(){
    perf.stat('initHttp');
    var self = this;
    if(!self.isHttpEnabled()){
        return;
    }
    if(!self.http_handler){
        self.http_handler = createHttpHandler(self);
    }
    if(self.isApiEnabled()){
        API.initHttpApp(self.http_handler);
    }
    self.emit('init.http_handler', self.http_handler);
    initHttpErrorHandler(self.http_handler);

    var http = require('http');
    self.http_server = http.createServer(self.http_handler);
    self.emit('init.http', self.http_server);

    if(self.api_path){
        API.startWebServices(self.http_server, '/API');
    }
}
function startHttpServer() {
    perf.stat('startHttpServer');
    var self = this;
    if(!self.isHttpEnabled()){
        return Promise.resolve();
    }
    return new Promise(function(resolve, reject){
        self.http_server.on('error', function(e){
            reject(e);
        });
        self.http_server.on('listening', function(){
            if(/\//.test(self.http_port))
                fs.chmod(self.http_port, '0777');
            self.emit('start.http', self.http_server);
            if(cluster.isMaster)
                logger.info("%s Web listen on %s...", self.name, self.http_port);
            resolve(self.http_server);
        });
        self.http_server.listen(self.http_port);
    });
}

function onError(e){
    //var self = this;
    if (e == 'master')
        return;
    console.info("error:",JSON.stringify(e));
    logger.error(e.stack ? e.stack : e);
    if(cluster.isMaster) {
        logger.error('SERVER INITIALIZE FAILED.');
    }
    process.exit(-1);
}

