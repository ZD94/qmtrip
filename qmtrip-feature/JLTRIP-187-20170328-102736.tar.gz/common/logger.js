/**
 * Created by wlh on 15/10/19.
 */
"use strict";
const path = require("path");
const util = require("util");
const fs = require("fs");
const moment = require("moment");
const callsite = require("callsite");
const cluster = require("cluster");
const colors = require("colors/safe");
const morgan = require("morgan");
colors.setTheme({
    CRI: 'red',
    WRN: 'yellow',
    INF: 'reset',
    DBG: 'blue',
    TRC: 'blue',
    PRE: 'gray'
});
var Console = console['Console'];
class LogFile {
    constructor(logdir, prefix) {
        this.logdir = logdir;
        this.prefix = prefix;
        this.file = null;
        this.ymd = null;
        this.logger = null;
        if (!fs.existsSync(logdir))
            fs.mkdirSync(logdir);
    }
    write(str, now) {
        var m = moment(now);
        var ymd = m.format("YYMMDD");
        if (ymd != this.ymd) {
            this.ymd = ymd;
            this.open(path.join(this.logdir, this.prefix + this.ymd + '.log'));
            this.logger = new Console(this.file, this.file);
        }
        this.logger.log(str);
    }
    open(file) {
        this.close();
        this.file = fs.createWriteStream(file, { flags: "a" });
        this.logger = new Console(this.file, this.file);
    }
    close() {
        if (this.file)
            this.file.end();
        this.logger = null;
    }
    static getFile(logdir, prefix) {
        var k = path.normalize(path.join(logdir, prefix));
        if (LogFile.files.has(k))
            return LogFile.files.get(k);
        var file = new LogFile(logdir, prefix);
        LogFile.files.set(k, file);
        process.on('exit', function () {
            file.close();
        });
        return file;
    }
}
LogFile.files = new Map();
const logformat = '[%s][%s][%s](%s:%d): %s';
const consoleformat = colors['PRE']('[%s][%s](%s:%d): ') + '%s';
class LogChannel {
    constructor(parent, config) {
        this.console = true;
        this.subchannel = {};
        this.parent = parent;
        this.console = ('console' in config) ? (config.console) : (this.parent ? this.parent.console : true);
        this.logdir = config.path || (this.parent ? this.parent.logdir : __dirname);
        this.prefix = config.prefix || (this.parent ? this.parent.prefix : 'logger_');
        this.file = LogFile.getFile(this.logdir, this.prefix);
        if (config.mods) {
            for (let m in config.mods) {
                this.subchannel[m] = new LogChannel(this, config.mods[m]);
            }
        }
    }
    log(level, mod, now, logstr, trace, stack) {
        var logpoint = stack[0];
        var filename = logpoint.filename;
        var linenumber = logpoint.linenumber;
        filename = path.relative(__dirname, filename).replace(/\.\.\//, '');
        var outstr = util.format(logformat, moment(now).format('HH:mm:ss.SSSS'), level, mod, filename, linenumber, logstr);
        if (this.console) {
            var consolestr = outstr;
            var color = colors[level];
            if (color) {
                var basename = path.basename(filename);
                if (basename == 'index.js') {
                    basename = path.basename(path.dirname(filename)) + '/' + basename;
                }
                consolestr = util.format(consoleformat, level, mod, basename, linenumber, color(logstr));
            }
            console.log(consolestr);
        }
        this.file.write(outstr, now);
        if (trace) {
            stack.forEach(function (point) {
                var line = util.format('    at %s', point.line);
                if (this.console)
                    console.log(line);
                this.logger.log(line);
            });
        }
    }
    finalize() {
        for (let m in this.subchannel) {
            this.subchannel[m].finalize();
        }
    }
    static init(options) {
        LogChannel.ROOT = new LogChannel(null, options || {});
    }
    static final() {
        LogChannel.ROOT.finalize();
    }
    static getChannel(mod) {
        var mods = mod.split('.');
        let c = LogChannel.ROOT;
        for (let m of mods) {
            var sub = c.subchannel[m];
            if (!sub)
                break;
            c = sub;
        }
        return c;
    }
}
function writelog(level, mod, now, trace, logstr, stack) {
    var ch = LogChannel.getChannel(mod);
    ch.log(level, mod, now, logstr, trace, stack);
}
function sendlog(level, mod, now, trace, logstr, stack) {
    process.send({ cmd: 'log', level: level, mod: mod, now: now, trace: trace, logstr: logstr, stack: stack });
}
var outputlog = writelog;
function log(level, mod, logstr, trace) {
    if (logstr.length == 0) {
        return;
    }
    var now = new Date();
    var callsites = callsite();
    callsites = callsites.slice(2, trace ? -1 : 3);
    var stack = callsites.map(function (point) {
        return {
            filename: point.getFileName(),
            linenumber: point.getLineNumber(),
            line: point.toString()
        };
    });
    outputlog(level, mod, now, trace, logstr, stack);
}
/**
 * 记录日志类
 *
 * ```
 *  var Logger  = require("common/logger");
 *  var logger = new Logger('mod');
 *  logger.info("test");
 *  logger.error("test");
 *  logger.warn("test");
 * ```
 *
 * @param mod
 */
class Logger {
    constructor(mod) {
        this.cri = this.error;
        this.wrn = this.warn;
        this.inf = this.info;
        this.log = this.info;
        this.dbg = this.debug;
        this.trc = this.trace;
        if (this == undefined) {
            return new Logger(mod);
        }
        if (mod == undefined)
            mod = '';
        this.mod = mod;
    }
    error(...args) {
        log('CRI', this.mod, util.format.apply(util, args));
    }
    ;
    warn(...args) {
        log('WRN', this.mod, util.format.apply(util, args));
    }
    ;
    info(...args) {
        log('INF', this.mod, util.format.apply(util, args));
    }
    ;
    debug(...args) {
        log('DBG', this.mod, util.format.apply(util, args));
    }
    ;
    trace(...args) {
        log('TRC', this.mod, util.format.apply(util, args), true);
    }
    ;
    static init(options) {
        if (cluster.isWorker) {
            outputlog = sendlog;
            return;
        }
        LogChannel.init(options);
        cluster.on('fork', function (worker) {
            worker.on('message', function (msg) {
                if (msg.cmd == 'log') {
                    writelog(msg.level, msg.mod, new Date(msg.now), msg.trace, msg.logstr, msg.stack);
                }
            });
        });
    }
    static finish() {
        LogChannel.final();
    }
    static httplog(mod, format) {
        function compile(fmt) {
            fmt = fmt.replace(/"/g, '\\"');
            var js = '  return "' + fmt.replace(/:([-\w]{2,})(?:\[([^\]]+)\])?/g, function (_, name, arg) {
                return '"\n    + (tokens["' + name + '"](req, res, "' + arg + '") || "-") + "';
            }) + '";';
            return new Function('tokens, req, res', js);
        }
        var fmt = morgan[format] || format || morgan['default'];
        if ('function' != typeof fmt)
            fmt = compile(fmt);
        var mod_access = mod + '.access';
        var mod_fail = mod + '.fail';
        return function (req, res, next) {
            req['_startTime'] = new Date;
            req['_remoteAddress'] = req.ip
                || req['_remoteAddress']
                || (req.connection && req.connection.remoteAddress)
                || undefined;
            function logRequest() {
                res.removeListener('finish', logRequest);
                res.removeListener('close', logRequest);
                var logstr = fmt(morgan, req, res);
                if (null == logstr)
                    return;
                log('INF', (res.statusCode < 400) ? mod_access : mod_fail, logstr);
            }
            res.on('finish', logRequest);
            res.on('close', logRequest);
            next();
        };
    }
}
module.exports = Logger;

//# sourceMappingURL=logger.js.map
