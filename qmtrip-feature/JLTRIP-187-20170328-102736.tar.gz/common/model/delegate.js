"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class ModelDelegate {
    constructor() {
    }
    get isLocal() {
        return this.target.isLocal;
    }
    get $name() {
        return this.target.$name;
    }
    create(obj) {
        return this.target.create(obj);
    }
    get(id, options) {
        return this.target.get(id, options);
    }
    $find(where) {
        return this.target.$find(where);
    }
    find(where) {
        return this.target.find(where);
    }
    update(obj) {
        return this.target.update(obj);
    }
    reload(obj) {
        return this.target.reload(obj);
    }
    destroy(obj, options) {
        return this.target.destroy(obj, options);
    }
    getCached(id) {
        return this.target.getCached(id);
    }
    setTarget(target) {
        this.target = target;
    }
    $resolve() {
        if (typeof this.target.$resolve == 'function')
            return this.target.$resolve();
    }
}
exports.ModelDelegate = ModelDelegate;

//# sourceMappingURL=delegate.js.map
