"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const _ = require("lodash");
class ModelAbstract {
    constructor($class) {
        this.$class = $class;
    }
    get isLocal() {
        return true;
    }
    get $name() {
        return _.camelCase(this.$class.name);
    }
    $resolve() {
        return Promise.resolve();
    }
    $create(obj) {
        return obj;
    }
    create(obj) {
        var target = {};
        var ret = new this.$class(target);
        ret.$created = true;
        ret.$fields = _.pick(obj, this.$class.$fieldnames);
        _.forIn(this.$class.$fields, (field, k) => {
            if (field.primaryKey)
                return;
            if (ret.$fields[k] != undefined)
                return;
            let value = field.defaultValue;
            if (typeof value == 'function')
                value = value();
            if (value == undefined)
                return;
            ret.$fields[k] = value;
        });
        ret = this.$create(ret);
        obj['id'] = ret.id;
        if (this.$class.$parents) {
            _.forIn(this.$class.$parents, (parentClass, k) => {
                var v = parentClass.create(obj);
                ret.$parents[k] = v;
            });
        }
        return ret;
    }
    $update(obj, fields) {
        for (let k in fields) {
            let val = fields[k];
            fields[k] = obj.target[k];
            obj.target[k] = val;
        }
        return Promise.resolve(obj.target);
    }
    update(obj) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var fields = obj.$fields;
            obj.$fields = {};
            if (!obj.$created && (!fields || Object.keys(fields).length == 0))
                return obj;
            //屏蔽创建员工进入createAccount
            /*if(obj.$created && (Object.keys(fields).length == 1 && Object.keys(fields)[0] == 'id'))
                return obj;*/
            try {
                var target = yield this.$update(obj, fields);
                obj.target = target;
                delete obj.$created;
                return obj;
            }
            catch (e) {
                //updater调用过程中可能有新更改,需要合并
                _.defaults(obj.$fields, fields);
                throw e;
            }
            finally {
                //删除$fields中和target中一样的
                Object.keys(obj.$fields)
                    .forEach((k) => {
                    if (obj.target[k] === obj.$fields[k])
                        delete obj.$fields[k];
                });
            }
        });
    }
    destroy(obj, options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            yield this.$destroy(obj, options);
            delete obj.target;
            delete obj.$fields;
            delete obj.$resolved;
        });
    }
    getCached(id) {
        return undefined;
    }
}
exports.ModelAbstract = ModelAbstract;

//# sourceMappingURL=abstract.js.map
