"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const _ = require("lodash");
const language_1 = require("common/language");
const helper_1 = require("common/api/helper");
function regModelType(constructor, name) {
    name = name ? (name.endsWith('.') ? name + constructor.name : name) : constructor.name;
    helper_1.registerClass(constructor, name, function (obj) {
        if (obj.target == undefined)
            return { __class: name };
        if (typeof obj.target.toJSON == 'function')
            obj.target = _.clone(obj.target.toJSON());
        obj.target.__class = name;
        return obj.target;
    }, function (obj) {
        delete obj.__class;
        return new constructor(obj);
    });
}
function getResolved(self, key) {
    return self.$resolved ? self.$resolved[key] : undefined;
}
exports.getResolved = getResolved;
function setResolved(self, key, value) {
    if (self.$resolved == undefined)
        self.$resolved = {};
    self.$resolved[key] = value;
}
function defineResolve(prototype, resolver) {
    prototype.$resolvers = prototype.$resolvers || [];
    prototype.$resolvers.push(resolver);
    var $resolve = prototype.$resolve;
    if (!$resolve || !$resolve.attached) {
        prototype.$resolve = function () {
            return tslib_1.__awaiter(this, void 0, void 0, function* () {
                var promises = this.$resolvers.map((f) => f(this));
                if ($resolve)
                    promises.push($resolve());
                yield Promise.all(promises);
                return this;
            });
        };
        prototype.$resolve.attached = true;
    }
}
var cur_prototype;
var cur_columns = {};
exports.tables = [];
function Table(model, name, options) {
    return function (constructor) {
        name = name || constructor.name;
        options = options || {};
        defineField(constructor, 'createdAt', { type: 'timestamp' });
        defineField(constructor, 'updatedAt', { type: 'timestamp' });
        defineField(constructor, 'deletedAt', { type: 'timestamp' });
        var dotIndex = name.indexOf('.');
        if (dotIndex >= 0) {
            options.schema = _.snakeCase(name.substr(0, dotIndex));
            name = name.substr(dotIndex + 1);
            name = name.length > 0 ? name : constructor.name;
        }
        options.timestamps = true;
        options.paranoid = true;
        options.underscored = true;
        options.underscoredAll = true;
        constructor['$model'] = model;
        constructor['$modelname'] = name;
        constructor['$fields'] = cur_columns;
        constructor['$fieldnames'] = Object.keys(cur_columns);
        constructor['$options'] = options;
        constructor['$getAllFieldNames'] = function () {
            var ret = constructor['$fieldnames'];
            if (constructor['$parents']) {
                _.forIn(constructor['$parents'], (parent) => {
                    ret = _.concat(ret, parent['$fieldnames']);
                });
            }
            return _.uniq(ret);
        };
        exports.tables.push(constructor);
        regModelType(constructor, 'API.' + name);
    };
}
exports.Table = Table;
function TableIndex(fields, option) {
    return function (constructor) {
        var indexes = constructor['$indexes'] = constructor['$indexes'] || [];
        if (typeof fields == 'string') {
            fields = [fields];
        }
        fields = fields.map((s) => _.snakeCase(s));
        option = option || {};
        option.fields = fields;
        indexes.push(option);
    };
}
exports.TableIndex = TableIndex;
function TableExtends(parent, asProp, typeField, typeValue) {
    return function (constructor) {
        if (!constructor['$model'])
            throw new Error('TableExtends before Table');
        constructor['$parents'] = constructor['$parents'] || {};
        constructor['$parents'][asProp] = parent;
        if (typeField) {
            parent['$typefield'] = typeField;
            parent['$children'] = parent['$children'] || {};
            if (_.isArray(typeValue) && typeValue.length) {
                typeValue.forEach((v) => {
                    parent['$children'][v] = constructor;
                });
            }
            else {
                parent['$children'][typeValue] = constructor;
            }
        }
        var prototype = constructor.prototype;
        var keys = Object.getOwnPropertyNames(prototype);
        parent.$fieldnames.forEach(function (field) {
            if (keys.indexOf(field) >= 0)
                return;
            Object.defineProperty(prototype, field, {
                get: function () {
                    var parent = this.$parents[asProp];
                    if (parent)
                        return parent[field];
                    return undefined;
                },
                set: function (val) {
                    var parent = this.$parents[asProp];
                    if (parent)
                        parent[field] = val;
                }
            });
        });
        defineResolve(prototype, (self) => tslib_1.__awaiter(this, void 0, void 0, function* () {
            let value = yield parent.$model.get(self.id, { notRetChild: true });
            self.$parents[asProp] = value;
        }));
    };
}
exports.TableExtends = TableExtends;
function Create() {
    return function (constructor, name, desc) {
        desc.value = function (obj) {
            return constructor.$model.create(obj || {});
        };
    };
}
exports.Create = Create;
function addField(prototype, name, options) {
    if (name == 'id')
        options['primaryKey'] = true;
    options.field = _.snakeCase(name);
    if (prototype !== cur_prototype) {
        cur_prototype = prototype;
        cur_columns = {};
    }
    cur_columns[name] = options;
}
function getField(self, name) {
    if (self.$fields && (self.$fields[name] || self.$fields[name] === 0)) {
        return self.$fields[name];
    }
    if (self.$fields && self.$fields.hasOwnProperty(name)) {
        return undefined;
    }
    if (self.target) {
        return self.target[name];
    }
    else {
        return undefined;
    }
}
function setField(self, name, val) {
    if (!self.$fields) {
        self.$fields = {};
    }
    if (self.target[name] === val) {
        delete self.$fields[name];
        return;
    }
    self.$fields[name] = val;
}
function defineField(constructor, name, options) {
    var prototype = constructor.prototype;
    addField(prototype, name, options);
    Object.defineProperty(constructor.prototype, name, {
        get: function () {
            return getField(this, name);
        },
        set: function (val) {
            setField(this, name, val);
        }
    });
}
function Field(options) {
    return function (prototype, name, desc) {
        options.defaultValue = options.defaultValue || desc.get;
        addField(prototype, name, options);
        desc.get = function () {
            return getField(this, name);
        };
        desc.set = function (val) {
            setField(this, name, val);
        };
    };
}
exports.Field = Field;
function ResolveRef(options, model, key) {
    return function (prototype, name, desc) {
        key = key || name + 'Id';
        addField(prototype, key, options);
        desc.configurable = false;
        desc.get = function () {
            return getResolved(this, name);
        };
        if (desc.set) {
            desc.set = function (val) {
                if (this[name] === val)
                    return;
                setResolved(this, name, val);
                setField(this, key, val.id);
            };
        }
        if (key != name) {
            Object.defineProperty(prototype, key, {
                configurable: false,
                enumerable: false,
                get: function () { return getField(this, key); },
                set: function (val) { return setField(this, key, val); }
            });
        }
        defineResolve(prototype, (self) => tslib_1.__awaiter(this, void 0, void 0, function* () {
            var id = getField(self, key);
            if (id == undefined) {
                setResolved(self, name, null);
                return;
            }
            let value = yield model.get(getField(self, key));
            setResolved(self, name, value);
        }));
    };
}
exports.ResolveRef = ResolveRef;
function ResolveLeft(options, model, key) {
    return function (prototype, name, desc) {
        key = key || _.camelCase(prototype.constructor.name + 'Id');
        desc.configurable = false;
        desc.get = function () {
            return getResolved(this, name);
        };
        defineResolve(prototype, (self) => tslib_1.__awaiter(this, void 0, void 0, function* () {
            var where = { limit: 1 };
            where[key] = self.id;
            let value = yield model.find(where);
            if (value && value[0])
                setResolved(self, name, value);
            else
                setResolved(self, name, null);
        }));
    };
}
exports.ResolveLeft = ResolveLeft;
function Reference(options, key) {
    return function (prototype, name, desc) {
        key = key || name.replace(/^get([A-Z])/, (m, s) => s.toLowerCase()) + 'Id';
        addField(prototype, key, options);
        var getter = desc.value;
        desc.value = function () {
            var id = getField(this, key);
            if (id == undefined)
                return null;
            return getter(id);
        };
        var setterName = name.replace(/^get/, 'set');
        var setter = prototype[setterName];
        if (setter && setterName != name) {
            Object.defineProperty(prototype, setterName, {
                configurable: false,
                enumerable: false,
                value: function (val) {
                    setField(this, key, val.id);
                }
            });
        }
        if (key != name) {
            Object.defineProperty(prototype, key, {
                configurable: false,
                enumerable: false,
                get: function () { return getField(this, key); },
                set: function (val) { return setField(this, key, val); }
            });
        }
    };
}
exports.Reference = Reference;
function RemoteCall() {
    return function (prototype, name, desc) {
        var method = desc.value;
        desc.value = function () {
            let args = arguments;
            if (this.$model.isLocal)
                return method.apply(this, args);
            API.require('model');
            return API.onload()
                .then(() => {
                return API.model.call(this.$model.$name, name, this.id, Array.prototype.slice.call(args));
            });
        };
    };
}
exports.RemoteCall = RemoteCall;
function LocalCall() {
    return function (prototype, name, desc) {
        var method = desc.value;
        desc.value = function () {
            let args = arguments;
            if (this.$model.isLocal)
                return method.apply(this, args);
            return Promise.reject(language_1.default.ERR.PERMISSION_DENY('LocalCall can not be called by RemoteModel'));
        };
    };
}
exports.LocalCall = LocalCall;
function requireAPI(name) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        if (!API[name]) {
            API.require(name);
            yield API.onload();
        }
        return API[name];
    });
}
exports.requireAPI = requireAPI;

//# sourceMappingURL=common.js.map
