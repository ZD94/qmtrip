"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
;
var DataType = function () { return DataType; };
DataType.BINARY = DataType;
DataType.UNSIGNED = DataType;
DataType.ZEROFILL = DataType;
exports.Types = {
    ABSTRACT: DataType,
    STRING: DataType,
    CHAR: DataType,
    TEXT: DataType,
    NUMBER: DataType,
    INTEGER: DataType,
    BIGINT: DataType,
    FLOAT: DataType,
    TIME: DataType,
    DATE: DataType,
    DATEONLY: DataType,
    BOOLEAN: DataType,
    NOW: DataType,
    BLOB: DataType,
    DECIMAL: DataType,
    NUMERIC: DataType,
    UUID: DataType,
    UUIDV1: DataType,
    UUIDV4: DataType,
    HSTORE: DataType,
    JSON: DataType,
    JSONB: DataType,
    VIRTUAL: DataType,
    ARRAY: DataType,
    NONE: DataType,
    ENUM: DataType,
    RANGE: DataType,
    REAL: DataType,
    DOUBLE: DataType,
    "DOUBLE PRECISION": DataType,
    GEOMETRY: DataType,
};
exports.Values = {
    NOW: () => 'now()',
    UUIDV1: () => 'uuid.v1',
    UUIDV4: () => 'uuid.v1',
};
var session = {};
function getSession() {
    return session;
}
exports.getSession = getSession;

//# sourceMappingURL=client.js.map
