"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const _ = require("lodash");
const Logger = require("common/logger");
const Sequelize = require("sequelize");
const index_1 = require("./index");
var initlog = new Logger('sqlinit');
var synclog = new Logger('dbsync');
function syncSchemas(options) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        let allSchemas = {};
        for (let k in index_1.DB.models) {
            let model = index_1.DB.models[k];
            let tn = model.getTableName();
            allSchemas[tn.schema] = true;
        }
        let query = index_1.DB.getQueryInterface();
        let schemas = yield query.showAllSchemas(_.assign({}, options, { logging: false }));
        for (let s of schemas) {
            if (!allSchemas[s])
                synclog.error(`Schema "${s}": not defined.`);
        }
        let newSchemas = [];
        for (let s in allSchemas) {
            if (schemas.indexOf(s) < 0) {
                newSchemas.push(s);
            }
        }
        if (newSchemas.length == 0)
            return;
        var sql_create_schema = newSchemas
            .map((schema) => `CREATE SCHEMA IF NOT EXISTS ${schema};`)
            .join(' ');
        return index_1.DB.query(sql_create_schema, options);
    });
}
let showTablesSql = "SELECT table_schema, table_name FROM information_schema.tables "
    + "WHERE table_type LIKE '%TABLE' AND table_name != 'updatelog' AND table_name != 'spatial_ref_sys' "
    + " AND NOT (table_schema LIKE 'pg_%' OR table_schema = 'information_schema');";
function checkRedundantTables(options) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        let allTables = [];
        let _models = {};
        let models = index_1.DB.models;
        for (let k in models) {
            let tn = models[k].getTableName();
            let tableName = tn.schema + '.' + tn.tableName;
            allTables.push(tableName);
            _models[tableName] = models[k];
            //console.log(models[k].getTableName());
        }
        let tableNames = yield index_1.DB.query(showTablesSql, _.assign({}, options, { type: Sequelize.QueryTypes.SHOWTABLES, logging: false }));
        //console.log(JSON.stringify(tableNames, null, ' '));
        for (let tn of tableNames) {
            let name = tn.table_schema + '.' + tn.table_name;
            if (allTables.indexOf(name) < 0) {
                synclog.error(`Table "${name}": not defined.`);
            }
        }
    });
}
function getExpectType(attr) {
    let type = attr.type;
    if (typeof type !== 'string')
        type = type.toSql();
    if (type == 'timestamp')
        return 'TIMESTAMP WITH TIME ZONE';
    if (type == 'INTEGER')
        return 'INTEGER(32)';
    if (type == 'INTEGER[]')
        return '_INT4[]';
    let m = type.match(/^VARCHAR(\(.*\))$/);
    if (m)
        return 'CHARACTER VARYING' + m[1];
    m = type.match(/^DECIMAL(\(.*\))$/);
    if (m)
        return 'NUMERIC' + m[1];
    return type;
}
function getAllowNull(attr) {
    let allowNull = (attr.allowNull !== false);
    if (attr.primaryKey)
        allowNull = false;
    if ((attr.field === 'created_at' || attr.field === 'updated_at') && attr.type === 'timestamp')
        allowNull = false;
    return allowNull;
}
let describeSql = `
SELECT
    tc.constraint_type as "Constraint",
    c.column_name as "Field",
    c.column_default as "Default",
    c.is_nullable as "Null",
    CASE
        WHEN c.udt_name = 'hstore' THEN c.udt_name 
        ELSE
            CASE WHEN c.data_type = 'integer' or c.data_type = 'numeric' THEN
                    CASE WHEN c.numeric_scale > 0 THEN concat(c.data_type, '(', cast(c.numeric_precision as varchar), ',', cast(c.numeric_scale as varchar), ')')
                        WHEN c.numeric_precision > 0 THEN concat(c.data_type, '(', cast(c.numeric_precision as varchar), ')')
                        ELSE c.data_type
                    END
                WHEN c.data_type = 'character varying' THEN concat(c.data_type, '(', cast(c.character_maximum_length as varchar), ')')
                WHEN c.data_type = 'ARRAY' THEN concat(c.udt_name, '[]')
                ELSE c.data_type
            END
    END as "Type",
    (SELECT array_agg(e.enumlabel)
        FROM pg_catalog.pg_type t JOIN pg_catalog.pg_enum e ON t.oid=e.enumtypid
        WHERE t.typname=c.udt_name) AS "special"
    FROM information_schema.columns c
        LEFT JOIN information_schema.key_column_usage cu ON c.table_name = cu.table_name AND cu.column_name = c.column_name
        LEFT JOIN information_schema.table_constraints tc ON c.table_name = tc.table_name AND cu.column_name = c.column_name AND tc.constraint_type = 'PRIMARY KEY'
    WHERE c.table_name = <%= table %> AND c.table_schema = <%= schema %>
`;
function describeTable(model, options) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        let tablename = model.getTableName();
        let sql = _.template(describeSql)({
            table: index_1.DB.escape(tablename.tableName),
            schema: index_1.DB.escape(tablename.schema)
        });
        return index_1.DB.query(sql, _.assign({}, { type: Sequelize.QueryTypes.DESCRIBE, logging: false }));
    });
}
function syncTable(model, options) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        try {
            let desc = yield describeTable(model, options);
            let attrs = model['attributes'];
            let query = index_1.DB.getQueryInterface();
            let fields = [];
            for (let f in attrs) {
                let attr = attrs[f];
                let field = desc[attr.field];
                fields.push(attr.field);
                if (!field) {
                    yield query.addColumn(model.getTableName(), attr.field, attr, options);
                    continue;
                }
                let expect = getExpectType(attr);
                let allowNull = getAllowNull(attr);
                if (expect !== field.type || allowNull !== field.allowNull) {
                    let changeColumn = false;
                    if (expect === field.type)
                        changeColumn = true;
                    else {
                        if (field.type === 'TIMESTAMP WITHOUT TIME ZONE' && expect == 'TIMESTAMP WITH TIME ZONE') {
                            changeColumn = true;
                        }
                        else if (field.type.match(/^CHARACTER VARYING/) && expect.match(/^CHARACTER VARYING/)) {
                            changeColumn = true;
                        }
                        else if (field.type.match(/^(DOUBLE PRECISION|NUMERIC)/) && expect.match(/^(DOUBLE PRECISION|NUMERIC)/)) {
                            changeColumn = true;
                        }
                        if (changeColumn)
                            synclog.warn(`Table ${model.getTableName()}, colume ${attr.field}: expect type ${expect}, got ${field.type}`);
                        else
                            synclog.error(`Table ${model.getTableName()}, colume ${attr.field}: expect type ${expect}, got ${field.type}`);
                    }
                    if (allowNull !== field.allowNull) {
                        synclog.warn(`Table ${model.getTableName()}, colume ${attr.field}: expect ${allowNull ? 'Nullable' : 'Not Null'}, got ${field.allowNull ? 'Nullable' : 'Not Null'}`);
                    }
                    if (changeColumn)
                        yield query.changeColumn(model.getTableName(), attr.field, attr, options);
                }
            }
            for (let f in desc) {
                if (fields.indexOf(f) < 0)
                    synclog.error(`Table ${model.getTableName()}, colume ${f}: not defined`);
            }
        }
        catch (e) {
            if (/relation.+does\snot\sexist/.test(e.message)) {
                yield model.sync(options);
            }
            else if (typeof e != 'string' || !e.startsWith('No description found for')) {
                throw e;
            }
            yield model.sync(options);
        }
    });
}
function databaseSync(options) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        options = _.extend({ force: false, logging: initlog.info.bind(initlog) }, options || {});
        yield syncSchemas(options);
        yield checkRedundantTables(options);
        for (let k in index_1.DB.models) {
            let model = index_1.DB.models[k];
            yield syncTable(model, options);
            //console.log('=========>', k);
            //console.log(JSON.stringify(desc, null, ' '));
        }
        //throw new Error('just not continue');
        //return DB.sync();
    });
}
exports.databaseSync = databaseSync;

//# sourceMappingURL=sync.js.map
