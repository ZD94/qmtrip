"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const object_1 = require("./object");
const abstract_1 = require("./abstract");
const pager_1 = require("./pager");
class ModelCached extends abstract_1.ModelAbstract {
    constructor($cache, $class) {
        super($class);
        this.$cache = $cache;
    }
    getCached(id) {
        return this.$cache.get(id);
    }
    clearCache() {
        this.$cache.removeAll();
    }
    find(where) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var self = this;
            var pg = new pager_1.Pager(self, where);
            yield pg.fetch();
            return pg;
        });
    }
    get(id, options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!id) {
                return undefined;
            }
            if (!options) {
                options = {};
            }
            var self = this;
            var obj;
            obj = self.$cache.get(id);
            if (!obj) {
                var objPromise = self.getResolved(id, options);
                self.$cache.put(id, objPromise);
                try {
                    obj = yield objPromise;
                    if (obj)
                        self.$cache.put(id, obj);
                }
                catch (e) {
                    obj = null;
                }
            }
            if (!obj) {
                self.$cache.remove(id);
                return null;
            }
            if (!options.notRetChild) {
                obj = self.getChildClassObj(obj);
            }
            return obj;
        });
    }
    getChildClassObj(obj) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var self = this;
            if (self.$class['$typefield']) {
                let type = obj[this.$class['$typefield']];
                let childClass = this.$class['$children'][type];
                return childClass.$model.get(obj.id);
            }
            return obj;
        });
    }
    reload(obj) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var loaded = yield this.getResolved(obj.id);
            obj.target = loaded.target;
            obj.$fields = loaded.$fields;
            obj.$resolved = loaded.$resolved;
            obj.$parents = loaded.$parents;
            return obj;
        });
    }
    update(obj) {
        const _super = name => super[name];
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            let created = obj.$created;
            obj = yield _super("update").call(this, obj);
            if (created) {
                var cached = this.$cache.get(obj.id);
                if (cached !== obj)
                    this.$cache.put(obj.id, obj);
            }
            return obj;
        });
    }
    destroy(obj, options) {
        const _super = name => super[name];
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            this.$cache.remove(obj.id);
            return _super("destroy").call(this, obj, options);
        });
    }
    getResolved(id, options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var obj = yield this.$get(id, options);
            if (!obj)
                return;
            yield object_1.resolveResolvable(obj, options);
            return obj;
        });
    }
}
exports.ModelCached = ModelCached;

//# sourceMappingURL=cached.js.map
