"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const paginate_1 = require("../paginate");
const _types_1 = require("_types");
const helper_1 = require("common/api/helper");
let Pager = class Pager extends Array {
    constructor($model, $query) {
        super();
        this.$model = $model;
        this.$query = $query;
        this.limit = $query.limit || 20;
        this.offset = $query.offset || 0;
    }
    id2obj(ids) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (!ids || !ids.length) {
                return [];
            }
            return Promise.all(ids.map((id) => { return this.$model.get(id, { paranoid: false }); }));
        });
    }
    $fetchDeserialize() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (this.ids) {
                var items = yield this.id2obj(this.ids);
                this.splice(0, this.length);
                items.forEach((v) => this.push(v));
                delete this.ids;
            }
            return this;
        });
    }
    fetch() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            this.$query.offset = this.offset;
            this.$query.limit = this.limit;
            var { ids, count } = yield this.$model.$find(this.$query);
            this.total = count;
            var items = yield this.id2obj(ids);
            this.splice(0, this.length);
            items.forEach((v) => this.push(v));
            return this;
        });
    }
    hasNextPage() {
        return this.curPage < (this.totalPages - 1);
    }
    nextPage() {
        var offset = this.offset + this.limit;
        if (offset < this.total) {
            this.offset = offset;
            return this.fetch();
        }
        return null;
    }
    hasPrevPage() {
        return this.curPage > 0;
    }
    prevPage() {
        if (this.offset == 0)
            return null;
        this.offset = this.offset - this.limit;
        if (this.offset < 0) {
            this.offset = 0;
        }
        return this.fetch();
    }
    get perPage() { return this.limit; }
    get curPage() { return Math.ceil(this.offset / this.limit); }
    get totalPages() { return Math.ceil((this.total + this.limit) / this.limit) - 1; }
};
Pager = tslib_1.__decorate([
    paginate_1.fixArraySubclass
], Pager);
exports.Pager = Pager;
helper_1.registerClass(Pager, null, function (obj) {
    let ret = {
        __class: 'Pager',
        ids: obj.map((s) => { return s.id; }),
        count: obj['total'],
        model: obj.$model.$name,
        query: obj.$query
    };
    return ret;
}, function (obj) {
    let model = _types_1.Models[obj.model];
    let pager = new Pager(model, obj.query);
    pager.total = obj.count;
    pager.ids = obj.ids;
    pager['$waitresolved'] = pager.$fetchDeserialize();
    return pager;
});

//# sourceMappingURL=pager.js.map
