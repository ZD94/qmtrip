"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const _ = require("lodash");
function resolveResolvable(obj, options) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        if (typeof obj.$resolve == 'function') {
            yield obj.$resolve();
        }
    });
}
exports.resolveResolvable = resolveResolvable;
class ModelObject {
    constructor(target) {
        this.target = target;
        var prototype = Object.getPrototypeOf(this);
        var constructor = prototype.constructor;
        this.$model = constructor.$model;
        this.$fields = {};
        this.$resolved = {};
        this.$parents = {};
    }
    reload(noParents) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var tasks = [];
            tasks.push(this.$model.reload(this));
            if (!noParents) {
                _.forIn(this.$parents, (parent) => {
                    tasks.push(parent.reload());
                });
            }
            yield Promise.all(tasks);
            return this;
        });
    }
    save() {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            //var prototype = Object.getPrototypeOf(this);
            //var constructor = prototype.constructor;
            var tasks = [];
            //整合父级$fields(解决只改手机号时不走updateStaff去找updateAccount)
            _.forIn(this.$parents, (parent) => {
                _.extend(this.$fields, parent.$fields);
                // parent.$fields = {};
            });
            let created = this.$created;
            let m = yield this.$model.update(this);
            if (!created || this.$model.isLocal) {
                _.forIn(this.$parents, (parent) => {
                    parent.id = m.id;
                    tasks.push(parent.save());
                });
                yield Promise.all(tasks);
            }
            return this;
        });
    }
    $reset(includeParents) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            //console.log('obj reset', this.$model.$name, this.id);
            if (includeParents) {
                _.forIn(this.$parents, (parent) => {
                    parent.$fields = {};
                });
            }
            this.$fields = {};
        });
    }
    destroy(options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var prototype = Object.getPrototypeOf(this);
            var constructor = prototype.constructor;
            var tasks = [];
            _.forIn(this.$parents, (parent) => {
                tasks.push(parent.destroy(options));
            });
            tasks.push(constructor.$model.destroy(this, options));
            yield Promise.all(tasks);
        });
    }
    validate() { }
    get isLocal() {
        return this.$model.isLocal;
    }
}
exports.ModelObject = ModelObject;

//# sourceMappingURL=object.js.map
