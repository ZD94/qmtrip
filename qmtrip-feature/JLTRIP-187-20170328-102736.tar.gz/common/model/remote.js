"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const cached_1 = require("./cached");
const _ = require("lodash");
var API = require('common/api');
class ModelRemoteOld extends cached_1.ModelCached {
    constructor(options) {
        super(options.cache, options.type);
        this.options = options;
    }
    get isLocal() {
        return false;
    }
    $resolve() {
        if (this.options.resolve)
            return this.options.resolve();
        return;
    }
    $get(id, options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var funcGet = this.options.funcGet;
            if (typeof funcGet == 'function')
                return funcGet();
            yield this.$resolve();
            var func = API[this.options.modname][funcGet];
            if (typeof func !== 'function') {
                throw new TypeError('API.' + this.options.modname + '.' + funcGet + ' is ' + func + ', not a Function.');
            }
            var ret = yield func({ id: id });
            API.addEventListener('modelUpdated:' + this.$class.$modelname + ':' + id, () => tslib_1.__awaiter(this, void 0, void 0, function* () {
                //console.log('modelUpdated:'+this.$class.$modelname+':'+id);
                var obj = yield this.getCached(id);
                obj.reload(true);
            }));
            return ret;
        });
    }
    $find(where) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var funcFind = this.options.funcFind;
            if (typeof funcFind == 'function')
                return funcFind();
            yield this.$resolve();
            var func = API[this.options.modname][funcFind];
            if (typeof func !== 'function') {
                throw new TypeError('API.' + this.options.modname + '.' + funcFind + ' is ' + func + ', not a Function.');
            }
            return func(where);
        });
    }
    $update(obj, fields) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            if (obj.$created) {
                let funcCreate = this.options.funcCreate;
                if (typeof funcCreate == 'function')
                    return funcCreate();
                yield this.$resolve();
                let func = API[this.options.modname][funcCreate];
                if (typeof func !== 'function') {
                    throw new TypeError('API.' + this.options.modname + '.' + funcCreate + ' is ' + func + ', not a Function.');
                }
                _.forIn(obj.$parents, (parent) => {
                    _.extend(fields, parent.$fields);
                });
                obj = yield func(fields);
                return obj.target;
            }
            else {
                let funcUpdate = this.options.funcUpdate;
                if (typeof funcUpdate == 'function')
                    return funcUpdate();
                yield this.$resolve();
                let func = API[this.options.modname][funcUpdate];
                if (typeof func !== 'function') {
                    throw new TypeError('API.' + this.options.modname + '.' + funcUpdate + ' is ' + func + ', not a Function.');
                }
                _.forIn(obj.$parents, (parent) => {
                    _.extend(fields, parent.$fields);
                    parent.$fields = {}; //把父级$fields清空 屏蔽进入父级的update方法
                });
                obj = yield func(_.extend({ id: obj.id }, fields));
                return obj.target;
            }
        });
    }
    $destroy(obj, options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var funcDelete = this.options.funcDelete;
            if (typeof funcDelete == 'function')
                return funcDelete();
            yield this.$resolve();
            var func = API[this.options.modname][funcDelete];
            if (typeof func !== 'function') {
                throw new TypeError('API.' + this.options.modname + '.' + funcDelete + ' is ' + func + ', not a Function.');
            }
            return func({ id: obj.id });
        });
    }
}
exports.ModelRemoteOld = ModelRemoteOld;
class ModelRemote extends cached_1.ModelCached {
    constructor(options) {
        super(options.cache, options.type);
        this.options = options;
    }
    get isLocal() {
        return false;
    }
    $resolve() {
        if (this.options.resolve)
            return this.options.resolve();
        return;
    }
    $get(id, options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            yield this.$resolve();
            var ret = yield API.model.get(this.$class.$model.$name, id, options);
            API.addEventListener('modelUpdated:' + this.$class.$modelname + ':' + id, () => tslib_1.__awaiter(this, void 0, void 0, function* () {
                //console.log('modelUpdated:'+this.$class.$model.$name+':'+id);
                var obj = yield this.getCached(id);
                obj.reload(true);
            }));
            return ret;
        });
    }
    $find(where) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            yield this.$resolve();
            return API.model.find(this.$class.$model.$name, where);
        });
    }
    $update(obj, fields) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            yield this.$resolve();
            if (obj.$created) {
                _.forIn(obj.$parents, (parent) => {
                    _.extend(fields, parent.$fields);
                });
                obj = yield API.model.create(this.$class.$model.$name, fields);
                return obj.target;
            }
            else {
                _.forIn(obj.$parents, (parent) => {
                    _.extend(fields, parent.$fields);
                    parent.$fields = {}; //把父级$fields清空 屏蔽进入父级的update方法
                });
                obj = yield API.model.update(this.$class.$model.$name, obj.id, fields);
                return obj.target;
            }
        });
    }
    $destroy(obj, options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            yield this.$resolve();
            return API.model.destroy(this.$class.$model.$name, obj.id, options);
        });
    }
}
exports.ModelRemote = ModelRemote;

//# sourceMappingURL=remote.js.map
