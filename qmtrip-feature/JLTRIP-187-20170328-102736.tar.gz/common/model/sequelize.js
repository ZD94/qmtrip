"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const cached_1 = require("./cached");
const weakcache_1 = require("common/weakcache");
class ModelSequelize extends cached_1.ModelCached {
    constructor(cache, TClass) {
        super(cache, TClass);
    }
    $create(obj) {
        obj.target = this.$class.$sqlmodel.build(obj['$fields']);
        obj['$fields'] = { '!': '!' };
        return obj;
    }
    $get(id, options) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            var target = yield this.$class.$sqlmodel.findById(id, options);
            if (!target)
                return undefined;
            return new this.$class(target);
        });
    }
    $find(where) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            where.attributes = ['id'];
            var { rows, count } = yield this.$class.$sqlmodel.findAndCount(where);
            let ids = rows.map(function (row) {
                return row.id;
            });
            return { ids: ids, count: count };
        });
    }
    $update(obj, fields) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            try {
                obj.target.set(fields);
                yield obj.target.save({ returning: true });
                return obj.target;
            }
            catch (e) {
                //出错后,需要将之前设置的fields恢复成之前的样子
                var previous = obj.target.previous();
                for (let k in previous) {
                    obj.target.set(k, previous[k]);
                }
                throw e;
            }
        });
    }
    $destroy(obj, options) {
        return obj.target.destroy(options);
    }
}
exports.ModelSequelize = ModelSequelize;
function createServerService(TClass) {
    var cache = weakcache_1.createCache(TClass.name);
    return new ModelSequelize(cache, TClass);
}
exports.createServerService = createServerService;

//# sourceMappingURL=sequelize.js.map
