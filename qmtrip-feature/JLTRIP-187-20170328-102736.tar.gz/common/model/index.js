/**
 * Created by wlh on 15/12/15.
 */
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
var uuid = require('uuid');
const fs = require("fs");
const path = require("path");
const _ = require("lodash");
const Logger = require("common/logger");
const callsite = require("callsite");
const Sequelize = require("sequelize");
const Common = require("./common");
function getSession() {
    return Zone.current.get('session');
}
exports.getSession = getSession;
var cur_dir = process.cwd();
var tsreq_dir = path.join(cur_dir, 'tmp/tsreq');
//sequelize.js bug info see https://github.com/sequelize/sequelize/issues/3781
var pg = require('pg');
delete pg['native'];
var cache = {};
var url;
var logger = new Logger('sequelize');
exports.Types = {
    ABSTRACT: Sequelize.ABSTRACT,
    STRING: Sequelize.STRING,
    CHAR: Sequelize.CHAR,
    TEXT: Sequelize.TEXT,
    NUMBER: Sequelize.NUMBER,
    INTEGER: Sequelize.INTEGER,
    BIGINT: Sequelize.BIGINT,
    FLOAT: Sequelize.FLOAT,
    TIME: Sequelize.TIME,
    DATE: Sequelize.DATE,
    DATEONLY: Sequelize.DATEONLY,
    BOOLEAN: Sequelize.BOOLEAN,
    BLOB: Sequelize.BLOB,
    DECIMAL: Sequelize.DECIMAL,
    NUMERIC: Sequelize.NUMERIC,
    UUID: Sequelize.UUID,
    HSTORE: Sequelize.HSTORE,
    JSON: Sequelize.JSON,
    JSONB: Sequelize.JSONB,
    VIRTUAL: Sequelize.VIRTUAL,
    ARRAY: Sequelize.ARRAY,
    NONE: Sequelize.NONE,
    ENUM: Sequelize.ENUM,
    RANGE: Sequelize.RANGE,
    REAL: Sequelize.REAL,
    DOUBLE: Sequelize.DOUBLE,
    "DOUBLE PRECISION": Sequelize["DOUBLE PRECISION"],
    GEOMETRY: Sequelize.GEOMETRY,
};
exports.Values = {
    NOW: () => new Date(),
    UUIDV1: uuid.v1,
    UUIDV4: uuid.v4,
};
exports.DB = undefined;
function init(conn_url) {
    url = conn_url;
    let options = {
        logging: logger.info.bind(logger),
        timezone: '+08:00',
    };
    if (/^postgres:\/\/.*ssl=true/.test(url)) {
        options.dialect = 'postgres';
        options.dialectOptions = { ssl: true };
    }
    exports.DB = new Sequelize(url, options);
}
exports.init = init;
const cluster = require("cluster");
var API = require('common/api');
var models = {};
function handleModelUpdated(msg) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        if (msg.cmd != 'modelUpdated')
            return;
        var model = models[msg.model];
        if (model == undefined)
            return;
        var obj = model.getCached(msg.id);
        if (obj == undefined)
            return;
        yield obj.reload(true);
        API.broadcast('modelUpdated:' + msg.model + ':' + msg.id);
    });
}
function broadcast(msg, except) {
    if (cluster.isWorker) {
        process.send(msg);
        return;
    }
    _.keys(cluster.workers)
        .map((k) => cluster.workers[k])
        .forEach(function (worker) {
        if (worker === except)
            return;
        worker.send(msg);
    });
}
if (cluster.isMaster) {
    cluster.on('fork', function (worker) {
        worker.on('message', function (msg) {
            if (msg.cmd != 'modelUpdated')
                return;
            handleModelUpdated(msg);
            broadcast(msg, worker);
        });
    });
}
else {
    process.on('message', handleModelUpdated);
}
function initDefines() {
    for (let t of Common.tables) {
        if (exports.DB.models[t['$modelname']]) {
            console.warn('table define overwrite:', t['$modelname']);
        }
        if (t['$indexes']) {
            t['$options'].indexes = t['$indexes'];
        }
        let model = t['$sqlmodel'] = exports.DB.define(t['$modelname'], t['$fields'], t['$options']);
        model.afterUpdate('notifyUpdate', (instance, options) => {
            broadcast({ cmd: 'modelUpdated', model: t['$modelname'], id: instance['id'] });
            API.broadcast('modelUpdated:' + t['$modelname'] + ':' + instance['id']);
        });
        models[t['$modelname']] = t['$model'];
    }
    Common.tables.splice(0, Common.tables.length);
}
exports.initDefines = initDefines;
var sync_1 = require("./sync");
exports.databaseSync = sync_1.databaseSync;
function importSqlDefine(DB, file) {
    return DB['import'](file);
    //var func = require(file);
    //return func({
    //    define: function(name, columns, options){
    //        var model = DB.models[name];
    //        if(model)
    //            return model;
    //        return DB.define(name, columns, options);
    //    }
    //}, Types);
}
function importModel(dir) {
    var stack;
    var filename;
    if (!dir) {
        stack = callsite();
        filename = stack[1].getFileName();
        dir = path.dirname(filename);
    }
    else if (!path.isAbsolute(dir)) {
        stack = callsite();
        filename = stack[1].getFileName();
        var dirname = path.dirname(filename);
        dir = path.join(dirname, dir);
    }
    dir = path.normalize(dir);
    if (dir.startsWith(tsreq_dir)) {
        dir = path.join(cur_dir, path.relative(tsreq_dir, dir));
        dir = path.normalize(dir);
    }
    var isCached = cache[dir];
    if (isCached)
        return exports.DB;
    var stats = fs.statSync(dir);
    if (stats.isDirectory()) {
        fs
            .readdirSync(dir)
            .filter(function (file) {
            if (/.*\.js\.map/.test(file)) {
                return;
            }
            return (file.indexOf(".") !== 0) && (file !== "index.js") && (file !== "relationship.js");
        })
            .forEach(function (file) {
            importSqlDefine(exports.DB, path.join(dir, file));
        });
    }
    else {
        importSqlDefine(exports.DB, dir);
    }
    cache[dir] = true;
    return exports.DB;
}
exports.importModel = importModel;

//# sourceMappingURL=index.js.map
